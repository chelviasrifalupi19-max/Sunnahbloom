<?php

use App\Models\DailyAmalan;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

test('amalan keys includes odoj 1 juz', function () {
    expect(DailyAmalan::AMALAN_KEYS)->toHaveKey('odoj_one_juz');
    expect(DailyAmalan::AMALAN_KEYS['odoj_one_juz']['label'])->toBe('ODOJ 1 Juz (1 Hari 1 Juz)');
    expect(DailyAmalan::AMALAN_KEYS['odoj_one_juz']['category'])->toBe('quran');
    expect(count(DailyAmalan::AMALAN_KEYS))->toBe(15);
});

test('user can view amalan checklist with odoj 1 juz', function () {
    $user = User::factory()->create([
        'role' => 'user',
        'is_active' => true,
    ]);

    $response = $this->actingAs($user)->get(route('amalan.index'));

    $response->assertStatus(200);
    $response->assertSee('ODOJ 1 Juz (1 Hari 1 Juz)');
    $response->assertSee('dari 15 Amalan Selesai');
});

test('user can save amalan with odoj checked', function () {
    $user = User::factory()->create([
        'role' => 'user',
        'is_active' => true,
    ]);

    $response = $this->actingAs($user)->post(route('amalan.save'), [
        'date' => now()->toDateString(),
        'odoj_one_juz' => '1',
        'tilawah_quran' => '1',
    ]);

    $response->assertRedirect();

    $amalan = DailyAmalan::where('user_id', $user->id)
        ->whereDate('date', now()->toDateString())
        ->first();

    expect($amalan)->not->toBeNull();
    expect($amalan->odoj_one_juz)->toBeTrue();
    expect($amalan->tilawah_quran)->toBeTrue();
    expect($amalan->completedCount())->toBe(2);
    expect($amalan->completion_rate)->toBe((int) round((2 / 15) * 100));
});

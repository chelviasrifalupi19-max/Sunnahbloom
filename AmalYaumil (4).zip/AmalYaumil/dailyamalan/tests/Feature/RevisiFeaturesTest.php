<?php

use App\Models\AccessCode;
use App\Models\AmalanItem;
use App\Models\AppSetting;
use App\Models\DailyAmalan;
use App\Models\JournalEntry;
use App\Models\User;
use App\Models\UserReminder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

uses(RefreshDatabase::class);

test('access code is required for registration and validated properly', function () {
    AccessCode::create([
        'code' => 'RQ-SANTRI-2026',
        'label' => 'Santri Angkatan 2026',
        'max_uses' => 2,
        'used_count' => 0,
        'is_active' => true,
    ]);

    // Invalid code should fail
    $invalidResponse = $this->post(route('register.post'), [
        'name' => 'Fulan',
        'email' => 'fulan@example.com',
        'password' => 'password123',
        'password_confirmation' => 'password123',
        'access_code' => 'WRONG-CODE',
    ]);
    $invalidResponse->assertSessionHasErrors('access_code');

    // Valid code should succeed
    $validResponse = $this->post(route('register.post'), [
        'name' => 'Santri Al-Izzah',
        'email' => 'santri@alizzah.id',
        'password' => 'password123',
        'password_confirmation' => 'password123',
        'access_code' => 'RQ-SANTRI-2026',
    ]);

    $validResponse->assertRedirect(route('user.dashboard'));
    $this->assertAuthenticated();

    $user = User::where('email', 'santri@alizzah.id')->first();
    expect($user)->not->toBeNull();
    expect($user->access_code_used)->toBe('RQ-SANTRI-2026');

    $code = AccessCode::where('code', 'RQ-SANTRI-2026')->first();
    expect($code->used_count)->toBe(1);
});

test('forgot password flow generates reset token and allows password reset', function () {
    $user = User::factory()->create([
        'email' => 'muhasabah@example.com',
        'password' => Hash::make('oldpassword123'),
        'is_active' => true,
    ]);

    // Request reset link
    $response = $this->post(route('password.email'), [
        'email' => 'muhasabah@example.com',
    ]);

    $response->assertSessionHas('success');
    $simulationUrl = session('simulation_url');
    expect($simulationUrl)->not->toBeNull();

    // Parse the token from the simulation link path
    $plainToken = basename(parse_url($simulationUrl, PHP_URL_PATH));
    expect($plainToken)->not->toBeNull();

    // Verify record exists in password_reset_tokens table
    $tokenRow = DB::table('password_reset_tokens')->where('email', 'muhasabah@example.com')->first();
    expect($tokenRow)->not->toBeNull();
    expect(Hash::check($plainToken, $tokenRow->token))->toBeTrue();

    // Reset password using the plain token
    $resetResponse = $this->post(route('password.update'), [
        'email' => 'muhasabah@example.com',
        'token' => $plainToken,
        'password' => 'newpassword123',
        'password_confirmation' => 'newpassword123',
    ]);

    $resetResponse->assertRedirect(route('login'));
    $resetResponse->assertSessionHas('success');

    $user->refresh();
    expect(Hash::check('newpassword123', $user->password))->toBeTrue();
});

test('journal entries are encrypted at rest in the database and decryptable by the owner', function () {
    $user = User::factory()->create([
        'role' => 'user',
        'is_active' => true,
    ]);

    $entry = JournalEntry::create([
        'user_id' => $user->id,
        'date' => now()->toDateString(),
        'title' => 'Muhasabah Sangat Rahasia',
        'journal_content' => 'Ini adalah catatan yang sangat pribadi dan tidak boleh dibaca siapapun kecuali saya.',
        'gratitude_notes' => 'Bersyukur atas nikmat sehat dan iman.',
        'forgiveness_reflection' => 'Memaafkan fulan atas kata-katanya tadi siang.',
        'mood' => 'bersyukur',
    ]);

    // Check database directly - must be encrypted!
    $rawRow = DB::table('journal_entries')->where('id', $entry->id)->first();
    expect($rawRow->journal_content)->not->toBe('Ini adalah catatan yang sangat pribadi dan tidak boleh dibaca siapapun kecuali saya.');
    expect($rawRow->journal_content)->not->toContain('pribadi');

    // Access through model - decrypted correctly
    expect($entry->title)->toBe('Muhasabah Sangat Rahasia');
    expect($entry->journal_content)->toBe('Ini adalah catatan yang sangat pribadi dan tidak boleh dibaca siapapun kecuali saya.');
    expect($entry->gratitude_notes)->toBe('Bersyukur atas nikmat sehat dan iman.');
    expect($entry->forgiveness_reflection)->toBe('Memaafkan fulan atas kata-katanya tadi siang.');
});

test('user can add, edit, and delete personal custom amalan', function () {
    $user = User::factory()->create([
        'role' => 'user',
        'is_active' => true,
    ]);

    // Add custom amalan without icon (tests default fallback to sparkles)
    $addResponse = $this->actingAs($user)->post(route('amalan.custom.store'), [
        'label' => 'Membaca Surat Al-Mulk Sebelum Tidur',
        'category' => 'quran',
    ]);

    $addResponse->assertSessionHas('success');

    $customItem = AmalanItem::where('user_id', $user->id)->first();
    expect($customItem)->not->toBeNull();
    expect($customItem->label)->toBe('Membaca Surat Al-Mulk Sebelum Tidur');
    expect($customItem->icon)->toBe('sparkles');

    // Edit custom amalan
    $editResponse = $this->actingAs($user)->put(route('amalan.custom.update', $customItem->id), [
        'label' => 'Membaca Al-Mulk & As-Sajdah',
        'category' => 'quran',
        'icon' => 'sparkles',
    ]);

    $editResponse->assertSessionHas('success');
    $customItem->refresh();
    expect($customItem->label)->toBe('Membaca Al-Mulk & As-Sajdah');

    // Delete custom amalan
    $deleteResponse = $this->actingAs($user)->delete(route('amalan.custom.destroy', $customItem->id));
    $deleteResponse->assertSessionHas('info');

    expect(AmalanItem::where('id', $customItem->id)->exists())->toBeFalse();
});

test('admin can manage master amalan items and dynamic application settings', function () {
    $admin = User::factory()->create([
        'role' => 'admin',
        'is_active' => true,
    ]);

    // Admin updates app settings
    $settingsResponse = $this->actingAs($admin)->post(route('admin.settings.update'), [
        'app_name' => 'Sunnah Bloom',
        'app_sub_header' => 'Platform Digital Amalan Yaumi',
        'app_tagline' => 'powered by Rumah Qur\'an Al-Izzah Cab. Singkawang',
        'app_institution' => 'Rumah Qur\'an (RQ) Al-Izzah Cab. Singkawang',
        'daily_quote' => 'Sebaik-baik manusia adalah yang paling bermanfaat bagi manusia lainnya.',
        'daily_quote_source' => 'Hadits Riwayat Muslim',
        'default_access_code' => 'RQ-ALIZZAH-2026',
    ]);

    $settingsResponse->assertSessionHas('success');
    expect(AppSetting::get('app_name'))->toBe('Sunnah Bloom');
    expect(AppSetting::get('app_tagline'))->toBe('powered by Rumah Qur\'an Al-Izzah Cab. Singkawang');

    // Admin adds a master amalan item
    $addMasterResponse = $this->actingAs($admin)->post(route('admin.amalan-items.store'), [
        'label' => 'Shalat Sunnah Qobliyah Subuh 2 Rakaat',
        'category' => 'sunnah',
        'icon' => 'sun',
    ]);

    $addMasterResponse->assertSessionHas('success');
    $masterItem = AmalanItem::master()->where('label', 'Shalat Sunnah Qobliyah Subuh 2 Rakaat')->first();
    expect($masterItem)->not->toBeNull();
    expect($masterItem->isMaster())->toBeTrue();
    expect($masterItem->user_id)->toBeNull();
});

test('user can update custom daily reminder times', function () {
    $user = User::factory()->create([
        'role' => 'user',
        'is_active' => true,
    ]);

    $response = $this->actingAs($user)->put(route('reminders.update'), [
        'reminder_morning' => '04:45',
        'is_morning_active' => '1',
        'reminder_dhuha' => '10:00',
        'is_dhuha_active' => '1',
        'reminder_evening' => '17:30',
        'is_evening_active' => '1',
        'reminder_night' => '21:30',
        'is_night_active' => '1',
        'browser_notifications_enabled' => '1',
    ]);

    $response->assertSessionHas('success');

    $reminder = UserReminder::where('user_id', $user->id)->first();
    expect($reminder)->not->toBeNull();
    expect($reminder->reminder_morning)->toBe('04:45');
    expect($reminder->reminder_night)->toBe('21:30');
    expect($reminder->is_morning_active)->toBeTrue();
    expect($reminder->browser_notifications_enabled)->toBeTrue();
});

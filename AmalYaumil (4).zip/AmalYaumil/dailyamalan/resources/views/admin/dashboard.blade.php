@extends('layouts.admin')

@section('title', 'Dasbor Administrator — Amalan Yaumi')

@section('content')
<div class="space-y-8">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-2">
                <i data-lucide="shield" class="w-3.5 h-3.5 text-amber-700"></i>
                Pusat Pengawasan Sistem
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Ringkasan Dasbor Administrator
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">
                Pantau keaktifan pengguna, kepatuhan amalan yaumi, dan audit sesi login secara menyeluruh.
            </p>
        </div>

        <div class="flex items-center gap-2">
            <a href="{{ route('admin.users.index') }}"
               class="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-2">
                <i data-lucide="users" class="w-4 h-4 text-amber-400"></i>
                Kelola Pengguna
            </a>
            <a href="{{ route('admin.statistics.index') }}"
               class="px-4 py-2.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-2">
                <i data-lucide="bar-chart-2" class="w-4 h-4 text-amber-600"></i>
                Statistik Detail
            </a>
        </div>
    </div>

    <!-- 6 Key Metric Cards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <!-- 1. Total Users -->
        <div class="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs hover:border-amber-300 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Pengguna</span>
                <div class="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                    <i data-lucide="users" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $totalUsers }}</span>
                <span class="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200/60 px-2 py-0.5 rounded-full">+{{ $newUsersThisWeek }} pekan ini</span>
            </div>
            <p class="text-xs text-slate-400 mt-2">{{ $totalRegularUsers }} pengguna umum terdaftar</p>
        </div>

        <!-- 2. Currently Active Users (15 min) -->
        <div class="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Aktif Saat Ini (15 Menit)</span>
                <div class="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                    <i data-lucide="activity" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-amber-600">{{ $activeUsersCount }}</span>
                <span class="text-xs font-semibold text-slate-500">Pengguna Online</span>
            </div>
            <p class="text-xs text-slate-400 mt-2">{{ $activeTodayCount }} pengguna aktif hari ini</p>
        </div>

        <!-- 3. Logged in Today (Unique) -->
        <div class="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs hover:border-blue-300 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Login Hari Ini</span>
                <div class="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
                    <i data-lucide="log-in" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $loggedInTodayCount }}</span>
                <span class="text-xs font-semibold text-slate-500">Akun Unik</span>
            </div>
            <p class="text-xs text-slate-400 mt-2">Tercatat di audit aktivitas sesi</p>
        </div>

        <!-- 4. Filled Amalan Today -->
        <div class="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs hover:border-orange-300 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Isi Amalan Hari Ini</span>
                <div class="w-10 h-10 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center">
                    <i data-lucide="sun" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $usersFilledAmalanTodayCount }}</span>
                <span class="text-xs font-semibold text-slate-500">Pengguna</span>
            </div>
            <p class="text-xs text-slate-400 mt-2">Dari {{ $totalUsersEverFilledAmalan }} total pengguna aktif mutaba'ah</p>
        </div>

        <!-- 5. Total Amalan Records -->
        <div class="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs hover:border-purple-300 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Entri Amalan</span>
                <div class="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center">
                    <i data-lucide="database" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $totalAmalanEntries }}</span>
                <span class="text-xs font-semibold text-slate-500">Hari Disimpan</span>
            </div>
            <p class="text-xs text-slate-400 mt-2">Seluruh database pengguna terdaftar</p>
        </div>

        <!-- 6. Global Average Rate -->
        <div class="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs hover:border-rose-300 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Rata-Rata Kepatuhan Global</span>
                <div class="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
                    <i data-lucide="pie-chart" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $globalAvgAmalan }}%</span>
                <span class="text-xs font-semibold text-slate-500">Rerata Nilai</span>
            </div>
            <p class="text-xs text-slate-400 mt-2">Tingkat capaian agregat seluruh jamaah</p>
        </div>
    </div>

    <!-- Charts Row: User Growth & Weekly Amalan Trend -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- User Growth Trend (6 Months) -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs flex flex-col justify-between">
            <div>
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h2 class="text-base font-bold text-slate-900">Pertumbuhan Pengguna (6 Bulan Terakhir)</h2>
                        <p class="text-xs text-slate-500">Akumulasi jumlah akun pengguna terdaftar</p>
                    </div>
                    <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700">
                        Total {{ $totalUsers }}
                    </span>
                </div>

                <div class="grid grid-cols-6 gap-3 items-end h-44 pt-4 pb-2 border-b border-slate-100">
                    @foreach($userGrowth as $growth)
                        <div class="flex flex-col items-center justify-end h-full group">
                            <span class="text-[10px] font-bold text-slate-600 mb-1 group-hover:scale-110 transition-transform">
                                {{ $growth['total_users'] }}
                            </span>
                            <div class="w-full max-w-[36px] bg-slate-100 rounded-t-lg overflow-hidden flex flex-col justify-end h-28">
                                <div class="w-full bg-gradient-to-t from-slate-900 to-slate-700 rounded-t-lg transition-all duration-500"
                                     style="height: {{ $totalUsers > 0 ? max(round(($growth['total_users'] / $totalUsers) * 100), 10) : 10 }}%">
                                </div>
                            </div>
                            <span class="text-[10px] font-semibold text-slate-500 mt-2 truncate w-full text-center">
                                {{ $growth['month_label'] }}
                            </span>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="pt-4 flex justify-between text-xs text-slate-400">
                <span>Grafik perkembangan akun secara berkala</span>
                <span>Update harian</span>
            </div>
        </div>

        <!-- Weekly Amalan Activity (7 Days) -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs flex flex-col justify-between">
            <div>
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h2 class="text-base font-bold text-slate-900">Aktivitas Pengisian 7 Hari Terakhir</h2>
                        <p class="text-xs text-slate-500">Jumlah pengguna yang mengisi dan rerata capaian</p>
                    </div>
                    <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200/60">
                        7 Hari Terakhir
                    </span>
                </div>

                <div class="grid grid-cols-7 gap-2 items-end h-44 pt-4 pb-2 border-b border-slate-100">
                    @foreach($amalanWeeklyTrend as $trend)
                        <div class="flex flex-col items-center justify-end h-full group">
                            <span class="text-[10px] font-bold text-amber-700 mb-1">
                                {{ $trend['avg_rate'] }}%
                            </span>
                            <div class="w-full max-w-[30px] bg-slate-100 rounded-t-lg overflow-hidden flex flex-col justify-end h-28">
                                <div class="w-full bg-gradient-to-t from-amber-600 via-amber-500 to-yellow-400 rounded-t-lg transition-all duration-500"
                                     style="height: {{ max($trend['avg_rate'], 8) }}%">
                                </div>
                            </div>
                            <span class="text-[9px] font-semibold text-slate-500 mt-2 truncate w-full text-center">
                                {{ $trend['date_label'] }}
                            </span>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="pt-4 flex justify-between text-xs text-slate-400">
                <span>Persentase menunjukkan rata-rata capaian per hari</span>
                <span>Real-time</span>
            </div>
        </div>

    </div>

    <!-- Tables Row: Recent Logins & Recent Users -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- Live Login Feed -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
                        <i data-lucide="shield-alert" class="w-4 h-4"></i>
                    </div>
                    <h2 class="text-base font-bold text-slate-900">Aktivitas Login Terbaru</h2>
                </div>
                <a href="{{ route('admin.login-activities.index') }}" class="text-xs font-bold text-amber-700 hover:text-amber-800">
                    Semua Log &rarr;
                </a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-200 text-slate-400 font-bold uppercase text-[9px] tracking-wider">
                            <th class="py-2.5 px-3">Pengguna</th>
                            <th class="py-2.5 px-3">Perangkat</th>
                            <th class="py-2.5 px-3">IP Address</th>
                            <th class="py-2.5 px-3">Waktu</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @foreach($recentLogins as $login)
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                                    {{ $login->user ? $login->user->name : 'Akun Terhapus' }}
                                </td>
                                <td class="py-2.5 px-3 text-slate-500 whitespace-nowrap">
                                    {{ $login->device_info }}
                                </td>
                                <td class="py-2.5 px-3 font-mono text-slate-400 whitespace-nowrap">
                                    {{ $login->ip_address }}
                                </td>
                                <td class="py-2.5 px-3 text-slate-500 whitespace-nowrap">
                                    {{ $login->login_at->diffForHumans() }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Registered Users -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
                        <i data-lucide="user-check" class="w-4 h-4"></i>
                    </div>
                    <h2 class="text-base font-bold text-slate-900">Pengguna Terdaftar Terbaru</h2>
                </div>
                <a href="{{ route('admin.users.index') }}" class="text-xs font-bold text-amber-700 hover:text-amber-800">
                    Lihat Semua &rarr;
                </a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-200 text-slate-400 font-bold uppercase text-[9px] tracking-wider">
                            <th class="py-2.5 px-3">Nama</th>
                            <th class="py-2.5 px-3">Peran</th>
                            <th class="py-2.5 px-3">Hari Mutaba'ah</th>
                            <th class="py-2.5 px-3">Status</th>
                            <th class="py-2.5 px-3 text-right">Detail</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @foreach($recentUsers as $user)
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                                    <p class="font-bold text-slate-900">{{ $user->name }}</p>
                                    <p class="text-[10px] text-slate-400">{{ $user->email }}</p>
                                </td>
                                <td class="py-2.5 px-3 whitespace-nowrap">
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold {{ $user->role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600' }}">
                                        {{ ucfirst($user->role) }}
                                    </span>
                                </td>
                                <td class="py-2.5 px-3 text-slate-600 whitespace-nowrap font-medium">
                                    {{ $user->daily_amalans_count }} Hari
                                    @if($user->daily_amalans_avg_completion_rate)
                                        <span class="text-amber-700 font-bold">({{ round($user->daily_amalans_avg_completion_rate) }}%)</span>
                                    @endif
                                </td>
                                <td class="py-2.5 px-3 whitespace-nowrap">
                                    <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold {{ $user->is_active ? 'bg-amber-50 text-amber-800 border border-amber-200/60' : 'bg-rose-50 text-rose-700' }}">
                                        <span class="w-1.5 h-1.5 rounded-full {{ $user->is_active ? 'bg-amber-500' : 'bg-rose-500' }}"></span>
                                        {{ $user->is_active ? 'Aktif' : 'Nonaktif' }}
                                    </span>
                                </td>
                                <td class="py-2.5 px-3 text-right whitespace-nowrap">
                                    <a href="{{ route('admin.users.show', $user->id) }}"
                                       class="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold transition-colors">
                                        Periksa
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</div>
@endsection

@extends('layouts.admin')

@section('title', 'Statistik & Analitik — Admin Amalan Yaumi')

@section('content')
<div class="space-y-8">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">
                Statistik & Laporan Analitik Amalan
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">
                Analisis mendalam mengenai tingkat kepatuhan amalan, segmentasi jamaah, dan distribusi platform.
            </p>
        </div>

        <div class="flex items-center gap-2">
            <span class="px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 shadow-2xs">
                Total Jamaah: {{ $totalUsers }}
            </span>
            <span class="px-3.5 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-xs font-bold text-amber-800 shadow-2xs">
                Total Entri: {{ $totalAmalanEntries }}
            </span>
        </div>
    </div>

    <!-- User Engagement Segmentation -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="mb-6">
            <h2 class="text-base font-bold text-slate-900">Segmentasi Keterlibatan Jamaah</h2>
            <p class="text-xs text-slate-500">Klasifikasi pengguna berdasarkan rata-rata tingkat capaian mutaba'ah</p>
        </div>

        <!-- 4 Grid Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <!-- High -->
            <div class="p-5 rounded-2xl bg-amber-50/80 border border-amber-300">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold text-amber-900 uppercase tracking-wider">Sangat Istiqomah</span>
                    <span class="w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-amber-300"></span>
                </div>
                <p class="text-3xl font-extrabold text-amber-600">{{ $highEngagement }}</p>
                <p class="text-[11px] text-amber-700/90 mt-1">Capaian rata-rata ≥ 75%</p>
            </div>

            <!-- Medium -->
            <div class="p-5 rounded-2xl bg-orange-50/80 border border-orange-200">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold text-orange-900 uppercase tracking-wider">Cukup Konsisten</span>
                    <span class="w-2.5 h-2.5 rounded-full bg-orange-500 ring-2 ring-orange-200"></span>
                </div>
                <p class="text-3xl font-extrabold text-orange-600">{{ $mediumEngagement }}</p>
                <p class="text-[11px] text-orange-700/90 mt-1">Capaian rata-rata 40% – 74%</p>
            </div>

            <!-- Low -->
            <div class="p-5 rounded-2xl bg-blue-50/70 border border-blue-200">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold text-blue-800 uppercase tracking-wider">Perlu Bimbingan</span>
                    <span class="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                </div>
                <p class="text-3xl font-extrabold text-blue-700">{{ $lowEngagement }}</p>
                <p class="text-[11px] text-blue-600/90 mt-1">Capaian rata-rata 1% – 39%</p>
            </div>

            <!-- Zero -->
            <div class="p-5 rounded-2xl bg-slate-50 border border-slate-200">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Belum Mengisi</span>
                    <span class="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
                </div>
                <p class="text-3xl font-extrabold text-slate-800">{{ $zeroEngagement }}</p>
                <p class="text-[11px] text-slate-400 mt-1">Belum pernah mengisi amalan</p>
            </div>
        </div>

        <!-- Visual Segmented Bar -->
        @if($totalUsers > 0)
            <div class="w-full bg-slate-100 rounded-full h-3 flex overflow-hidden">
                <div class="bg-amber-500 h-3" style="width: {{ ($highEngagement / $totalUsers) * 100 }}%" title="Sangat Istiqomah: {{ $highEngagement }}"></div>
                <div class="bg-orange-400 h-3" style="width: {{ ($mediumEngagement / $totalUsers) * 100 }}%" title="Cukup Konsisten: {{ $mediumEngagement }}"></div>
                <div class="bg-blue-400 h-3" style="width: {{ ($lowEngagement / $totalUsers) * 100 }}%" title="Perlu Bimbingan: {{ $lowEngagement }}"></div>
                <div class="bg-slate-300 h-3" style="width: {{ ($zeroEngagement / $totalUsers) * 100 }}%" title="Belum Mengisi: {{ $zeroEngagement }}"></div>
            </div>
        @endif
    </div>

    <!-- Amalan Compliance Leaderboard -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <div>
                <h2 class="text-base font-bold text-slate-900">Peringkat Kepatuhan Jenis Amalan</h2>
                <p class="text-xs text-slate-500">Diurutkan dari amalan yang paling konsisten dilaksanakan oleh jamaah</p>
            </div>
            <span class="text-xs font-semibold text-slate-500">
                Total {{ count($amalanStats) }} Macam Amalan
            </span>
        </div>

        <div class="space-y-3">
            @foreach($amalanStats as $index => $stat)
                <div class="p-4 rounded-2xl bg-slate-50/70 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group hover:bg-slate-100/70 transition-colors">
                    <div class="flex items-center gap-3.5 min-w-0">
                        <!-- Rank Badge -->
                        <div class="w-7 h-7 rounded-xl flex items-center justify-center font-extrabold text-xs shrink-0 {{ $index === 0 ? 'bg-amber-400 text-slate-950 shadow-xs' : ($index === 1 ? 'bg-slate-300 text-slate-800' : ($index === 2 ? 'bg-amber-700 text-white' : 'bg-slate-200 text-slate-600')) }}">
                            {{ $index + 1 }}
                        </div>

                        <!-- Name and Category -->
                        <div class="truncate">
                            <p class="font-bold text-slate-900 text-xs sm:text-sm truncate">{{ $stat['label'] }}</p>
                            <p class="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Kategori: {{ ucfirst($stat['category']) }}</p>
                        </div>
                    </div>

                    <!-- Percentage & Bar Container -->
                    <div class="flex items-center gap-4 sm:w-64 shrink-0">
                        <div class="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                            <div class="bg-gradient-to-r {{ $stat['percentage'] >= 75 ? 'from-amber-600 via-amber-500 to-yellow-400' : ($stat['percentage'] >= 50 ? 'from-orange-500 to-amber-400' : 'from-slate-400 to-slate-500') }} h-2.5 rounded-full transition-all duration-500"
                                 style="width: {{ $stat['percentage'] }}%">
                            </div>
                        </div>
                        <span class="w-14 text-right text-xs font-extrabold {{ $stat['percentage'] >= 75 ? 'text-amber-700' : 'text-slate-700' }}">
                            {{ $stat['percentage'] }}%
                        </span>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <!-- Platform & Device Usage Distribution -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="mb-6">
            <h2 class="text-base font-bold text-slate-900">Distribusi Perangkat Pengguna</h2>
            <p class="text-xs text-slate-500">Berdasarkan data sesi login yang tercatat pada sistem</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
            @php
                $totalDeviceHits = array_sum($deviceBreakdown);
            @endphp
            @foreach($deviceBreakdown as $platform => $count)
                @php
                    $pct = $totalDeviceHits > 0 ? round(($count / $totalDeviceHits) * 100) : 0;
                @endphp
                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-bold text-slate-800 truncate">{{ $platform }}</span>
                            <span class="text-xs font-extrabold text-amber-700">{{ $pct }}%</span>
                        </div>
                        <div class="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden mb-2">
                            <div class="bg-slate-800 h-1.5 rounded-full" style="width: {{ $pct }}%"></div>
                        </div>
                    </div>
                    <span class="text-[10px] text-slate-400">{{ $count }} sesi login</span>
                </div>
            @endforeach
        </div>
    </div>

</div>
@endsection

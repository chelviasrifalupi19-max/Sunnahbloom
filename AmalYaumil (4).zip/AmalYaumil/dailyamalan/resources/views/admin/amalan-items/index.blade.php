@extends('layouts.admin')

@section('title', 'Master Amalan Yaumi — Admin Sunnah Bloom')

@section('content')
<div class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-2">
                <i data-lucide="check-square" class="w-3.5 h-3.5 text-amber-700"></i>
                Katalog Master Ibadah
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Master Amalan Yaumi
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">
                Kelola daftar checklist amalan harian standar yang tampil pada lembar amalan seluruh santri dan jamaah.
            </p>
        </div>
    </div>

    <!-- Create New Master Amalan Form Card -->
    <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
        <h2 class="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
            <i data-lucide="plus-circle" class="w-4 h-4 text-amber-600"></i>
            Tambah Amalan Master Baru
        </h2>

        <form action="{{ route('admin.amalan-items.store') }}" method="POST" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
            @csrf

            <!-- Label -->
            <div class="sm:col-span-5">
                <label for="label" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Nama Amalan <span class="text-rose-600">*</span>
                </label>
                <input type="text" id="label" name="label" placeholder="Contoh: Tilawah 1 Juz (ODOJ) / Shalat Tahajud" required
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <!-- Category -->
            <div class="sm:col-span-3">
                <label for="category" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Kategori <span class="text-rose-600">*</span>
                </label>
                <select id="category" name="category" required
                        class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                    <option value="wajib">Wajib (Fardhu)</option>
                    <option value="sunnah" selected>Sunnah Muakkad</option>
                    <option value="quran">Al-Qur'an & Tadabbur</option>
                    <option value="dzikir">Dzikir & Doa</option>
                    <option value="kebaikan">Amal Shalih & Kebaikan</option>
                </select>
            </div>

            <!-- Icon -->
            <div class="sm:col-span-2">
                <label for="icon" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Ikon (Lucide)
                </label>
                <input type="text" id="icon" name="icon" value="check-circle" placeholder="check-circle"
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <!-- Submit Button -->
            <div class="sm:col-span-2">
                <button type="submit"
                        class="w-full py-2.5 px-4 bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs sm:text-sm rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5">
                    <i data-lucide="plus" class="w-4 h-4"></i>
                    Tambah
                </button>
            </div>
        </form>
    </div>

    <!-- Master Items List Card -->
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex items-center justify-between">
            <div>
                <h2 class="text-base font-bold text-slate-900">Daftar Amalan Master</h2>
                <p class="text-xs text-slate-500 mt-0.5">Amalan yang aktif akan otomatis muncul pada lembar evaluasi harian jamaah</p>
            </div>
            <span class="text-xs font-bold px-3 py-1 rounded-full bg-slate-100 text-slate-700">
                Total: {{ $masterItems->count() }} Amalan
            </span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs sm:text-sm">
                <thead class="bg-slate-50/80 text-slate-600 font-bold text-[11px] uppercase tracking-wider border-b border-slate-100">
                    <tr>
                        <th class="px-6 py-3.5">Urutan</th>
                        <th class="px-6 py-3.5">Nama Amalan</th>
                        <th class="px-6 py-3.5">Kategori</th>
                        <th class="px-6 py-3.5">Identitas Kunci</th>
                        <th class="px-6 py-3.5">Status</th>
                        <th class="px-6 py-3.5 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($masterItems as $index => $item)
                        <tr class="hover:bg-amber-50/30 transition-colors">
                            <td class="px-6 py-4 font-bold text-slate-400">
                                #{{ $index + 1 }}
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-xs shrink-0">
                                        <i data-lucide="{{ $item->icon ?: 'check-circle' }}" class="w-4 h-4"></i>
                                    </div>
                                    <div>
                                        <p class="font-bold text-slate-900">{{ $item->label }}</p>
                                        <p class="text-[11px] text-slate-400 font-mono">Ikon: {{ $item->icon ?: 'check-circle' }}</p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                @php
                                    $catLabels = [
                                        'wajib' => ['bg' => 'bg-rose-100 text-rose-800', 'text' => 'Wajib'],
                                        'sunnah' => ['bg' => 'bg-amber-100 text-amber-800', 'text' => 'Sunnah'],
                                        'quran' => ['bg' => 'bg-emerald-100 text-emerald-800', 'text' => 'Al-Qur\'an'],
                                        'dzikir' => ['bg' => 'bg-sky-100 text-sky-800', 'text' => 'Dzikir'],
                                        'kebaikan' => ['bg' => 'bg-indigo-100 text-indigo-800', 'text' => 'Kebaikan'],
                                    ];
                                    $badge = $catLabels[$item->category] ?? ['bg' => 'bg-slate-100 text-slate-700', 'text' => ucfirst($item->category)];
                                @endphp
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold {{ $badge['bg'] }}">
                                    {{ $badge['text'] }}
                                </span>
                            </td>
                            <td class="px-6 py-4 font-mono text-xs text-slate-500">
                                {{ $item->key }}
                            </td>
                            <td class="px-6 py-4">
                                @if($item->is_active)
                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                        Aktif
                                    </span>
                                @else
                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
                                        <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                        Nonaktif
                                    </span>
                                @endif
                            </td>
                            <td class="px-6 py-4 text-right">
                                <div class="flex items-center justify-end gap-2">
                                    <!-- Edit Trigger Button -->
                                    <button type="button"
                                            onclick="openEditModal({{ $item->id }}, '{{ addslashes($item->label) }}', '{{ $item->category }}', '{{ $item->icon }}', {{ $item->is_active ? 'true' : 'false' }})"
                                            class="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                                            title="Edit Amalan">
                                        <i data-lucide="edit-3" class="w-4 h-4"></i>
                                    </button>

                                    <!-- Delete Button -->
                                    <form action="{{ route('admin.amalan-items.destroy', $item->id) }}" method="POST"
                                          onsubmit="return confirm('Apakah Anda yakin ingin menghapus master amalan ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors" title="Hapus Master Amalan">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center text-slate-400">
                                <i data-lucide="check-square" class="w-10 h-10 mx-auto mb-2 text-slate-300"></i>
                                <p class="font-semibold text-slate-600">Belum ada master amalan</p>
                                <p class="text-xs text-slate-400 mt-1">Gunakan formulir di atas untuk menambahkan amalan master.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Edit Master Modal -->
<div id="editAmalanModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
    <div class="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div class="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                <i data-lucide="edit" class="w-4 h-4 text-amber-600"></i>
                Edit Master Amalan
            </h3>
            <button type="button" onclick="closeEditModal()" class="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form id="editAmalanForm" method="POST" class="mt-4 space-y-4">
            @csrf
            @method('PUT')

            <div>
                <label for="edit_label" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Nama Amalan <span class="text-rose-600">*</span>
                </label>
                <input type="text" id="edit_label" name="label" required
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
                <label for="edit_category" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Kategori <span class="text-rose-600">*</span>
                </label>
                <select id="edit_category" name="category" required
                        class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                    <option value="wajib">Wajib (Fardhu)</option>
                    <option value="sunnah">Sunnah Muakkad</option>
                    <option value="quran">Al-Qur'an & Tadabbur</option>
                    <option value="dzikir">Dzikir & Doa</option>
                    <option value="kebaikan">Amal Shalih & Kebaikan</option>
                </select>
            </div>

            <div>
                <label for="edit_icon" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Ikon (Lucide)
                </label>
                <input type="text" id="edit_icon" name="icon"
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div class="flex items-center gap-2 pt-2">
                <input type="checkbox" id="edit_is_active" name="is_active" value="1"
                       class="w-4 h-4 text-amber-600 rounded border-slate-300 focus:ring-amber-500">
                <label for="edit_is_active" class="text-xs font-bold text-slate-700">
                    Aktifkan amalan ini untuk jamaah
                </label>
            </div>

            <div class="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button type="button" onclick="closeEditModal()"
                        class="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50">
                    Batal
                </button>
                <button type="submit"
                        class="px-5 py-2.5 bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs rounded-xl shadow-xs">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function openEditModal(id, label, category, icon, isActive) {
        const form = document.getElementById('editAmalanForm');
        form.action = `/admin/amalan-items/${id}`;
        document.getElementById('edit_label').value = label;
        document.getElementById('edit_category').value = category;
        document.getElementById('edit_icon').value = icon || 'check-circle';
        document.getElementById('edit_is_active').checked = isActive;
        document.getElementById('editAmalanModal').classList.remove('hidden');
    }

    function closeEditModal() {
        document.getElementById('editAmalanModal').classList.add('hidden');
    }
</script>
@endpush

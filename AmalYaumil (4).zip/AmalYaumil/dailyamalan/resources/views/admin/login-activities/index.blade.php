@extends('layouts.admin')

@section('title', 'Aktivitas & Audit Sesi Login — Admin Amalan Yaumi')

@section('content')
<div class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">
                Audit Aktivitas & Riwayat Sesi Login
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">
                Catatan komprehensif seluruh aktivitas login pengguna untuk menjaga keamanan sistem.
            </p>
        </div>
    </div>

    <!-- 3 Metric Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Sesi Login Hari Ini</span>
            <p class="text-3xl font-extrabold text-slate-900 mt-1">{{ $totalLoginsToday }}</p>
            <p class="text-[11px] text-slate-400 mt-1">Frekuensi percobaan sesi login hari ini</p>
        </div>

        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">Pengguna Unik Hari Ini</span>
            <p class="text-3xl font-extrabold text-amber-600 mt-1">{{ $uniqueUsersToday }}</p>
            <p class="text-[11px] text-slate-400 mt-1">Akun unik yang mengakses aplikasi</p>
        </div>

        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Log Sesi Keseluruhan</span>
            <p class="text-3xl font-extrabold text-slate-900 mt-1">{{ $totalAllTime }}</p>
            <p class="text-[11px] text-slate-400 mt-1">Seluruh riwayat yang tersimpan di database</p>
        </div>
    </div>

    <!-- Filter & Search Toolbar -->
    <div class="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs">
        <form method="GET" action="{{ route('admin.login-activities.index') }}" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
            <!-- Search Input -->
            <div class="sm:col-span-6 relative">
                <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <i data-lucide="search" class="w-4 h-4"></i>
                </div>
                <input type="text" name="search" value="{{ $search }}"
                       placeholder="Cari nama pengguna, email, atau alamat IP..."
                       class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
            </div>

            <!-- Date Filter -->
            <div class="sm:col-span-4">
                <input type="date" name="date" value="{{ $dateFilter }}"
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500">
            </div>

            <!-- Action -->
            <div class="sm:col-span-2 flex items-center gap-2">
                <button type="submit" class="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm rounded-xl transition-all shadow-xs">
                    Saring
                </button>
                @if($search || $dateFilter)
                    <a href="{{ route('admin.login-activities.index') }}" class="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-colors" title="Reset filter">
                        <i data-lucide="rotate-ccw" class="w-4 h-4"></i>
                    </a>
                @endif
            </div>
        </form>
    </div>

    <!-- Table Card -->
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs sm:text-sm">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px] tracking-wider">
                        <th class="py-3.5 px-5">Pengguna</th>
                        <th class="py-3.5 px-4">Alamat IP</th>
                        <th class="py-3.5 px-4">Perangkat & Browser</th>
                        <th class="py-3.5 px-4">Waktu Masuk (Login)</th>
                        <th class="py-3.5 px-5 text-right">Durasi Sesi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($activities as $act)
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="py-3.5 px-5">
                                @if($act->user)
                                    <div class="flex items-center gap-2.5">
                                        <div class="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center">
                                            {{ strtoupper(substr($act->user->name, 0, 2)) }}
                                        </div>
                                        <div>
                                            <p class="font-bold text-slate-900 leading-tight">{{ $act->user->name }}</p>
                                            <p class="text-[10px] text-slate-400">{{ $act->user->email }}</p>
                                        </div>
                                    </div>
                                @else
                                    <span class="text-slate-400 italic">Pengguna Terhapus</span>
                                @endif
                            </td>

                            <td class="py-3.5 px-4 font-mono text-slate-600 whitespace-nowrap text-xs">
                                {{ $act->ip_address }}
                            </td>

                            <td class="py-3.5 px-4 text-slate-700 whitespace-nowrap font-medium">
                                {{ $act->device_info }}
                            </td>

                            <td class="py-3.5 px-4 text-slate-600 whitespace-nowrap text-xs">
                                <p class="font-semibold text-slate-800">{{ $act->login_at->translatedFormat('d M Y, H:i:s') }}</p>
                                <p class="text-[10px] text-slate-400">{{ $act->login_at->diffForHumans() }}</p>
                            </td>

                            <td class="py-3.5 px-5 text-right whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold {{ $act->logout_at ? 'bg-slate-100 text-slate-600' : 'bg-amber-50 text-amber-800 border border-amber-200/60' }}">
                                    {{ $act->duration }}
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="py-12 text-center text-slate-400">
                                <i data-lucide="shield" class="w-8 h-8 mx-auto mb-2 text-slate-300"></i>
                                <p class="font-medium">Tidak ada data aktivitas login yang sesuai.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($activities->hasPages())
            <div class="p-5 border-t border-slate-100">
                {{ $activities->links() }}
            </div>
        @endif
    </div>

</div>
@endsection

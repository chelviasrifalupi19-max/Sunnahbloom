@extends('layouts.admin')

@section('title', 'Detail Pengguna: ' . $user->name . ' — Admin Amalan Yaumi')

@section('content')
<div class="space-y-6">

    <!-- Top Back Navigation & Actions -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <a href="{{ route('admin.users.index') }}"
           class="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 hover:text-amber-600 transition-colors">
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            Kembali ke Daftar Pengguna
        </a>

        <!-- Status Toggle Action -->
        @if($user->id !== Auth::id())
            <form action="{{ route('admin.users.toggle-status', $user->id) }}" method="POST"
                  onsubmit="return confirm('Apakah Anda yakin ingin {{ $user->is_active ? 'menonaktifkan' : 'mengaktifkan' }} akun ini?');">
                @csrf
                <button type="submit"
                        class="px-4 py-2 rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-2 {{ $user->is_active ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200' : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200' }}">
                    <i data-lucide="{{ $user->is_active ? 'user-x' : 'user-check' }}" class="w-4 h-4"></i>
                    {{ $user->is_active ? 'Nonaktifkan Akun Pengguna' : 'Aktifkan Kembali Akun' }}
                </button>
            </form>
        @endif
    </div>

    <!-- Privacy Assurance Banner -->
    <div class="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 text-amber-900 flex items-start gap-3 text-xs leading-relaxed">
        <div class="w-7 h-7 rounded-lg bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 mt-0.5">
            <i data-lucide="lock" class="w-4 h-4"></i>
        </div>
        <div>
            <span class="font-bold">Perlindungan Privasi Spiritual Pengguna:</span>
            Panel administrator hanya menampilkan data agregat kepatuhan amalan yaumi dan audit login. Catatan jurnal doa, curahan hati, dan refleksi syukur pribadi pengguna <strong>sepenuhnya dirahasiakan dan tidak dapat dibuka</strong> oleh pihak manapun demi menjaga kekhusyukan ibadah.
        </div>
    </div>

    <!-- User Profile Header Card -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex flex-col sm:flex-row items-center sm:items-start gap-6">
            <div class="w-20 h-20 rounded-3xl bg-slate-900 text-amber-400 font-extrabold text-2xl flex items-center justify-center shadow-md shrink-0">
                {{ strtoupper(substr($user->name, 0, 2)) }}
            </div>
            <div class="flex-1 text-center sm:text-left">
                <div class="flex flex-wrap items-center justify-center sm:justify-start gap-2.5 mb-1.5">
                    <h1 class="text-2xl font-extrabold text-slate-900">{{ $user->name }}</h1>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-bold {{ $user->role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700' }}">
                        {{ ucfirst($user->role) }}
                    </span>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold {{ $user->is_active ? 'bg-amber-50 text-amber-800 border border-amber-200/60' : 'bg-rose-50 text-rose-700' }}">
                        <span class="w-1.5 h-1.5 rounded-full {{ $user->is_active ? 'bg-amber-500' : 'bg-rose-500' }}"></span>
                        {{ $user->is_active ? 'Status Akun: Aktif' : 'Status Akun: Nonaktif' }}
                    </span>
                </div>

                <p class="text-xs text-slate-500 mb-2">
                    {{ $user->email }} • No. HP: {{ $user->phone ?? '—' }} • Bergabung: {{ $user->created_at->translatedFormat('d F Y') }}
                </p>

                @if($user->bio)
                    <p class="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200/80 max-w-xl italic">
                        "{{ $user->bio }}"
                    </p>
                @endif
            </div>

            <!-- Summary KPI Chips -->
            <div class="grid grid-cols-2 gap-3 shrink-0">
                <div class="p-3 bg-slate-50 border border-slate-200 rounded-2xl text-center">
                    <p class="text-xs font-bold text-slate-400 uppercase">Hari Mutaba'ah</p>
                    <p class="text-xl font-extrabold text-slate-900 mt-0.5">{{ $user->daily_amalans_count }}</p>
                </div>
                <div class="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-center">
                    <p class="text-xs font-bold text-amber-800 uppercase">Rata-Rata Capaian</p>
                    <p class="text-xl font-extrabold text-amber-700 mt-0.5">{{ round($user->daily_amalans_avg_completion_rate ?? 0) }}%</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Amalan Compliance Breakdown -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="mb-6">
            <h2 class="text-base font-bold text-slate-900">Tingkat Kepatuhan Amalan Pengguna</h2>
            <p class="text-xs text-slate-500">Persentase pelaksanaan untuk masing-masing amalan yaumi</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            @foreach($breakdown as $item)
                <div class="p-3.5 rounded-2xl bg-slate-50/70 border border-slate-200 text-xs flex flex-col justify-between">
                    <div class="flex items-center justify-between mb-1.5">
                        <span class="font-bold text-slate-800 truncate">{{ $item['label'] }}</span>
                        <span class="font-extrabold {{ $item['pct'] >= 75 ? 'text-amber-700' : 'text-slate-600' }}">{{ $item['pct'] }}%</span>
                    </div>
                    <div class="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden mb-1">
                        <div class="bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-400 h-1.5 rounded-full" style="width: {{ $item['pct'] }}%"></div>
                    </div>
                    <span class="text-[10px] text-slate-400">{{ $item['count'] }} dari {{ $item['total'] }} hari</span>
                </div>
            @endforeach
        </div>
    </div>

    <!-- Two Columns: Recent Daily Records & Login Activities -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- Recent Daily Amalan Records -->
        <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-base font-bold text-slate-900">Riwayat Mutaba'ah Terbaru</h2>
                <span class="text-xs text-slate-400">10 Entri Terakhir</span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-200 text-slate-400 font-bold uppercase text-[9px] tracking-wider">
                            <th class="py-2.5 px-3">Tanggal</th>
                            <th class="py-2.5 px-3">Capaian</th>
                            <th class="py-2.5 px-3">Amalan Selesai</th>
                            <th class="py-2.5 px-3">Catatan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @forelse($amalanHistory as $history)
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                                    {{ $history->date->translatedFormat('d M Y') }}
                                </td>
                                <td class="py-2.5 px-3 whitespace-nowrap">
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold {{ $history->completion_rate >= 80 ? 'bg-amber-50 text-amber-800 border border-amber-200/60' : 'bg-slate-100 text-slate-600' }}">
                                        {{ $history->completion_rate }}%
                                    </span>
                                </td>
                                <td class="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                                    {{ $history->completedCount() }}/{{ count(\App\Models\DailyAmalan::AMALAN_KEYS) }}
                                </td>
                                <td class="py-2.5 px-3 text-slate-400 max-w-xs truncate">
                                    {{ $history->notes ?: '—' }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="py-6 text-center text-slate-400">
                                    Belum ada data mutaba'ah.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Login Activities of This User -->
        <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-base font-bold text-slate-900">Riwayat Audit Sesi Login</h2>
                <span class="text-xs text-slate-400">Terakhir</span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-200 text-slate-400 font-bold uppercase text-[9px] tracking-wider">
                            <th class="py-2.5 px-3">Perangkat / Browser</th>
                            <th class="py-2.5 px-3">IP Address</th>
                            <th class="py-2.5 px-3">Waktu Login</th>
                            <th class="py-2.5 px-3">Durasi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @forelse($loginActivities as $act)
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                                    {{ $act->device_info }}
                                </td>
                                <td class="py-2.5 px-3 font-mono text-slate-400 whitespace-nowrap">
                                    {{ $act->ip_address }}
                                </td>
                                <td class="py-2.5 px-3 text-slate-500 whitespace-nowrap">
                                    {{ $act->login_at->translatedFormat('d M, H:i') }}
                                </td>
                                <td class="py-2.5 px-3 font-semibold text-amber-700 whitespace-nowrap">
                                    {{ $act->duration }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="py-6 text-center text-slate-400">
                                    Belum ada riwayat audit login.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            @if($loginActivities->hasPages())
                <div class="mt-4 pt-3 border-t border-slate-100">
                    {{ $loginActivities->links() }}
                </div>
            @endif
        </div>

    </div>

</div>
@endsection

@extends('layouts.admin')

@section('title', 'Manajemen Kode Akses & Lisensi — Admin Sunnah Bloom')

@section('content')
<div class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-2">
                <i data-lucide="key" class="w-3.5 h-3.5 text-amber-700"></i>
                Sistem Lisensi & Akses Registrasi
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Manajemen Kode Akses Lembaga
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">
                Terbitkan kode akses/lisensi untuk batch santri, jamaah internal RQ Al-Izzah, atau lisensi komersial.
            </p>
        </div>
    </div>

    <!-- Create New Access Code Form Card -->
    <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
        <h2 class="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
            <i data-lucide="plus-circle" class="w-4 h-4 text-amber-600"></i>
            Terbitkan Kode Akses / Lisensi Baru
        </h2>

        <form action="{{ route('admin.access-codes.store') }}" method="POST" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
            @csrf

            <!-- Code -->
            <div class="sm:col-span-4">
                <label for="code" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Kode Akses <span class="text-rose-600">*</span>
                </label>
                <input type="text" id="code" name="code" placeholder="Contoh: BATCH-02-SANTRI" required
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono uppercase font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <!-- Label -->
            <div class="sm:col-span-4">
                <label for="label" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Keterangan / Label Grup <span class="text-rose-600">*</span>
                </label>
                <input type="text" id="label" name="label" placeholder="Contoh: Santri RQ Al-Izzah Angkatan 2026" required
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <!-- Max Uses -->
            <div class="sm:col-span-2">
                <label for="max_uses" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Maks. Kuota
                </label>
                <input type="number" id="max_uses" name="max_uses" min="1" placeholder="Kosong = Tanpa Batas"
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <!-- Submit Button -->
            <div class="sm:col-span-2">
                <button type="submit"
                        class="w-full py-2.5 px-4 bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs sm:text-sm rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5">
                    <i data-lucide="plus" class="w-4 h-4"></i>
                    Terbitkan
                </button>
            </div>
        </form>
    </div>

    <!-- Access Codes Table Card -->
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex items-center justify-between">
            <h2 class="text-base font-bold text-slate-900">Daftar Kode Akses Aktif</h2>
            <span class="text-xs text-slate-500">Total {{ $codes->total() }} Kode Terdaftar</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs sm:text-sm">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px] tracking-wider">
                        <th class="py-3 px-5">Kode Lisensi</th>
                        <th class="py-3 px-4">Label & Peruntukan</th>
                        <th class="py-3 px-4">Penggunaan</th>
                        <th class="py-3 px-4">Status</th>
                        <th class="py-3 px-4">Dibuat Oleh</th>
                        <th class="py-3 px-5 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($codes as $code)
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="py-3.5 px-5 whitespace-nowrap">
                                <span class="font-mono font-extrabold text-amber-900 bg-amber-50 border border-amber-300 px-2.5 py-1 rounded-lg">
                                    {{ $code->code }}
                                </span>
                            </td>
                            <td class="py-3.5 px-4 font-semibold text-slate-800">
                                {{ $code->label }}
                            </td>
                            <td class="py-3.5 px-4 whitespace-nowrap">
                                <span class="font-bold text-slate-900">{{ $code->used_count }}</span>
                                <span class="text-slate-400">/ {{ $code->max_uses ? $code->max_uses : '∞' }} akun</span>
                            </td>
                            <td class="py-3.5 px-4 whitespace-nowrap">
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold {{ $code->is_active ? 'bg-amber-50 text-amber-800 border border-amber-200' : 'bg-slate-100 text-slate-600' }}">
                                    <span class="w-1.5 h-1.5 rounded-full {{ $code->is_active ? 'bg-amber-500' : 'bg-slate-400' }}"></span>
                                    {{ $code->is_active ? 'Aktif' : 'Nonaktif' }}
                                </span>
                            </td>
                            <td class="py-3.5 px-4 text-slate-500 text-xs">
                                {{ $code->creator ? $code->creator->name : 'Sistem' }}
                            </td>
                            <td class="py-3.5 px-5 text-right whitespace-nowrap">
                                <div class="inline-flex items-center gap-2">
                                    <!-- Toggle Status Form -->
                                    <form action="{{ route('admin.access-codes.toggle', $code->id) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors {{ $code->is_active ? 'border-slate-300 text-slate-600 hover:bg-slate-100' : 'border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100' }}">
                                            {{ $code->is_active ? 'Nonaktifkan' : 'Aktifkan' }}
                                        </button>
                                    </form>

                                    <!-- Delete Form -->
                                    <form action="{{ route('admin.access-codes.destroy', $code->id) }}" method="POST"
                                          onsubmit="return confirm('Apakah Anda yakin ingin menghapus kode akses ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="p-1 text-slate-400 hover:text-rose-600 transition-colors" title="Hapus">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="py-12 text-center text-slate-400">
                                Belum ada kode akses yang diterbitkan.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($codes->hasPages())
            <div class="p-4 border-t border-slate-100">
                {{ $codes->links() }}
            </div>
        @endif
    </div>

</div>
@endsection

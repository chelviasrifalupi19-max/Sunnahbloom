@extends('layouts.admin')

@section('title', 'Pengaturan Aplikasi & Branding — Admin Sunnah Bloom')

@section('content')
<div class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-2">
                <i data-lucide="settings" class="w-3.5 h-3.5 text-amber-700"></i>
                Konfigurasi Sistem Terpusat
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Pengaturan Aplikasi & Branding Lembaga
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">
                Kelola identitas aplikasi, nama lembaga, teks mutiara harian, dan kebijakan lisensi pendaftaran secara dinamis.
            </p>
        </div>
    </div>

    <!-- Main Settings Form Card -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <form action="{{ route('admin.settings.update') }}" method="POST" class="space-y-8">
            @csrf

            <!-- Section 1: Identitas & Branding Lembaga -->
            <div>
                <div class="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
                    <div class="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
                        <i data-lucide="layout" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900">Identitas Aplikasi & Lembaga</h2>
                        <p class="text-xs text-slate-500">Nama aplikasi, sub-header, dan powered-by tagline yang tampil di seluruh sistem</p>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <!-- Nama Aplikasi -->
                    <div>
                        <label for="app_name" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Nama Utama Aplikasi <span class="text-rose-600">*</span>
                        </label>
                        <input type="text" id="app_name" name="app_name"
                               value="{{ old('app_name', $settings['app_name'] ?? 'Sunnah Bloom') }}" required
                               class="w-full px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                        <p class="text-[11px] text-slate-400 mt-1">Nama produk/brand yang tampil di header dan logo utama.</p>
                    </div>

                    <!-- Sub Header -->
                    <div>
                        <label for="app_sub_header" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Sub-Header Aplikasi <span class="text-rose-600">*</span>
                        </label>
                        <input type="text" id="app_sub_header" name="app_sub_header"
                               value="{{ old('app_sub_header', $settings['app_sub_header'] ?? 'Platform Digital Amalan Yaumi') }}" required
                               class="w-full px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                        <p class="text-[11px] text-slate-400 mt-1">Deskripsi singkat di bawah nama aplikasi.</p>
                    </div>

                    <!-- Tagline Lembaga -->
                    <div>
                        <label for="app_tagline" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Tagline Lembaga (Powered by) <span class="text-rose-600">*</span>
                        </label>
                        <input type="text" id="app_tagline" name="app_tagline"
                               value="{{ old('app_tagline', $settings['app_tagline'] ?? 'powered by Rumah Qur\'an Al-Izzah Cab. Singkawang') }}" required
                               class="w-full px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                        <p class="text-[11px] text-slate-400 mt-1">Keterangan lembaga resmi yang tercantum di cover, footer, dan watermark export.</p>
                    </div>

                    <!-- Nama Institusi Resmi -->
                    <div>
                        <label for="app_institution" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Nama Institusi / Cabang Resmi <span class="text-rose-600">*</span>
                        </label>
                        <input type="text" id="app_institution" name="app_institution"
                               value="{{ old('app_institution', $settings['app_institution'] ?? 'Rumah Qur\'an (RQ) Al-Izzah Cab. Singkawang') }}" required
                               class="w-full px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                        <p class="text-[11px] text-slate-400 mt-1">Nama resmi cabang lembaga pengelola mutaba'ah.</p>
                    </div>
                </div>
            </div>

            <!-- Section 2: Teks Mutiara / Kutipan Harian -->
            <div>
                <div class="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
                    <div class="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
                        <i data-lucide="quote" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900">Kutipan Mutiara Harian (Daily Hikmah)</h2>
                        <p class="text-xs text-slate-500">Kutipan motivasi ibadah yang ditampilkan kepada seluruh jamaah di beranda</p>
                    </div>
                </div>

                <div class="space-y-4">
                    <div>
                        <label for="daily_quote" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Teks Mutiara / Ayat / Hadits <span class="text-rose-600">*</span>
                        </label>
                        <textarea id="daily_quote" name="daily_quote" rows="3" required
                                  class="w-full p-4 rounded-xl bg-slate-50 border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">{{ old('daily_quote', $settings['daily_quote'] ?? '') }}</textarea>
                    </div>

                    <div>
                        <label for="daily_quote_source" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Sumber Kutipan / Perawi <span class="text-rose-600">*</span>
                        </label>
                        <input type="text" id="daily_quote_source" name="daily_quote_source"
                               value="{{ old('daily_quote_source', $settings['daily_quote_source'] ?? '') }}" required
                               placeholder="Contoh: QS. Al-Insyirah: 7-8 atau HR. Bukhari"
                               class="w-full sm:w-1/2 px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                    </div>
                </div>
            </div>

            <!-- Section 3: Kebijakan Registrasi & Lisensi -->
            <div>
                <div class="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
                    <div class="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
                        <i data-lucide="shield-check" class="w-4 h-4"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900">Kebijakan Registrasi & Lisensi Akses</h2>
                        <p class="text-xs text-slate-500">Atur apakah pendaftaran akun baru memerlukan kode akses lembaga atau dibuka bebas</p>
                    </div>
                </div>

                <div class="p-5 rounded-2xl bg-amber-50/70 border border-amber-200/90 space-y-4">
                    <label class="flex items-start gap-3 cursor-pointer select-none">
                        <input type="checkbox" name="registration_requires_access_code" value="1"
                               {{ ($settings['registration_requires_access_code'] ?? '1') === '1' ? 'checked' : '' }}
                               class="w-5 h-5 rounded text-amber-500 focus:ring-amber-500 border-slate-300 mt-0.5">
                        <div>
                            <span class="text-sm font-bold text-slate-900 block">Wajibkan Kode Akses / Lisensi saat Pendaftaran (Tahap 1: Internal Lembaga)</span>
                            <span class="text-xs text-slate-500 leading-relaxed block mt-0.5">
                                Jika dicentang, hanya calon jamaah/santri yang memiliki kode akses terdaftar yang dapat membuat akun. Jika dinonaktifkan (Tahap 2), pendaftaran terbuka bebas untuk umum.
                            </span>
                        </div>
                    </label>

                    <div class="pt-3 border-t border-amber-200/60">
                        <label for="default_access_code" class="block text-xs font-bold text-amber-950 uppercase tracking-wider mb-1.5">
                            Kode Akses Default Internal
                        </label>
                        <div class="flex items-center gap-3 max-w-md">
                            <input type="text" id="default_access_code" name="default_access_code"
                                   value="{{ old('default_access_code', $settings['default_access_code'] ?? 'RQ-ALIZZAH-2026') }}" required
                                   class="w-full px-4 py-2.5 rounded-xl bg-white border border-amber-300 text-sm font-mono uppercase font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500">
                            <a href="{{ route('admin.access-codes.index') }}" class="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold whitespace-nowrap shadow-xs transition-colors">
                                Kelola Semua Kode &rarr;
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="pt-4 flex justify-end">
                <button type="submit"
                        class="px-8 py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center gap-2 hover:scale-[1.02] active:scale-[0.98]">
                    <i data-lucide="save" class="w-4 h-4"></i>
                    Simpan Semua Pengaturan
                </button>
            </div>
        </form>
    </div>

</div>
@endsection

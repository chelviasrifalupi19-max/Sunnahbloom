@extends('layouts.app')

@section('title', 'Halaman Tidak Ditemukan (404) — Amalan Yaumi')

@section('content')
<div class="max-w-lg mx-auto py-12 text-center">
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xl p-8 sm:p-12 relative overflow-hidden">
        <!-- Sun Radiant Ambient Glow -->
        <div class="absolute -top-16 -right-16 w-40 h-40 bg-amber-400/20 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -bottom-16 -left-16 w-40 h-40 bg-orange-400/20 rounded-full blur-3xl pointer-events-none"></div>

        <div class="relative z-10">
            <!-- Icon -->
            <div class="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 text-slate-950 font-bold flex items-center justify-center mx-auto mb-6 shadow-xl shadow-amber-500/25 ring-8 ring-amber-100/70">
                <i data-lucide="compass" class="w-10 h-10"></i>
            </div>

            <span class="inline-block px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-extrabold uppercase tracking-widest mb-3">
                Error 404 • Halaman Hilang
            </span>

            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-3">
                Halaman Tidak Ditemukan
            </h1>

            <p class="text-slate-600 text-sm leading-relaxed mb-8">
                Tautan yang Anda tuju mungkin salah ketik, sudah dipindahkan, atau tidak lagi tersedia. Mari kembali ke rute yang tepat.
            </p>

            <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
                <a href="{{ url('/') }}"
                   class="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2">
                    <i data-lucide="home" class="w-4 h-4"></i>
                    Kembali ke Beranda
                </a>
                <a href="{{ route('login') }}"
                   class="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm transition-colors flex items-center justify-center gap-2">
                    <i data-lucide="log-in" class="w-4 h-4"></i>
                    Masuk Akun
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

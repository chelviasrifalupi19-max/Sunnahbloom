@extends('layouts.app')

@section('title', 'Terjadi Kendala Sistem (500) — Amalan Yaumi')

@section('content')
<div class="max-w-lg mx-auto py-12 text-center">
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xl p-8 sm:p-12 relative overflow-hidden">
        <!-- Sun Radiant Ambient Glow -->
        <div class="absolute -top-16 -right-16 w-40 h-40 bg-amber-400/20 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -bottom-16 -left-16 w-40 h-40 bg-orange-400/20 rounded-full blur-3xl pointer-events-none"></div>

        <div class="relative z-10">
            <!-- Icon -->
            <div class="w-20 h-20 rounded-3xl bg-gradient-to-tr from-rose-500 via-amber-500 to-orange-400 text-white font-bold flex items-center justify-center mx-auto mb-6 shadow-xl shadow-amber-500/25 ring-8 ring-amber-100/70">
                <i data-lucide="alert-triangle" class="w-10 h-10"></i>
            </div>

            <span class="inline-block px-3 py-1 rounded-full bg-rose-100 text-rose-900 text-xs font-extrabold uppercase tracking-widest mb-3">
                Error 500 • Kendala Sistem
            </span>

            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-3">
                Terjadi Kendala Teknis
            </h1>

            <p class="text-slate-600 text-sm leading-relaxed mb-8">
                Sistem kami sedang mengalami sedikit kendala sesaat. Silakan tunggu beberapa detik dan muat ulang kembali halaman ini.
            </p>

            <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
                <a href="{{ url('/') }}"
                   class="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2">
                    <i data-lucide="home" class="w-4 h-4"></i>
                    Kembali ke Beranda
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

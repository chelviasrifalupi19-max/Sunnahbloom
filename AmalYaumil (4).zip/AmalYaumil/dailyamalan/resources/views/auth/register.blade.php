@extends('layouts.app')

@section('title', 'Daftar Akun Baru — Amalan Yaumi')

@section('content')
<div class="max-w-md mx-auto py-8">
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden p-8 sm:p-10">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 text-slate-950 font-bold flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/25">
                <i data-lucide="sun" class="w-7 h-7"></i>
            </div>
            <span class="inline-block px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-[10px] font-extrabold uppercase tracking-widest mb-1.5">
                {{ $appSettings['app_name'] ?? 'Sunnah Bloom' }}
            </span>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Daftar Akun Baru</h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">{{ $appSettings['app_sub_header'] ?? 'Platform Digital Amalan Yaumi' }}</p>
            <p class="text-[11px] font-semibold text-amber-700/80 mt-0.5">{{ $appSettings['app_tagline'] ?? 'powered by Rumah Qur\'an Al-Izzah Cab. Singkawang' }}</p>
        </div>

        <!-- Register Form -->
        <form action="{{ route('register.post') }}" method="POST" class="space-y-4">
            @csrf

            @if(($appSettings['registration_requires_access_code'] ?? '1') === '1')
                <!-- Access Code / License -->
                <div class="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200">
                    <div class="flex items-center justify-between mb-1.5">
                        <label for="access_code" class="block text-xs font-bold text-amber-950 uppercase tracking-wider">
                            Kode Akses / Lisensi Lembaga <span class="text-rose-600">*</span>
                        </label>
                        <span class="text-[10px] text-amber-800 font-bold bg-white px-2 py-0.5 rounded-full border border-amber-300">Tahap 1: Internal</span>
                    </div>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                            <i data-lucide="key" class="w-4 h-4 text-amber-600"></i>
                        </div>
                        <input type="text" id="access_code" name="access_code" value="{{ old('access_code', 'RQ-ALIZZAH-2026') }}" required
                               placeholder="Contoh: RQ-ALIZZAH-2026"
                               class="w-full pl-10 pr-4 py-2.5 bg-white border @error('access_code') border-rose-400 bg-rose-50/30 @else border-amber-300 @enderror rounded-xl text-sm font-mono uppercase tracking-wider font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all">
                    </div>
                    @error('access_code')
                        <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                            <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                            {{ $message }}
                        </p>
                    @else
                        <p class="text-[11px] text-amber-800/80 mt-1">
                            Kode akses lisensi resmi <strong>{{ $appSettings['app_institution'] ?? 'RQ Al-Izzah Cab. Singkawang' }}</strong>.
                        </p>
                    @enderror
                </div>
            @endif

            <!-- Name -->
            <div>
                <label for="name" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Nama Lengkap
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="user" class="w-4 h-4"></i>
                    </div>
                    <input type="text" id="name" name="name" value="{{ old('name') }}" required autofocus
                           placeholder="Nama lengkap Anda"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border @error('name') border-rose-400 bg-rose-50/30 @else border-slate-300 @enderror rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
                @error('name')
                    <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            <!-- Email -->
            <div>
                <label for="email" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Alamat Email
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </div>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" required
                           placeholder="nama@email.com"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border @error('email') border-rose-400 bg-rose-50/30 @else border-slate-300 @enderror rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
                @error('email')
                    <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            <!-- Phone (Optional) -->
            <div>
                <label for="phone" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Nomor WhatsApp / HP <span class="text-slate-400 font-normal">(Opsional)</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="phone" class="w-4 h-4"></i>
                    </div>
                    <input type="text" id="phone" name="phone" value="{{ old('phone') }}"
                           placeholder="Contoh: 081234567890"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border @error('phone') border-rose-400 bg-rose-50/30 @else border-slate-300 @enderror rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
                @error('phone')
                    <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            <!-- Password -->
            <div>
                <label for="password" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Kata Sandi <span class="text-slate-400 font-normal">(Minimal 8 karakter)</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="lock" class="w-4 h-4"></i>
                    </div>
                    <input type="password" id="password" name="password" required
                           placeholder="••••••••"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border @error('password') border-rose-400 bg-rose-50/30 @else border-slate-300 @enderror rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
                @error('password')
                    <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            <!-- Confirm Password -->
            <div>
                <label for="password_confirmation" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Konfirmasi Kata Sandi
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="check-check" class="w-4 h-4"></i>
                    </div>
                    <input type="password" id="password_confirmation" name="password_confirmation" required
                           placeholder="••••••••"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
            </div>

            <!-- Submit Button -->
            <div class="pt-2">
                <button type="submit"
                        class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 active:from-amber-500 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99]">
                    <i data-lucide="sun" class="w-4 h-4"></i>
                    Daftar Sekarang
                </button>
            </div>
        </form>

        <!-- Login Link Footer -->
        <div class="mt-8 pt-6 border-t border-slate-100 text-center text-xs text-slate-500">
            Sudah memiliki akun?
            <a href="{{ route('login') }}" class="font-bold text-amber-600 hover:text-amber-700 hover:underline ml-1">
                Masuk di sini
            </a>
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')

@section('title', 'Masuk ke Akun — Amalan Yaumi')

@section('content')
<div class="max-w-md mx-auto py-8">
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden p-8 sm:p-10">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 text-slate-950 font-bold flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/25">
                <i data-lucide="sun" class="w-7 h-7"></i>
            </div>
            <span class="inline-block px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-[10px] font-extrabold uppercase tracking-widest mb-1.5">
                {{ $appSettings['app_name'] ?? 'Sunnah Bloom' }}
            </span>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Selamat Datang Kembali</h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">{{ $appSettings['app_sub_header'] ?? 'Platform Digital Amalan Yaumi' }}</p>
            <p class="text-[11px] font-semibold text-amber-700/80 mt-0.5">{{ $appSettings['app_tagline'] ?? 'powered by Rumah Qur\'an Al-Izzah Cab. Singkawang' }}</p>
        </div>

        <!-- Quick Demo Credentials Selector -->
        <div class="mb-6 p-3.5 bg-amber-50/50 border border-amber-200/80 rounded-2xl text-xs space-y-2">
            <div class="flex items-center justify-between text-slate-500 font-semibold">
                <span class="flex items-center gap-1.5">
                    <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-500"></i>
                    Isi Cepat Demo:
                </span>
                <span class="text-[10px] text-slate-400">Klik untuk mengisi otomatis</span>
            </div>
            <div class="grid grid-cols-2 gap-2">
                <button type="button" onclick="fillCredentials('admin@amalan.id', 'password123')"
                        class="p-2 rounded-xl bg-white border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 text-left transition-all group">
                    <p class="font-bold text-slate-800 text-[11px] group-hover:text-amber-700">Akun Admin</p>
                    <p class="text-[10px] text-slate-400 font-mono truncate">admin@amalan.id</p>
                </button>
                <button type="button" onclick="fillCredentials('ahmad@example.com', 'password123')"
                        class="p-2 rounded-xl bg-white border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 text-left transition-all group">
                    <p class="font-bold text-slate-800 text-[11px] group-hover:text-amber-700">Akun Pengguna</p>
                    <p class="text-[10px] text-slate-400 font-mono truncate">ahmad@example.com</p>
                </button>
            </div>
        </div>

        <!-- Login Form -->
        <form action="{{ route('login.post') }}" method="POST" class="space-y-5">
            @csrf

            <!-- Email -->
            <div>
                <label for="email" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Alamat Email
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </div>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" required autofocus
                           placeholder="nama@email.com"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border @error('email') border-rose-400 bg-rose-50/30 @else border-slate-300 @enderror rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
                @error('email')
                    <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            <!-- Password -->
            <div>
                <label for="password" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Kata Sandi
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="lock" class="w-4 h-4"></i>
                    </div>
                    <input type="password" id="password" name="password" required
                           placeholder="••••••••"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border @error('password') border-rose-400 bg-rose-50/30 @else border-slate-300 @enderror rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
                @error('password')
                    <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            <!-- Remember Me & Forgot Password -->
            <div class="flex items-center justify-between text-xs">
                <label class="flex items-center gap-2 cursor-pointer select-none">
                    <input type="checkbox" name="remember" class="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 border-slate-300">
                    <span class="text-slate-600">Ingat saya</span>
                </label>
                <a href="{{ route('password.request') }}" class="font-bold text-amber-700 hover:text-amber-800 hover:underline">
                    Lupa Kata Sandi?
                </a>
            </div>

            <!-- Submit Button -->
            <button type="submit"
                    class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 active:from-amber-500 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99]">
                <i data-lucide="log-in" class="w-4 h-4"></i>
                Masuk Sekarang
            </button>
        </form>

        <!-- Register Link Footer -->
        <div class="mt-8 pt-6 border-t border-slate-100 text-center text-xs text-slate-500">
            Belum memiliki akun?
            <a href="{{ route('register') }}" class="font-bold text-amber-600 hover:text-amber-700 hover:underline ml-1">
                Daftar sekarang gratis
            </a>
        </div>
    </div>
</div>

<script>
    function fillCredentials(email, password) {
        document.getElementById('email').value = email;
        document.getElementById('password').value = password;
    }
</script>
@endsection

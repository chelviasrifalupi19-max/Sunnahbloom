@extends('layouts.app')

@section('title', 'Lupa Kata Sandi — Sunnah Bloom')

@section('content')
<div class="max-w-md mx-auto py-8">
    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden p-8 sm:p-10 relative">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 text-slate-950 font-bold flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/25">
                <i data-lucide="key-round" class="w-7 h-7"></i>
            </div>
            <span class="inline-block px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-[10px] font-extrabold uppercase tracking-widest mb-1.5">
                {{ $appSettings['app_name'] ?? 'Sunnah Bloom' }}
            </span>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Atur Ulang Kata Sandi</h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">Masukkan alamat email Anda untuk menerima instruksi pemulihan kata sandi.</p>
        </div>

        @if(session('status'))
            <div class="mb-5 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold flex items-start gap-2.5">
                <i data-lucide="check-circle" class="w-4 h-4 text-amber-600 shrink-0 mt-0.5"></i>
                <div>
                    <p>{{ session('status') }}</p>
                    @if(session('simulation_url'))
                        <div class="mt-3 p-3 bg-white rounded-xl border border-amber-300">
                            <p class="text-[11px] text-amber-900 font-bold mb-1">Tautan Langsung Reset (Mode Simulasi Pengujian):</p>
                            <a href="{{ session('simulation_url') }}" class="text-xs text-amber-600 underline font-mono break-all font-bold hover:text-amber-700">
                                Klik di sini untuk mengatur ulang kata sandi sekarang &rarr;
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        @endif

        <form action="{{ route('password.email') }}" method="POST" class="space-y-4">
            @csrf

            <!-- Email -->
            <div>
                <label for="email" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Alamat Email Akun
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </div>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" required autofocus
                           placeholder="nama@email.com"
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border @error('email') border-rose-400 bg-rose-50/30 @else border-slate-300 @enderror rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">
                </div>
                @error('email')
                    <p class="text-xs text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                        <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                        {{ $message }}
                    </p>
                @enderror
            </div>

            <!-- Submit Button -->
            <button type="submit"
                    class="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 active:from-amber-500 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99]">
                <i data-lucide="send" class="w-4 h-4"></i>
                Kirim Tautan Pemulihan
            </button>
        </form>

        <div class="mt-6 pt-6 border-t border-slate-100 text-center">
            <a href="{{ route('login') }}" class="inline-flex items-center gap-2 text-xs font-bold text-amber-700 hover:text-amber-800 transition-colors">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                Kembali ke Halaman Masuk
            </a>
        </div>
    </div>
</div>
@endsection

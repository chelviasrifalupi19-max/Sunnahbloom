@extends('layouts.app')

@section('title', 'Jurnal Jiwa & Refleksi Syukur — Sunnah Bloom')

@section('content')
<div class="max-w-4xl mx-auto space-y-8">

    <!-- Header & Privacy Notice Banner -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
                <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold mb-2">
                    <i data-lucide="shield-check" class="w-3.5 h-3.5 text-amber-700"></i>
                    Terenkripsi AES-256 • Privasi Terjamin
                </div>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    Jurnal Jiwa & Refleksi Syukur
                </h1>
                <p class="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
                    Ruang aman & rahasia untuk mencurahkan muhasabah hati, memaafkan luka batin, dan merenungi karunia Allah tanpa dibaca orang lain.
                </p>
            </div>
            <div class="shrink-0 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                <i data-lucide="lock" class="w-5 h-5 text-amber-600 shrink-0"></i>
                <span class="font-bold">Hanya dapat dibaca oleh Anda</span>
            </div>
        </div>
    </div>

    <!-- Write / Edit Journal Card -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex items-center gap-3 mb-6 pb-4 border-b border-slate-100">
            <div class="w-10 h-10 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center font-bold shrink-0">
                <i data-lucide="feather" class="w-5 h-5 text-amber-700"></i>
            </div>
            <div>
                <h2 class="text-base sm:text-lg font-bold text-slate-900">
                    {{ $todayEntry ? 'Perbarui Jurnal Hari Ini' : 'Tulis Catatan Refleksi Jiwa Hari Ini' }}
                </h2>
                <p class="text-xs text-slate-400">Tumpahkan segala keluh kesah, harapan, dan syukur ke hadirat Allah</p>
            </div>
        </div>

        <form action="{{ route('journal.store') }}" method="POST" class="space-y-6">
            @csrf

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Date -->
                <div>
                    <label for="date" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Tanggal Jurnal <span class="text-rose-600">*</span>
                    </label>
                    <input type="date" id="date" name="date"
                           value="{{ old('date', $todayEntry ? $todayEntry->date->toDateString() : \Carbon\Carbon::today()->toDateString()) }}"
                           required
                           class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <!-- Title -->
                <div class="sm:col-span-2">
                    <label for="title" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Judul Refleksi / Renungan Jiwa <span class="text-rose-600">*</span>
                    </label>
                    <input type="text" id="title" name="title"
                           value="{{ old('title', $todayEntry ? $todayEntry->title : '') }}"
                           placeholder="Contoh: Menemukan Ketenangan di Sepertiga Malam"
                           required
                           class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                </div>
            </div>

            <!-- Mood Selector -->
            <div>
                <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                    Kondisi Hati Hari Ini
                </label>
                @php
                    $currentMood = old('mood', $todayEntry ? $todayEntry->mood : 'bersyukur');
                    $moods = [
                        'bersyukur' => ['label' => '🌻 Sangat Bersyukur', 'color' => 'amber'],
                        'damai' => ['label' => '🕊️ Damai & Tenang', 'color' => 'blue'],
                        'bersemangat' => ['label' => '⚡ Penuh Semangat', 'color' => 'orange'],
                        'muhasabah' => ['label' => '🌱 Muhasabah Diri', 'color' => 'yellow'],
                        'butuh_doa' => ['label' => '🤲 Butuh Penguatan Doa', 'color' => 'rose'],
                    ];
                @endphp
                <div class="flex flex-wrap gap-2">
                    @foreach($moods as $mKey => $mVal)
                        <label class="cursor-pointer">
                            <input type="radio" name="mood" value="{{ $mKey }}"
                                   {{ $currentMood === $mKey ? 'checked' : '' }}
                                   class="sr-only peer">
                            <span class="inline-block px-3.5 py-2 rounded-xl text-xs font-bold border transition-all peer-checked:bg-amber-100 peer-checked:border-amber-500 peer-checked:text-amber-900 bg-slate-50 border-slate-200 text-slate-600 hover:bg-amber-50/60">
                                {{ $mVal['label'] }}
                            </span>
                        </label>
                    @endforeach
                </div>
            </div>

            <!-- 1. Catatan Harian Pribadi (Multi-line Spacious Textarea) -->
            <div>
                <label for="journal_content" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                    <span class="flex items-center gap-1.5">
                        <i data-lucide="book-open" class="w-3.5 h-3.5 text-amber-600"></i>
                        Catatan Jiwa & Muhasabah (Terenkripsi) <span class="text-rose-600">*</span>
                    </span>
                    <span class="text-[10px] text-slate-400 font-normal">Mendukung paragraf panjang multi-line</span>
                </label>
                <textarea id="journal_content" name="journal_content" rows="6" required
                          placeholder="Tuangkan isi hatimu secara bebas... Ceritakan bagaimana harimu berjalan, apa hikmah yang didapat, rasa lelah yang ingin diringankan, atau tekad baru untuk hari esok..."
                          class="w-full p-4 rounded-2xl bg-slate-50 border border-slate-200 text-sm leading-relaxed text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">{{ old('journal_content', $todayEntry ? $todayEntry->journal_content : '') }}</textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- 2. Tiga Hal yang Disyukuri (Multi-line Spacious Textarea) -->
                <div class="p-5 rounded-2xl bg-amber-50/70 border border-amber-200/90">
                    <label for="gratitude_notes" class="block text-xs font-bold text-amber-900 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                        <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-600"></i>
                        3 Hal yang Disyukuri Hari Ini
                    </label>
                    <p class="text-[11px] text-amber-800/80 mb-2.5">Tuliskan nikmat yang Allah hadirkan hari ini agar hati senantiasa cukup.</p>
                    <textarea id="gratitude_notes" name="gratitude_notes" rows="5"
                              placeholder="1. Masih diberikan nafas dan kesempatan sujud&#10;2. Bertemu teman yang mengingatkan kebaikan&#10;3. Nikmat sehat dan rezeki yang berkah"
                              class="w-full p-3.5 rounded-xl bg-white border border-amber-200 text-xs sm:text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all">{{ old('gratitude_notes', $todayEntry ? $todayEntry->gratitude_notes : '') }}</textarea>
                </div>

                <!-- 3. Memaafkan & Melepaskan Beban (Multi-line Spacious Textarea) -->
                <div class="p-5 rounded-2xl bg-orange-50/70 border border-orange-200/90">
                    <label for="forgiveness_reflection" class="block text-xs font-bold text-orange-900 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                        <i data-lucide="heart-handshake" class="w-3.5 h-3.5 text-orange-600"></i>
                        Memaafkan & Melepaskan Beban Hati
                    </label>
                    <p class="text-[11px] text-orange-800/80 mb-2.5">Bebaskan dada dari dendam, maafkan kekhilafan orang lain sebelum tidur.</p>
                    <textarea id="forgiveness_reflection" name="forgiveness_reflection" rows="5"
                              placeholder="Hari ini aku ikhlas memaafkan kata-kata atau perlakuan yang menyakiti... Aku pasrahkan segala urusan kepada Allah..."
                              class="w-full p-3.5 rounded-xl bg-white border border-orange-200 text-xs sm:text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all">{{ old('forgiveness_reflection', $todayEntry ? $todayEntry->forgiveness_reflection : '') }}</textarea>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                <div class="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <i data-lucide="shield" class="w-3.5 h-3.5 text-amber-600"></i>
                    Catatan otomatis dienkripsi sebelum disimpan di basis data.
                </div>
                <button type="submit"
                        class="w-full sm:w-auto px-7 py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2">
                    <i data-lucide="save" class="w-4 h-4"></i>
                    Simpan Jurnal & Refleksi Jiwa
                </button>
            </div>
        </form>
    </div>

    <!-- Past Journal Entries Grid -->
    <div>
        <div class="flex items-center justify-between mb-4">
            <div>
                <h2 class="text-lg font-bold text-slate-900">Arsip Catatan Jurnal Jiwa</h2>
                <p class="text-xs text-slate-400">Kumpulan perjalanan spiritual dan refleksi batin Anda</p>
            </div>
            <span class="text-xs font-bold px-3 py-1 rounded-full bg-slate-100 text-slate-700">
                Total {{ $entries->total() }} Catatan
            </span>
        </div>

        @if($entries->count() > 0)
            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                @foreach($entries as $entry)
                    <div class="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs hover:border-amber-300 transition-all flex flex-col justify-between group">
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <span class="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                                    <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                                    {{ $entry->date->translatedFormat('l, d F Y') }}
                                </span>
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 capitalize border border-amber-200">
                                    {{ $entry->mood ?? 'bersyukur' }}
                                </span>
                            </div>

                            <h3 class="text-base font-bold text-slate-800 mb-2 group-hover:text-amber-700 transition-colors">
                                {{ $entry->title }}
                            </h3>

                            <p class="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-4">
                                {{ $entry->journal_content }}
                            </p>

                            @if($entry->gratitude_notes)
                                <div class="p-3 bg-amber-50/80 rounded-xl border border-amber-200/80 mb-3 text-xs text-amber-900">
                                    <span class="font-bold flex items-center gap-1 mb-1 text-[11px]">
                                        <i data-lucide="sparkles" class="w-3 h-3 text-amber-600"></i> Syukur:
                                    </span>
                                    <p class="line-clamp-2 text-[11px] leading-relaxed">{{ $entry->gratitude_notes }}</p>
                                </div>
                            @endif
                        </div>

                        <!-- Footer Actions: Read, Export Quote, and Delete -->
                        <div class="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                            <a href="{{ route('journal.show', $entry->id) }}"
                               class="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1">
                                Baca Selengkapnya &rarr;
                            </a>

                            <div class="flex items-center gap-2">
                                <!-- Export Quote Button (Requirement #7) -->
                                <button type="button"
                                        onclick="openQuoteModal('{{ addslashes($entry->title) }}', '{{ addslashes($entry->gratitude_notes ?: $entry->journal_content) }}', '{{ $entry->date->translatedFormat('d F Y') }}')"
                                        class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold bg-amber-100/70 hover:bg-amber-100 text-amber-900 border border-amber-300 transition-colors"
                                        title="Ekspor Quote Estetik untuk Story/Status">
                                    <i data-lucide="share-2" class="w-3 h-3 text-amber-700"></i>
                                    Story Estetik
                                </button>

                                <form action="{{ route('journal.destroy', $entry->id) }}" method="POST"
                                      onsubmit="return confirm('Apakah Anda yakin ingin menghapus catatan jurnal tanggal ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors" title="Hapus Catatan">
                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="mt-6">
                {{ $entries->links() }}
            </div>
        @else
            <div class="p-12 bg-white rounded-3xl border border-dashed border-slate-200 text-center">
                <i data-lucide="feather" class="w-8 h-8 text-slate-300 mx-auto mb-2"></i>
                <p class="text-sm font-semibold text-slate-600">Belum ada catatan jurnal sebelumnya.</p>
                <p class="text-xs text-slate-400 mt-1">Gunakan form di atas untuk memulai tulisan pertamamu.</p>
            </div>
        @endif
    </div>

</div>

<!-- Modal: Export Quotes Estetik (Story / WA Status) - Requirement #7 -->
<div id="quoteModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm hidden">
    <div class="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 max-h-[95vh] overflow-y-auto">
        <div class="flex items-center justify-between pb-4 border-b border-slate-100">
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
                    <i data-lucide="image" class="w-4 h-4 text-amber-700"></i>
                </div>
                <div>
                    <h3 class="text-sm sm:text-base font-bold text-slate-900">Ekspor Quote Estetik (Story / Status)</h3>
                    <p class="text-[11px] text-slate-400">Siap dibagikan ke Instagram Story & WhatsApp</p>
                </div>
            </div>
            <button type="button" onclick="closeQuoteModal()" class="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="mt-4 space-y-4">
            <!-- Edit Quote Text -->
            <div>
                <label for="quoteTextInput" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Teks Kutipan / Refleksi
                </label>
                <textarea id="quoteTextInput" rows="3" oninput="renderCanvas()"
                          class="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea>
            </div>

            <!-- Theme Chooser -->
            <div class="flex items-center gap-2">
                <span class="text-xs font-bold text-slate-700">Pilih Tema:</span>
                <button type="button" onclick="setTheme('solar')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                    Matahari
                </button>
                <button type="button" onclick="setTheme('midnight')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-800 text-amber-400 border border-slate-700">
                    Malam & Emas
                </button>
                <button type="button" onclick="setTheme('emerald')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                    Hikmah Hijau
                </button>
            </div>

            <!-- Canvas Preview Container -->
            <div class="flex justify-center bg-slate-100 p-3 rounded-2xl border border-slate-200">
                <canvas id="quoteCanvas" width="540" height="960" class="max-h-[360px] w-auto rounded-xl shadow-md border border-slate-300/60"></canvas>
            </div>

            <!-- Actions -->
            <div class="flex items-center justify-between pt-2">
                <span class="text-[11px] text-slate-400 flex items-center gap-1">
                    <i data-lucide="award" class="w-3.5 h-3.5 text-amber-500"></i>
                    Watermark otomatis disertakan
                </span>
                <div class="flex items-center gap-2">
                    <button type="button" onclick="closeQuoteModal()" class="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 border border-slate-200">
                        Batal
                    </button>
                    <button type="button" onclick="downloadQuoteImage()"
                            class="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/25 flex items-center gap-1.5">
                        <i data-lucide="download" class="w-4 h-4"></i>
                        Unduh Gambar (PNG)
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    let currentTheme = 'solar';
    let currentTitle = '';
    let currentDate = '';

    function openQuoteModal(title, text, date) {
        currentTitle = title;
        currentDate = date;
        document.getElementById('quoteTextInput').value = text;
        document.getElementById('quoteModal').classList.remove('hidden');
        renderCanvas();
    }

    function closeQuoteModal() {
        document.getElementById('quoteModal').classList.add('hidden');
    }

    function setTheme(theme) {
        currentTheme = theme;
        renderCanvas();
    }

    function renderCanvas() {
        const canvas = document.getElementById('quoteCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        const text = document.getElementById('quoteTextInput').value || 'Maka sesungguhnya bersama kesulitan ada kemudahan.';

        // Background Gradient
        let bgGrad;
        if (currentTheme === 'midnight') {
            bgGrad = ctx.createLinearGradient(0, 0, width, height);
            bgGrad.addColorStop(0, '#020617');
            bgGrad.addColorStop(0.5, '#0f172a');
            bgGrad.addColorStop(1, '#1e1b4b');
        } else if (currentTheme === 'emerald') {
            bgGrad = ctx.createLinearGradient(0, 0, width, height);
            bgGrad.addColorStop(0, '#064e3b');
            bgGrad.addColorStop(0.5, '#047857');
            bgGrad.addColorStop(1, '#065f46');
        } else {
            // Solar Gradient
            bgGrad = ctx.createLinearGradient(0, 0, width, height);
            bgGrad.addColorStop(0, '#78350f');
            bgGrad.addColorStop(0.3, '#d97706');
            bgGrad.addColorStop(0.7, '#f59e0b');
            bgGrad.addColorStop(1, '#fbbf24');
        }
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);

        // Decorative background sun glow
        ctx.beginPath();
        ctx.arc(width / 2, 220, 260, 0, Math.PI * 2);
        ctx.fillStyle = currentTheme === 'midnight' ? 'rgba(251, 191, 36, 0.08)' : 'rgba(255, 255, 255, 0.12)';
        ctx.fill();

        // Inner Card Glassmorphism
        const cardX = 40;
        const cardY = 160;
        const cardW = width - 80;
        const cardH = height - 360;
        const radius = 24;

        ctx.save();
        ctx.beginPath();
        ctx.roundRect(cardX, cardY, cardW, cardH, radius);
        ctx.fillStyle = currentTheme === 'midnight' ? 'rgba(15, 23, 42, 0.75)' : 'rgba(255, 255, 255, 0.88)';
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = currentTheme === 'midnight' ? 'rgba(245, 158, 11, 0.3)' : 'rgba(255, 255, 255, 0.9)';
        ctx.stroke();
        ctx.restore();

        // Decorative quote mark
        ctx.fillStyle = currentTheme === 'midnight' ? '#f59e0b' : '#d97706';
        ctx.font = 'bold 72px "Plus Jakarta Sans", serif';
        ctx.textAlign = 'left';
        ctx.fillText('“', cardX + 30, cardY + 70);

        // Date & Tag
        ctx.fillStyle = currentTheme === 'midnight' ? '#94a3b8' : '#64748b';
        ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText((currentDate || 'Hari Ini') + ' • Refleksi Jiwa', cardX + 90, cardY + 50);

        // Quote Text with word wrap
        ctx.fillStyle = currentTheme === 'midnight' ? '#f8fafc' : '#0f172a';
        ctx.font = 'italic 600 23px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';

        const maxTextWidth = cardW - 60;
        const words = text.split(/\s+/);
        let line = '';
        const lines = [];

        for (let i = 0; i < words.length; i++) {
            const testLine = line + words[i] + ' ';
            const metrics = ctx.measureText(testLine);
            if (metrics.width > maxTextWidth && i > 0) {
                lines.push(line);
                line = words[i] + ' ';
            } else {
                line = testLine;
            }
        }
        lines.push(line);

        const lineHeight = 36;
        const totalTextHeight = lines.length * lineHeight;
        let startY = cardY + (cardH / 2) - (totalTextHeight / 2) + 20;

        // Cap lines if very long
        const maxLines = 10;
        lines.slice(0, maxLines).forEach(function (l) {
            ctx.fillText(l.trim(), width / 2, startY);
            startY += lineHeight;
        });

        // Author / User signature inside card
        ctx.fillStyle = currentTheme === 'midnight' ? '#fbbf24' : '#b45309';
        ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('— ' + (currentTitle || 'Catatan Muhasabah'), width / 2, cardY + cardH - 35);

        // Bottom Watermark (Requirement #7):
        // Sunnah Bloom × RQ Al-Izzah Cab. Singkawang
        ctx.fillStyle = currentTheme === 'midnight' ? '#fbbf24' : '#ffffff';
        ctx.font = 'bold 18px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Sunnah Bloom × RQ Al-Izzah Cab. Singkawang', width / 2, height - 110);

        ctx.fillStyle = currentTheme === 'midnight' ? '#cbd5e1' : '#fffbeb';
        ctx.font = '500 13px "Plus Jakarta Sans", sans-serif';
        ctx.fillText('Platform Digital Amalan Yaumi & Muhasabah Diri', width / 2, height - 85);
    }

    function downloadQuoteImage() {
        const canvas = document.getElementById('quoteCanvas');
        if (!canvas) return;

        // Render in high resolution 1080x1920 for download
        const exportCanvas = document.createElement('canvas');
        exportCanvas.width = 1080;
        exportCanvas.height = 1920;
        const expCtx = exportCanvas.getContext('2d');

        // Scale 2x
        expCtx.scale(2, 2);

        // Re-render at 540x960 logical coordinates onto exportCanvas
        const oldCanvas = document.getElementById('quoteCanvas');
        expCtx.drawImage(oldCanvas, 0, 0);

        const link = document.createElement('a');
        link.download = `SunnahBloom_Quote_${Date.now()}.png`;
        link.href = exportCanvas.toDataURL('image/png');
        link.click();
    }
</script>
@endpush
@endsection

@extends('layouts.app')

@section('title', $entry->title . ' — Jurnal Pribadi Sunnah Bloom')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">

    <!-- Top Navigation & Actions -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <a href="{{ route('journal.index') }}"
           class="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 hover:text-amber-700 transition-colors">
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            Kembali ke Semua Jurnal
        </a>

        <div class="flex items-center gap-2.5">
            <!-- Export Quote / Story Button (Requirement #7) -->
            <button type="button"
                    onclick="openQuoteModal('{{ addslashes($entry->title) }}', '{{ addslashes($entry->gratitude_notes ?: $entry->journal_content) }}', '{{ $entry->date->translatedFormat('d F Y') }}')"
                    class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 transition-colors shadow-2xs">
                <i data-lucide="share-2" class="w-3.5 h-3.5 text-amber-700"></i>
                Ekspor Story Estetik
            </button>

            <!-- Delete Form -->
            <form action="{{ route('journal.destroy', $entry->id) }}" method="POST"
                  onsubmit="return confirm('Apakah Anda yakin ingin menghapus catatan jurnal ini secara permanen?');">
                @csrf
                @method('DELETE')
                <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 transition-colors">
                    <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                    Hapus
                </button>
            </form>
        </div>
    </div>

    <!-- Main Detail Article Card -->
    <article class="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200/90 shadow-sm space-y-8">
        <!-- Header -->
        <div class="border-b border-slate-100 pb-6">
            <div class="flex flex-wrap items-center gap-3 mb-3">
                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-900 border border-amber-200">
                    <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                    {{ $entry->date->translatedFormat('l, d F Y') }}
                </span>
                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 capitalize border border-amber-200">
                    Mood: {{ $entry->mood ?? 'bersyukur' }}
                </span>
                <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                    <i data-lucide="lock" class="w-3 h-3 text-slate-500"></i>
                    Terenkripsi AES-256
                </span>
                <span class="ml-auto text-[11px] text-slate-400 font-medium">
                    Ditulis pada {{ $entry->created_at->format('H:i') }} WIB
                </span>
            </div>

            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-snug">
                {{ $entry->title }}
            </h1>
        </div>

        <!-- Main Narrative Content -->
        <div>
            <h2 class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Catatan Perjalanan & Muhasabah Jiwa</h2>
            <div class="prose prose-slate max-w-none text-slate-700 leading-relaxed whitespace-pre-line text-sm sm:text-base">
                {{ $entry->journal_content }}
            </div>
        </div>

        <!-- Gratitude Callout -->
        @if($entry->gratitude_notes)
            <div class="p-6 rounded-2xl bg-amber-50/70 border border-amber-200">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-2">
                        <i data-lucide="sparkles" class="w-4 h-4 text-amber-600"></i>
                        3 Hal yang Disyukuri Hari Ini
                    </h3>
                    <button type="button"
                            onclick="openQuoteModal('Rasa Syukur Hari Ini', '{{ addslashes($entry->gratitude_notes) }}', '{{ $entry->date->translatedFormat('d F Y') }}')"
                            class="text-[11px] font-bold text-amber-700 hover:text-amber-900 flex items-center gap-1">
                        <i data-lucide="share-2" class="w-3 h-3"></i> Jadikan Story
                    </button>
                </div>
                <div class="text-xs sm:text-sm text-amber-950/90 leading-relaxed whitespace-pre-line">
                    {{ $entry->gratitude_notes }}
                </div>
            </div>
        @endif

        <!-- Forgiveness Callout -->
        @if($entry->forgiveness_reflection)
            <div class="p-6 rounded-2xl bg-orange-50/70 border border-orange-200">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-xs font-bold text-orange-900 uppercase tracking-wider flex items-center gap-2">
                        <i data-lucide="heart-handshake" class="w-4 h-4 text-orange-600"></i>
                        Memaafkan & Melepaskan Beban Hati
                    </h3>
                    <button type="button"
                            onclick="openQuoteModal('Melepaskan Beban Jiwa', '{{ addslashes($entry->forgiveness_reflection) }}', '{{ $entry->date->translatedFormat('d F Y') }}')"
                            class="text-[11px] font-bold text-orange-700 hover:text-orange-900 flex items-center gap-1">
                        <i data-lucide="share-2" class="w-3 h-3"></i> Jadikan Story
                    </button>
                </div>
                <div class="text-xs sm:text-sm text-orange-950/90 leading-relaxed whitespace-pre-line">
                    {{ $entry->forgiveness_reflection }}
                </div>
            </div>
        @endif

        <!-- Privacy Footer -->
        <div class="pt-6 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-400">
            <i data-lucide="shield-check" class="w-4 h-4 text-amber-600"></i>
            <span>Catatan ini disimpan secara terenkripsi AES-256 dan hanya dapat dibaca oleh Anda.</span>
        </div>
    </article>

</div>

<!-- Modal: Export Quotes Estetik (Story / WA Status) - Requirement #7 -->
<div id="quoteModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm hidden">
    <div class="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 max-h-[95vh] overflow-y-auto">
        <div class="flex items-center justify-between pb-4 border-b border-slate-100">
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
                    <i data-lucide="image" class="w-4 h-4 text-amber-700"></i>
                </div>
                <div>
                    <h3 class="text-sm sm:text-base font-bold text-slate-900">Ekspor Quote Estetik (Story / Status)</h3>
                    <p class="text-[11px] text-slate-400">Siap dibagikan ke Instagram Story & WhatsApp</p>
                </div>
            </div>
            <button type="button" onclick="closeQuoteModal()" class="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="mt-4 space-y-4">
            <!-- Edit Quote Text -->
            <div>
                <label for="quoteTextInput" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Teks Kutipan / Refleksi
                </label>
                <textarea id="quoteTextInput" rows="3" oninput="renderCanvas()"
                          class="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea>
            </div>

            <!-- Theme Chooser -->
            <div class="flex items-center gap-2">
                <span class="text-xs font-bold text-slate-700">Pilih Tema:</span>
                <button type="button" onclick="setTheme('solar')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                    Matahari
                </button>
                <button type="button" onclick="setTheme('midnight')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-800 text-amber-400 border border-slate-700">
                    Malam & Emas
                </button>
                <button type="button" onclick="setTheme('emerald')" class="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                    Hikmah Hijau
                </button>
            </div>

            <!-- Canvas Preview Container -->
            <div class="flex justify-center bg-slate-100 p-3 rounded-2xl border border-slate-200">
                <canvas id="quoteCanvas" width="540" height="960" class="max-h-[360px] w-auto rounded-xl shadow-md border border-slate-300/60"></canvas>
            </div>

            <!-- Actions -->
            <div class="flex items-center justify-between pt-2">
                <span class="text-[11px] text-slate-400 flex items-center gap-1">
                    <i data-lucide="award" class="w-3.5 h-3.5 text-amber-500"></i>
                    Watermark otomatis disertakan
                </span>
                <div class="flex items-center gap-2">
                    <button type="button" onclick="closeQuoteModal()" class="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 border border-slate-200">
                        Batal
                    </button>
                    <button type="button" onclick="downloadQuoteImage()"
                            class="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/25 flex items-center gap-1.5">
                        <i data-lucide="download" class="w-4 h-4"></i>
                        Unduh Gambar (PNG)
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    let currentTheme = 'solar';
    let currentTitle = '';
    let currentDate = '';

    function openQuoteModal(title, text, date) {
        currentTitle = title;
        currentDate = date;
        document.getElementById('quoteTextInput').value = text;
        document.getElementById('quoteModal').classList.remove('hidden');
        renderCanvas();
    }

    function closeQuoteModal() {
        document.getElementById('quoteModal').classList.add('hidden');
    }

    function setTheme(theme) {
        currentTheme = theme;
        renderCanvas();
    }

    function renderCanvas() {
        const canvas = document.getElementById('quoteCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        const text = document.getElementById('quoteTextInput').value || 'Maka sesungguhnya bersama kesulitan ada kemudahan.';

        // Background Gradient
        let bgGrad;
        if (currentTheme === 'midnight') {
            bgGrad = ctx.createLinearGradient(0, 0, width, height);
            bgGrad.addColorStop(0, '#020617');
            bgGrad.addColorStop(0.5, '#0f172a');
            bgGrad.addColorStop(1, '#1e1b4b');
        } else if (currentTheme === 'emerald') {
            bgGrad = ctx.createLinearGradient(0, 0, width, height);
            bgGrad.addColorStop(0, '#064e3b');
            bgGrad.addColorStop(0.5, '#047857');
            bgGrad.addColorStop(1, '#065f46');
        } else {
            // Solar Gradient
            bgGrad = ctx.createLinearGradient(0, 0, width, height);
            bgGrad.addColorStop(0, '#78350f');
            bgGrad.addColorStop(0.3, '#d97706');
            bgGrad.addColorStop(0.7, '#f59e0b');
            bgGrad.addColorStop(1, '#fbbf24');
        }
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);

        // Decorative background sun glow
        ctx.beginPath();
        ctx.arc(width / 2, 220, 260, 0, Math.PI * 2);
        ctx.fillStyle = currentTheme === 'midnight' ? 'rgba(251, 191, 36, 0.08)' : 'rgba(255, 255, 255, 0.12)';
        ctx.fill();

        // Inner Card Glassmorphism
        const cardX = 40;
        const cardY = 160;
        const cardW = width - 80;
        const cardH = height - 360;
        const radius = 24;

        ctx.save();
        ctx.beginPath();
        ctx.roundRect(cardX, cardY, cardW, cardH, radius);
        ctx.fillStyle = currentTheme === 'midnight' ? 'rgba(15, 23, 42, 0.75)' : 'rgba(255, 255, 255, 0.88)';
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = currentTheme === 'midnight' ? 'rgba(245, 158, 11, 0.3)' : 'rgba(255, 255, 255, 0.9)';
        ctx.stroke();
        ctx.restore();

        // Decorative quote mark
        ctx.fillStyle = currentTheme === 'midnight' ? '#f59e0b' : '#d97706';
        ctx.font = 'bold 72px "Plus Jakarta Sans", serif';
        ctx.textAlign = 'left';
        ctx.fillText('“', cardX + 30, cardY + 70);

        // Date & Tag
        ctx.fillStyle = currentTheme === 'midnight' ? '#94a3b8' : '#64748b';
        ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText((currentDate || 'Hari Ini') + ' • Refleksi Jiwa', cardX + 90, cardY + 50);

        // Quote Text with word wrap
        ctx.fillStyle = currentTheme === 'midnight' ? '#f8fafc' : '#0f172a';
        ctx.font = 'italic 600 23px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';

        const maxTextWidth = cardW - 60;
        const words = text.split(/\s+/);
        let line = '';
        const lines = [];

        for (let i = 0; i < words.length; i++) {
            const testLine = line + words[i] + ' ';
            const metrics = ctx.measureText(testLine);
            if (metrics.width > maxTextWidth && i > 0) {
                lines.push(line);
                line = words[i] + ' ';
            } else {
                line = testLine;
            }
        }
        lines.push(line);

        const lineHeight = 36;
        const totalTextHeight = lines.length * lineHeight;
        let startY = cardY + (cardH / 2) - (totalTextHeight / 2) + 20;

        // Cap lines if very long
        const maxLines = 10;
        lines.slice(0, maxLines).forEach(function (l) {
            ctx.fillText(l.trim(), width / 2, startY);
            startY += lineHeight;
        });

        // Author / User signature inside card
        ctx.fillStyle = currentTheme === 'midnight' ? '#fbbf24' : '#b45309';
        ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('— ' + (currentTitle || 'Catatan Muhasabah'), width / 2, cardY + cardH - 35);

        // Bottom Watermark (Requirement #7):
        // Sunnah Bloom × RQ Al-Izzah Cab. Singkawang
        ctx.fillStyle = currentTheme === 'midnight' ? '#fbbf24' : '#ffffff';
        ctx.font = 'bold 18px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Sunnah Bloom × RQ Al-Izzah Cab. Singkawang', width / 2, height - 110);

        ctx.fillStyle = currentTheme === 'midnight' ? '#cbd5e1' : '#fffbeb';
        ctx.font = '500 13px "Plus Jakarta Sans", sans-serif';
        ctx.fillText('Platform Digital Amalan Yaumi & Muhasabah Diri', width / 2, height - 85);
    }

    function downloadQuoteImage() {
        const canvas = document.getElementById('quoteCanvas');
        if (!canvas) return;

        // Render in high resolution 1080x1920 for download
        const exportCanvas = document.createElement('canvas');
        exportCanvas.width = 1080;
        exportCanvas.height = 1920;
        const expCtx = exportCanvas.getContext('2d');

        // Scale 2x
        expCtx.scale(2, 2);

        // Re-render at 540x960 logical coordinates onto exportCanvas
        const oldCanvas = document.getElementById('quoteCanvas');
        expCtx.drawImage(oldCanvas, 0, 0);

        const link = document.createElement('a');
        link.download = `SunnahBloom_Quote_${Date.now()}.png`;
        link.href = exportCanvas.toDataURL('image/png');
        link.click();
    }
</script>
@endpush
@endsection

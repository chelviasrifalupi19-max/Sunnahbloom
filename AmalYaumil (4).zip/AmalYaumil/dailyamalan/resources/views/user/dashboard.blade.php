@extends('layouts.app')

@section('title', 'Beranda Pengguna — Amalan Yaumi')

@section('content')
<div class="space-y-8">

    <!-- Welcome Greeting Hero -->
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-950 via-stone-900 to-orange-950 text-white p-6 sm:p-10 shadow-xl border border-amber-600/50">
        <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-900/60 border border-amber-500/40 text-amber-200 text-xs font-semibold mb-3">
                    <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                    {{ \Carbon\Carbon::today()->translatedFormat('l, d F Y') }}
                </div>
                <h1 class="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-2">
                    Assalamu'alaikum, {{ $user->name }} ☀️
                </h1>
                <p class="text-sm sm:text-base text-amber-100/90 max-w-xl font-normal">
                    {{ $appSettings['daily_quote'] ?? '"Dan barangsiapa yang bertakwa kepada Allah, niscaya Dia menjadikan kemudahan dalam urusannya." (QS. At-Talaq: 4)' }}
                </p>
            </div>

            <!-- Quick Action Button -->
            <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <a href="{{ route('amalan.index') }}"
                   class="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]">
                    <i data-lucide="check-circle-2" class="w-5 h-5 text-slate-950"></i>
                    <span>Isi Amalan Hari Ini</span>
                </a>
                <a href="{{ route('journal.index') }}"
                   class="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm border border-white/20 backdrop-blur-md transition-all">
                    <i data-lucide="pen-tool" class="w-4 h-4 text-amber-300"></i>
                    <span>Tulis Jurnal</span>
                </a>
            </div>
        </div>
    </div>

    <!-- 4 Stats Cards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <!-- Streak Card -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Istiqomah Streak</span>
                <div class="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                    <i data-lucide="flame" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $streak }}</span>
                <span class="text-xs font-semibold text-slate-500">Hari Berturut-turut</span>
            </div>
            <p class="text-[11px] text-slate-400 mt-2">
                {{ $streak > 0 ? 'Pertahankan ritme ibadahmu!' : 'Mulai istiqomah hari ini!' }}
            </p>
        </div>

        <!-- Today's Rate Card -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Capaian Hari Ini</span>
                <div class="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                    <i data-lucide="sun" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold {{ $todayAmalan->completion_rate >= 80 ? 'text-amber-600' : 'text-slate-900' }}">
                    {{ $todayAmalan->completion_rate }}%
                </span>
                <span class="text-xs font-semibold text-slate-500">
                    ({{ $todayAmalan->completedCount() }}/{{ count(\App\Models\DailyAmalan::AMALAN_KEYS) }} Amalan)
                </span>
            </div>
            <div class="w-full bg-slate-100 rounded-full h-2 mt-3 overflow-hidden">
                <div class="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 h-2 rounded-full transition-all duration-500"
                     style="width: {{ $todayAmalan->completion_rate }}%"></div>
            </div>
        </div>

        <!-- Overall Average Card -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Rata-Rata Capaian</span>
                <div class="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                    <i data-lucide="trending-up" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $avgPercentage }}%</span>
                <span class="text-xs font-semibold text-slate-500">Kepatuhan</span>
            </div>
            <p class="text-[11px] text-slate-400 mt-2">Dihitung dari semua hari mutaba'ah</p>
        </div>

        <!-- Total Days Card -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Riwayat Tercatat</span>
                <div class="w-9 h-9 rounded-xl bg-yellow-50 text-yellow-700 flex items-center justify-center font-bold">
                    <i data-lucide="calendar" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $totalDays }}</span>
                <span class="text-xs font-semibold text-slate-500">Hari Disimpan</span>
            </div>
            <p class="text-[11px] text-slate-400 mt-2">{{ $totalJournals }} Catatan Jurnal Ditulis</p>
        </div>
    </div>

    <!-- 7-Day Trend Visual & Today's Checklist Quick View -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- 7-Days Chart / Bar Card -->
        <div class="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs flex flex-col justify-between">
            <div>
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Perkembangan 7 Hari Terakhir</h2>
                        <p class="text-xs text-slate-500">Visualisasi capaian mutaba'ah sepekan</p>
                    </div>
                    <a href="{{ route('progress.index') }}" class="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1">
                        Lihat Grafik Lengkap
                        <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </a>
                </div>

                <!-- 7 Bars Chart -->
                <div class="grid grid-cols-7 gap-2 sm:gap-4 items-end h-44 pt-4 pb-2 border-b border-slate-100">
                    @foreach($last7Days as $item)
                        <div class="flex flex-col items-center gap-2 h-full justify-end group">
                            <!-- Rate tooltip on hover -->
                            <span class="text-[10px] font-bold {{ $item['is_today'] ? 'text-amber-700' : 'text-slate-500' }} group-hover:scale-110 transition-transform">
                                {{ $item['rate'] }}%
                            </span>

                            <!-- Bar -->
                            <div class="w-full max-w-[40px] bg-slate-100 rounded-t-lg overflow-hidden flex flex-col justify-end h-28 relative">
                                <div class="w-full rounded-t-lg transition-all duration-500 {{ $item['is_today'] ? 'bg-gradient-to-t from-amber-600 via-amber-500 to-yellow-400' : ($item['rate'] >= 75 ? 'bg-amber-500' : ($item['rate'] > 0 ? 'bg-amber-300' : 'bg-slate-200')) }}"
                                     style="height: {{ max($item['rate'], 6) }}%">
                                </div>
                            </div>

                            <!-- Label -->
                            <div class="text-center">
                                <p class="text-[11px] font-bold {{ $item['is_today'] ? 'text-amber-700 font-extrabold' : 'text-slate-700' }}">
                                    {{ $item['day'] }}
                                </p>
                                <p class="text-[9px] text-slate-400">{{ $item['date'] }}</p>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="mt-4 pt-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
                <div class="flex items-center gap-4">
                    <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Baik (≥75%)</span>
                    <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-300"></span> Sedang</span>
                    <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-slate-300"></span> Belum Diisi</span>
                </div>
                <span class="text-[11px] text-slate-400">Diperbarui otomatis secara real-time</span>
            </div>
        </div>

        <!-- Latest Journal & Spiritual Reflection Card -->
        <div class="bg-gradient-to-br from-amber-50/70 to-white rounded-3xl p-6 sm:p-7 border border-amber-200/80 shadow-xs flex flex-col justify-between">
            <div>
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                            <i data-lucide="book-heart" class="w-4 h-4"></i>
                        </div>
                        <h2 class="text-base font-bold text-slate-900">Jurnal Syukur Terakhir</h2>
                    </div>
                    <span class="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                        🔒 Rahasia
                    </span>
                </div>

                @if($latestJournal)
                    <div class="p-4 bg-white rounded-2xl border border-amber-200/80 shadow-2xs space-y-2 mb-4">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-semibold text-slate-400">
                                {{ $latestJournal->date->translatedFormat('d F Y') }}
                            </span>
                            <span class="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold capitalize">
                                {{ $latestJournal->mood ?? 'bersyukur' }}
                            </span>
                        </div>
                        <h3 class="text-sm font-bold text-slate-800 line-clamp-1">
                            {{ $latestJournal->title }}
                        </h3>
                        <p class="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                            {{ $latestJournal->journal_content }}
                        </p>
                    </div>
                @else
                    <div class="p-6 bg-white/80 rounded-2xl border border-dashed border-amber-300 text-center space-y-2 mb-4">
                        <i data-lucide="sun" class="w-6 h-6 text-amber-400 mx-auto"></i>
                        <p class="text-xs text-slate-600 font-medium">Belum ada catatan jurnal yang tersimpan.</p>
                        <p class="text-[11px] text-slate-400">Tuliskan 3 nikmat yang disyukuri hari ini untuk menenangkan hati.</p>
                    </div>
                @endif
            </div>

            <div class="pt-2">
                <a href="{{ route('journal.index') }}"
                   class="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-amber-500 hover:text-slate-950 text-amber-800 font-bold text-xs border border-amber-300 shadow-2xs transition-all flex items-center justify-center gap-2">
                    <i data-lucide="pen-tool" class="w-3.5 h-3.5"></i>
                    Buka Halaman Jurnal Syukur &rarr;
                </a>
            </div>
        </div>

    </div>

</div>
@endsection

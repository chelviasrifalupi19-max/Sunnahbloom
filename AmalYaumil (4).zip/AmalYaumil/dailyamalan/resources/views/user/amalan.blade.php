@extends('layouts.app')

@section('title', 'Catat Amalan Yaumi — Sunnah Bloom')

@section('content')
<div class="max-w-4xl mx-auto space-y-6">

    <!-- Top Date Navigation & Header -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <div class="inline-flex items-center gap-2 text-xs font-bold text-amber-600 uppercase tracking-wider mb-1">
                    <i data-lucide="sun" class="w-4 h-4 text-amber-500"></i>
                    Mutaba'ah Yaumiyah
                </div>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    Catatan Amalan Harian
                </h1>
                <p class="text-xs sm:text-sm text-slate-500 mt-1">
                    Centang ibadah yang telah Anda tunaikan dengan jujur demi muhasabah diri.
                </p>
            </div>

            <!-- Action Buttons & Date Switcher -->
            <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                <!-- Add Custom Amalan Button -->
                <button type="button"
                        onclick="openAddCustomModal()"
                        class="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-xs transition-all shadow-2xs">
                    <i data-lucide="plus-circle" class="w-4 h-4 text-amber-600"></i>
                    Tambah Amalan Pribadi
                </button>

                <!-- Date Switcher Controls -->
                <div class="flex items-center gap-1.5 justify-between">
                    <a href="{{ route('amalan.index', ['date' => $selectedDate->copy()->subDay()->toDateString()]) }}"
                       class="p-2 rounded-xl border border-slate-200 hover:bg-amber-50/60 text-slate-600 transition-colors"
                       title="Hari Sebelumnya">
                        <i data-lucide="chevron-left" class="w-4 h-4"></i>
                    </a>

                    <form method="GET" action="{{ route('amalan.index') }}" class="flex items-center">
                        <input type="date" name="date" value="{{ $selectedDate->toDateString() }}"
                               onchange="this.form.submit()"
                               class="px-3 py-1.5 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-700 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-amber-500">
                    </form>

                    <a href="{{ route('amalan.index', ['date' => $selectedDate->copy()->addDay()->toDateString()]) }}"
                       class="p-2 rounded-xl border border-slate-200 hover:bg-amber-50/60 text-slate-600 transition-colors"
                       title="Hari Berikutnya">
                        <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </a>

                    @if(!$selectedDate->isToday())
                        <a href="{{ route('amalan.index', ['date' => \Carbon\Carbon::today()->toDateString()]) }}"
                           class="px-2.5 py-1.5 rounded-xl bg-amber-100 text-amber-900 hover:bg-amber-200 text-xs font-bold transition-colors">
                            Hari Ini
                        </a>
                    @endif
                </div>
            </div>
        </div>

        <!-- Live Progress Banner -->
        <div class="mt-6 pt-6 border-t border-slate-100">
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-2">
                    <span class="text-xs font-bold text-slate-700">Tingkat Capaian Tanggal Ini:</span>
                    <span id="completion-text" class="text-xs font-bold text-amber-700">
                        {{ $amalan->completedCount() }} dari {{ count($keys) }} Amalan Selesai
                    </span>
                </div>
                <span id="rate-badge" class="px-2.5 py-1 rounded-full text-xs font-extrabold bg-amber-100 text-amber-900">
                    <span id="rate-percentage">{{ $amalan->completion_rate }}</span>%
                </span>
            </div>
            <div class="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                <div id="progress-bar"
                     class="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 h-3 rounded-full transition-all duration-300"
                     style="width: {{ $amalan->completion_rate }}%">
                </div>
            </div>
        </div>
    </div>

    <!-- Main Checklist Form -->
    <form action="{{ route('amalan.save') }}" method="POST" id="amalan-form">
        @csrf
        <input type="hidden" name="date" value="{{ $selectedDate->toDateString() }}">

        <div class="space-y-6">
            @foreach($categories as $catKey => $category)
                @php
                    $itemsInThisCat = array_filter($keys, fn($it) => $it['category'] === $catKey);
                @endphp

                @if(count($itemsInThisCat) > 0)
                    <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
                        <!-- Category Header -->
                        <div class="flex items-center justify-between mb-5 pb-3 border-b border-slate-100">
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 rounded-lg bg-amber-100 text-amber-900 font-bold flex items-center justify-center">
                                    @if($catKey === 'wajib')
                                        <i data-lucide="compass" class="w-4 h-4"></i>
                                    @elseif($catKey === 'sunnah')
                                        <i data-lucide="sun" class="w-4 h-4"></i>
                                    @elseif($catKey === 'quran')
                                        <i data-lucide="book-open" class="w-4 h-4"></i>
                                    @elseif($catKey === 'dzikir')
                                        <i data-lucide="shield-check" class="w-4 h-4"></i>
                                    @elseif($catKey === 'kebaikan')
                                        <i data-lucide="heart" class="w-4 h-4"></i>
                                    @else
                                        <i data-lucide="sparkles" class="w-4 h-4"></i>
                                    @endif
                                </div>
                                <h2 class="text-base sm:text-lg font-bold text-slate-800">{{ $category['title'] }}</h2>
                            </div>
                            <span class="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                                {{ $category['badge'] }}
                            </span>
                        </div>

                        <!-- Items Checklist Grid -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                            @foreach($itemsInThisCat as $itemKey => $item)
                                @php
                                    $checked = $amalan->isChecked($itemKey);
                                    $isCustom = !empty($item['is_custom']);
                                @endphp
                                <div id="card-{{ $itemKey }}"
                                     class="flex items-center justify-between p-3.5 rounded-2xl border transition-all amalan-card {{ $checked ? 'bg-amber-50/90 border-amber-300 text-amber-950 shadow-2xs font-semibold' : 'bg-slate-50/60 border-slate-200 text-slate-700 hover:bg-amber-50/40' }}">

                                    <label for="check-{{ $itemKey }}" class="flex items-center gap-3 cursor-pointer select-none min-w-0 flex-1">
                                        <input type="checkbox"
                                               name="{{ $itemKey }}"
                                               id="check-{{ $itemKey }}"
                                               value="1"
                                               {{ $checked ? 'checked' : '' }}
                                               onchange="updateAmalanCard('{{ $itemKey }}')"
                                               class="w-5 h-5 rounded-md text-amber-500 border-slate-300 focus:ring-amber-500 amalan-checkbox shrink-0">
                                        <div class="min-w-0 flex-1">
                                            <p class="text-xs font-bold leading-snug truncate">{{ $item['label'] }}</p>
                                            @if($isCustom)
                                                <span class="inline-block text-[9px] font-bold text-amber-700 bg-amber-100/80 px-1.5 py-0.2 rounded mt-0.5">
                                                    Pribadi
                                                </span>
                                            @endif
                                        </div>
                                    </label>

                                    <!-- Action buttons for user's personal custom amalan -->
                                    @if($isCustom && !empty($item['id']))
                                        <div class="flex items-center gap-1 ml-2 shrink-0">
                                            <button type="button"
                                                    onclick="event.stopPropagation(); openEditCustomModal({{ $item['id'] }}, '{{ addslashes($item['label']) }}', '{{ $item['category'] }}', '{{ $item['icon'] }}')"
                                                    title="Edit Amalan Pribadi"
                                                    class="p-1 rounded-md text-slate-400 hover:text-amber-700 hover:bg-amber-100/60 transition-colors">
                                                <i data-lucide="edit-2" class="w-3.5 h-3.5"></i>
                                            </button>
                                            <button type="button"
                                                    onclick="event.stopPropagation(); confirmDeleteCustomModal({{ $item['id'] }}, '{{ addslashes($item['label']) }}')"
                                                    title="Hapus Amalan Pribadi"
                                                    class="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors">
                                                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                            </button>
                                        </div>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif
            @endforeach

            <!-- Notes Section -->
            <div class="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
                <div class="flex items-center gap-2 mb-3">
                    <i data-lucide="message-square" class="w-4 h-4 text-amber-600"></i>
                    <label for="notes" class="text-sm font-bold text-slate-800">
                        Catatan & Evaluasi Amalan Hari Ini (Opsional)
                    </label>
                </div>
                <textarea id="notes" name="notes" rows="3"
                          placeholder="Tuliskan evaluasi amalan, kendala ibadah hari ini, atau target perbaikan esok hari..."
                          class="w-full p-4 rounded-2xl bg-slate-50 border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all">{{ old('notes', $amalan->notes) }}</textarea>
            </div>

            <!-- Sticky / Action Save Bar -->
            <div class="sticky bottom-6 z-20 bg-white/95 backdrop-blur-md p-4 rounded-2xl border border-amber-200/80 shadow-xl flex items-center justify-between gap-4">
                <div class="hidden sm:block text-xs text-slate-500">
                    <span class="font-bold text-slate-700">Tanggal:</span> {{ $selectedDate->translatedFormat('d F Y') }}
                </div>
                <button type="submit"
                        class="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]">
                    <i data-lucide="save" class="w-4 h-4"></i>
                    Simpan Amalan Tanggal Ini
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Modal: Tambah Amalan Pribadi -->
<div id="addCustomModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
    <div class="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div class="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                <i data-lucide="plus-circle" class="w-4 h-4 text-amber-600"></i>
                Tambah Amalan Kustom Anda
            </h3>
            <button type="button" onclick="closeAddCustomModal()" class="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form action="{{ route('amalan.custom.store') }}" method="POST" class="mt-4 space-y-4">
            @csrf

            <div>
                <label for="add_label" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Nama Amalan <span class="text-rose-600">*</span>
                </label>
                <input type="text" id="add_label" name="label" required placeholder="Contoh: Baca Surat Al-Waqi'ah / Olahraga 15 Menit"
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
                <label for="add_category" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Kategori Amalan <span class="text-rose-600">*</span>
                </label>
                <select id="add_category" name="category" required
                        class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                    <option value="sunnah">Sholat Sunnah</option>
                    <option value="quran">Al-Qur'an & Tilawah</option>
                    <option value="dzikir">Dzikir & Doa</option>
                    <option value="kebaikan">Muamalah & Kebaikan</option>
                    <option value="pribadi" selected>Target Amalan Pribadi</option>
                </select>
            </div>

            <input type="hidden" name="icon" value="sparkles">

            <div class="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button type="button" onclick="closeAddCustomModal()"
                        class="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50">
                    Batal
                </button>
                <button type="submit"
                        class="px-5 py-2.5 bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs rounded-xl shadow-xs">
                    Tambahkan Amalan
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Edit Amalan Pribadi -->
<div id="editCustomModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
    <div class="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div class="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                <i data-lucide="edit" class="w-4 h-4 text-amber-600"></i>
                Edit Amalan Kustom
            </h3>
            <button type="button" onclick="closeEditCustomModal()" class="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form id="editCustomForm" method="POST" class="mt-4 space-y-4">
            @csrf
            @method('PUT')

            <div>
                <label for="edit_custom_label" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Nama Amalan <span class="text-rose-600">*</span>
                </label>
                <input type="text" id="edit_custom_label" name="label" required
                       class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
                <label for="edit_custom_category" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Kategori Amalan <span class="text-rose-600">*</span>
                </label>
                <select id="edit_custom_category" name="category" required
                        class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                    <option value="sunnah">Sholat Sunnah</option>
                    <option value="quran">Al-Qur'an & Tilawah</option>
                    <option value="dzikir">Dzikir & Doa</option>
                    <option value="kebaikan">Muamalah & Kebaikan</option>
                    <option value="pribadi">Target Amalan Pribadi</option>
                </select>
            </div>

            <input type="hidden" id="edit_custom_icon" name="icon" value="sparkles">

            <div class="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button type="button" onclick="closeEditCustomModal()"
                        class="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50">
                    Batal
                </button>
                <button type="submit"
                        class="px-5 py-2.5 bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs rounded-xl shadow-xs">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Form Hidden for Delete Custom Amalan -->
<form id="deleteCustomForm" method="POST" class="hidden">
    @csrf
    @method('DELETE')
</form>

<script>
    const totalItems = {{ count($keys) }};

    function updateAmalanCard(key) {
        const checkbox = document.getElementById('check-' + key);
        const card = document.getElementById('card-' + key);

        if (checkbox.checked) {
            card.classList.add('bg-amber-50/90', 'border-amber-300', 'text-amber-950', 'shadow-2xs', 'font-semibold');
            card.classList.remove('bg-slate-50/60', 'border-slate-200', 'text-slate-700');
        } else {
            card.classList.remove('bg-amber-50/90', 'border-amber-300', 'text-amber-950', 'shadow-2xs', 'font-semibold');
            card.classList.add('bg-slate-50/60', 'border-slate-200', 'text-slate-700');
        }

        recalculateRate();
    }

    function recalculateRate() {
        const checkboxes = document.querySelectorAll('.amalan-checkbox:checked');
        const count = checkboxes.length;
        const percentage = Math.round((count / totalItems) * 100);

        document.getElementById('rate-percentage').innerText = percentage;
        document.getElementById('completion-text').innerText = `${count} dari ${totalItems} Amalan Selesai`;
        document.getElementById('progress-bar').style.width = percentage + '%';
    }

    function openAddCustomModal() {
        document.getElementById('addCustomModal').classList.remove('hidden');
    }

    function closeAddCustomModal() {
        document.getElementById('addCustomModal').classList.add('hidden');
    }

    function openEditCustomModal(id, label, category, icon) {
        const form = document.getElementById('editCustomForm');
        form.action = `/amalan/custom/${id}`;
        document.getElementById('edit_custom_label').value = label;
        document.getElementById('edit_custom_category').value = category;
        const iconInput = document.getElementById('edit_custom_icon');
        if (iconInput) {
            iconInput.value = icon || 'sparkles';
        }
        document.getElementById('editCustomModal').classList.remove('hidden');
    }

    function closeEditCustomModal() {
        document.getElementById('editCustomModal').classList.add('hidden');
    }

    function confirmDeleteCustomModal(id, label) {
        if (confirm(`Apakah Anda yakin ingin menghapus amalan pribadi '${label}'?`)) {
            const form = document.getElementById('deleteCustomForm');
            form.action = `/amalan/custom/${id}`;
            form.submit();
        }
    }
</script>
@endsection

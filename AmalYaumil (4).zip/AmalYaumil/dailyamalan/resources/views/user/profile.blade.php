@extends('layouts.app')

@section('title', 'Profil & Pengaturan Pengingat — Sunnah Bloom')

@section('content')
<div class="max-w-4xl mx-auto space-y-8">

    <!-- Header & Profile Overview -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex flex-col sm:flex-row items-center sm:items-start gap-6">
            <div class="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 text-slate-950 font-extrabold text-2xl flex items-center justify-center shadow-lg shadow-amber-500/25 shrink-0">
                {{ strtoupper(substr($user->name, 0, 2)) }}
            </div>
            <div class="flex-1 text-center sm:text-left">
                <div class="flex flex-wrap items-center justify-center sm:justify-start gap-2.5 mb-1.5">
                    <h1 class="text-2xl font-extrabold text-slate-900">{{ $user->name }}</h1>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-bold {{ $user->role === 'admin' ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-amber-50 text-amber-800 border border-amber-200' }}">
                        {{ ucfirst($user->role) }}
                    </span>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600">
                        {{ $user->isActive() ? 'Akun Aktif' : 'Nonaktif' }}
                    </span>
                </div>
                <p class="text-xs text-slate-500 mb-3">{{ $user->email }} • Bergabung sejak {{ $user->created_at->translatedFormat('d F Y') }}</p>
                @if($user->bio)
                    <p class="text-xs text-slate-600 bg-amber-50/40 p-3 rounded-xl border border-amber-200/60 max-w-xl italic">
                        "{{ $user->bio }}"
                    </p>
                @endif
            </div>
        </div>
    </div>

    <!-- Daily Reminders Configuration Card (Requirement #5) -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-6 border-b border-slate-100 gap-3">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
                    <i data-lucide="bell-ring" class="w-5 h-5 text-amber-700"></i>
                </div>
                <div>
                    <h2 class="text-lg font-bold text-slate-900">Jadwal Pengingat Ibadah Harian</h2>
                    <p class="text-xs text-slate-500">Atur sendiri jam notifikasi agar istiqomah menjalankan amalan yaumiyah</p>
                </div>
            </div>

            <button type="button" onclick="testBrowserNotification()"
                    class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-xs font-bold text-amber-900 transition-colors">
                <i data-lucide="bell" class="w-3.5 h-3.5 text-amber-600"></i>
                Tes Notifikasi Web
            </button>
        </div>

        <form action="{{ route('reminders.update') }}" method="POST" class="space-y-6">
            @csrf
            @method('PUT')

            <!-- Browser Permission Banner -->
            <div class="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <input type="checkbox" id="browser_notifications_enabled" name="browser_notifications_enabled" value="1"
                           {{ ($reminder->browser_notifications_enabled ?? true) ? 'checked' : '' }}
                           class="w-5 h-5 rounded-md text-amber-500 border-slate-300 focus:ring-amber-500">
                    <div>
                        <label for="browser_notifications_enabled" class="text-xs sm:text-sm font-bold text-slate-900 cursor-pointer">
                            Aktifkan Notifikasi Web Browser
                        </label>
                        <p class="text-[11px] text-slate-500">
                            Pemberitahuan akan muncul otomatis di layar HP atau Laptop saat waktu amalan tiba.
                        </p>
                    </div>
                </div>
                <button type="button" onclick="requestNotificationPermission()"
                        class="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shrink-0">
                    Beri Izin Notifikasi
                </button>
            </div>

            <!-- Reminder Slots Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">

                <!-- Subuh / Dzikir Pagi -->
                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 flex items-center justify-between gap-4">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
                            <i data-lucide="sunrise" class="w-4 h-4 text-amber-600"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-xs font-bold text-slate-800">Subuh & Dzikir Pagi</p>
                            <p class="text-[11px] text-slate-500">Awal hari berkah</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="time" name="reminder_morning" value="{{ old('reminder_morning', $reminder->reminder_morning ?? '05:00') }}"
                               class="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="is_morning_active" value="1" {{ ($reminder->is_morning_active ?? true) ? 'checked' : '' }} class="sr-only peer">
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                        </label>
                    </div>
                </div>

                <!-- Dhuha & Tilawah Siang -->
                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 flex items-center justify-between gap-4">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
                            <i data-lucide="sun" class="w-4 h-4 text-amber-600"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-xs font-bold text-slate-800">Shalat Dhuha</p>
                            <p class="text-[11px] text-slate-500">Sedekah persendian</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="time" name="reminder_dhuha" value="{{ old('reminder_dhuha', $reminder->reminder_dhuha ?? '09:30') }}"
                               class="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="is_dhuha_active" value="1" {{ ($reminder->is_dhuha_active ?? true) ? 'checked' : '' }} class="sr-only peer">
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                        </label>
                    </div>
                </div>

                <!-- Petang & Al-Ma'tsurat -->
                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 flex items-center justify-between gap-4">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
                            <i data-lucide="sunset" class="w-4 h-4 text-amber-600"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-xs font-bold text-slate-800">Dzikir Petang & Maghrib</p>
                            <p class="text-[11px] text-slate-500">Benteng perlindungan senja</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="time" name="reminder_evening" value="{{ old('reminder_evening', $reminder->reminder_evening ?? '17:45') }}"
                               class="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="is_evening_active" value="1" {{ ($reminder->is_evening_active ?? true) ? 'checked' : '' }} class="sr-only peer">
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                        </label>
                    </div>
                </div>

                <!-- Malam & Muhasabah Diri -->
                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 flex items-center justify-between gap-4">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center shrink-0">
                            <i data-lucide="moon" class="w-4 h-4 text-amber-600"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-xs font-bold text-slate-800">Muhasabah & Evaluasi Harian</p>
                            <p class="text-[11px] text-slate-500">Cek checklist & refleksi jiwa</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="time" name="reminder_night" value="{{ old('reminder_night', $reminder->reminder_night ?? '21:00') }}"
                               class="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="is_night_active" value="1" {{ ($reminder->is_night_active ?? true) ? 'checked' : '' }} class="sr-only peer">
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                        </label>
                    </div>
                </div>

            </div>

            <div class="flex justify-end pt-2">
                <button type="submit"
                        class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-amber-500/25 transition-all">
                    Simpan Jadwal Pengingat
                </button>
            </div>
        </form>
    </div>

    <!-- Edit Profile & Security Forms -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- Edit Form -->
        <div class="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
            <div class="flex items-center gap-2 mb-6 pb-4 border-b border-slate-100">
                <i data-lucide="user-cog" class="w-5 h-5 text-amber-600"></i>
                <h2 class="text-base font-bold text-slate-900">Perbarui Informasi Profil</h2>
            </div>

            <form action="{{ route('profile.update') }}" method="POST" class="space-y-4">
                @csrf
                @method('PUT')

                <div>
                    <label for="name" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Nama Lengkap
                    </label>
                    <input type="text" id="name" name="name" value="{{ old('name', $user->name) }}" required
                           class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border @error('name') border-rose-400 @else border-slate-200 @enderror text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                    @error('name')
                        <p class="text-xs text-rose-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="email" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Alamat Email
                    </label>
                    <input type="email" id="email" name="email" value="{{ old('email', $user->email) }}" required
                           class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border @error('email') border-rose-400 @else border-slate-200 @enderror text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                    @error('email')
                        <p class="text-xs text-rose-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="phone" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Nomor HP / WhatsApp
                    </label>
                    <input type="text" id="phone" name="phone" value="{{ old('phone', $user->phone) }}"
                           placeholder="Contoh: 081234567890"
                           class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border @error('phone') border-rose-400 @else border-slate-200 @enderror text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                    @error('phone')
                        <p class="text-xs text-rose-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="bio" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Biodata / Niat Pribadi
                    </label>
                    <textarea id="bio" name="bio" rows="2"
                              placeholder="Motto atau niat istiqomah Anda..."
                              class="w-full p-3 rounded-xl bg-slate-50 border @error('bio') border-rose-400 @else border-slate-200 @enderror text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">{{ old('bio', $user->bio) }}</textarea>
                    @error('bio')
                        <p class="text-xs text-rose-600 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="pt-4 border-t border-slate-100">
                    <p class="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                        Ganti Kata Sandi (Kosongkan jika tidak ingin mengubah)
                    </p>

                    <div class="space-y-3">
                        <div>
                            <input type="password" name="current_password" placeholder="Kata sandi saat ini"
                                   class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border @error('current_password') border-rose-400 @else border-slate-200 @enderror text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                            @error('current_password')
                                <p class="text-xs text-rose-600 mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                                <input type="password" name="new_password" placeholder="Kata sandi baru"
                                       class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border @error('new_password') border-rose-400 @else border-slate-200 @enderror text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                                @error('new_password')
                                    <p class="text-xs text-rose-600 mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <input type="password" name="new_password_confirmation" placeholder="Ulangi kata sandi baru"
                                       class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="pt-4 flex justify-end">
                    <button type="submit"
                            class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-amber-500/25 transition-all">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>

        <!-- Recent Login History & Security -->
        <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs flex flex-col justify-between">
            <div>
                <div class="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                    <i data-lucide="shield" class="w-5 h-5 text-amber-600"></i>
                    <h2 class="text-base font-bold text-slate-900">Aktivitas Sesi Terakhir</h2>
                </div>

                <div class="space-y-3">
                    @forelse($recentLogins as $login)
                        <div class="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs space-y-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-slate-800">{{ $login->device_info }}</span>
                                <span class="text-[10px] text-slate-400">{{ $login->login_at->diffForHumans() }}</span>
                            </div>
                            <div class="flex items-center justify-between text-[11px] text-slate-500">
                                <span class="font-mono">{{ $login->ip_address }}</span>
                                <span class="font-semibold text-amber-700">{{ $login->duration }}</span>
                            </div>
                        </div>
                    @empty
                        <p class="text-xs text-slate-400">Belum ada riwayat aktivitas sesi.</p>
                    @endforelse
                </div>
            </div>

            <div class="pt-6 border-t border-slate-100 text-[11px] text-slate-400 flex items-center gap-1.5">
                <i data-lucide="info" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                <span>Riwayat ini dicatat demi keamanan akun Anda.</span>
            </div>
        </div>

    </div>

</div>

@push('scripts')
<script>
    function requestNotificationPermission() {
        if (!("Notification" in window)) {
            alert("Browser ini tidak mendukung notifikasi desktop.");
            return;
        }

        Notification.requestPermission().then(function (permission) {
            if (permission === "granted") {
                new Notification("Sunnah Bloom — RQ Al-Izzah", {
                    body: "Alhamdulillah! Notifikasi pengingat ibadah harian telah aktif.",
                    icon: "/favicon.ico"
                });
            } else {
                alert("Izin notifikasi belum diaktifkan pada browser.");
            }
        });
    }

    function testBrowserNotification() {
        if (!("Notification" in window)) {
            alert("Browser tidak mendukung Web Notification.");
            return;
        }

        if (Notification.permission === "granted") {
            new Notification("Waktunya Muhasabah & Amalan Yaumi! 🌻", {
                body: "Sudahkah Anda mengevaluasi ibadah hari ini di Sunnah Bloom?",
                icon: "/favicon.ico"
            });
        } else {
            Notification.requestPermission().then(function (permission) {
                if (permission === "granted") {
                    new Notification("Sunnah Bloom — RQ Al-Izzah", {
                        body: "Notifikasi pengingat berhasil diaktifkan!",
                        icon: "/favicon.ico"
                    });
                } else {
                    alert("Harap izinkan notifikasi di pengaturan browser Anda.");
                }
            });
        }
    }
</script>
@endpush
@endsection

@extends('layouts.app')

@section('title', 'Grafik Perkembangan & Histori — Amalan Yaumi')

@section('content')
<div class="space-y-8">

    <!-- Header -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
                <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-bold mb-2">
                    <i data-lucide="sun" class="w-3.5 h-3.5 text-amber-600"></i>
                    Evaluasi & Grafik Istiqomah
                </div>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900">
                    Perkembangan Mutaba'ah
                </h1>
                <p class="text-xs sm:text-sm text-slate-500 mt-1">
                    Analisis konsistensi ibadahmu berdasarkan data yang telah tercatat.
                </p>
            </div>
            <a href="{{ route('amalan.index') }}"
               class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-xs sm:text-sm shadow-sm transition-all">
                <i data-lucide="plus-circle" class="w-4 h-4"></i>
                Isi Amalan Baru
            </a>
        </div>
    </div>

    <!-- 4 Milestone Summary Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <!-- 1. Perfect Days -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Hari Sempurna (100%)</span>
                <div class="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                    <i data-lucide="award" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-amber-600">{{ $perfectDays }}</span>
                <span class="text-xs font-semibold text-slate-500">Hari MasyaAllah</span>
            </div>
            <p class="text-[11px] text-slate-400 mt-2">Semua {{ count(\App\Models\DailyAmalan::AMALAN_KEYS) }} amalan tuntas dikerjakan</p>
        </div>

        <!-- 2. Highest Rate -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Rekor Tertinggi</span>
                <div class="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                    <i data-lucide="zap" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $highestRate }}%</span>
                <span class="text-xs font-semibold text-slate-500">Capaian Harian</span>
            </div>
            <p class="text-[11px] text-slate-400 mt-2">Capaian terbaik yang pernah diraih</p>
        </div>

        <!-- 3. Overall Average -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Rata-Rata Kepatuhan</span>
                <div class="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                    <i data-lucide="activity" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $overallAverage }}%</span>
                <span class="text-xs font-semibold text-slate-500">Konsistensi</span>
            </div>
            <p class="text-[11px] text-slate-400 mt-2">Rata-rata dari seluruh hari aktif</p>
        </div>

        <!-- 4. Total Days -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-400 transition-all">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Hari Tercatat</span>
                <div class="w-9 h-9 rounded-xl bg-yellow-50 text-yellow-700 flex items-center justify-center font-bold">
                    <i data-lucide="check-check" class="w-5 h-5"></i>
                </div>
            </div>
            <div class="flex items-baseline gap-2">
                <span class="text-3xl font-extrabold text-slate-900">{{ $totalRecorded }}</span>
                <span class="text-xs font-semibold text-slate-500">Hari Mutaba'ah</span>
            </div>
            <p class="text-[11px] text-slate-400 mt-2">Data tersimpan rapi di akun Anda</p>
        </div>
    </div>

    <!-- 14-Days Trend Chart Visual -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-lg font-bold text-slate-900">Tren Capaian 14 Hari Terakhir</h2>
                <p class="text-xs text-slate-500">Melihat konsistensi fluktuasi ibadah dari dua pekan terakhir</p>
            </div>
            <div class="flex items-center gap-3 text-xs">
                <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Tinggi (≥75%)</span>
                <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-300"></span> Sedang</span>
                <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-slate-300"></span> 0%</span>
            </div>
        </div>

        <!-- Bar Container -->
        <div class="grid grid-cols-7 sm:grid-cols-14 gap-2 items-end h-52 pt-6 pb-2 border-b border-slate-100">
            @foreach($trendDays as $day)
                <div class="flex flex-col items-center justify-end h-full group">
                    <span class="text-[9px] font-bold {{ $day['rate'] >= 75 ? 'text-amber-700' : 'text-slate-500' }} group-hover:scale-110 transition-transform mb-1">
                        {{ $day['rate'] }}%
                    </span>
                    <div class="w-full max-w-[28px] bg-slate-100 rounded-t-md overflow-hidden flex flex-col justify-end h-36">
                        <div class="w-full rounded-t-md transition-all duration-300 {{ $day['rate'] >= 75 ? 'bg-gradient-to-t from-amber-500 to-yellow-400' : ($day['rate'] > 0 ? 'bg-amber-300' : 'bg-slate-200') }}"
                             style="height: {{ max($day['rate'], 6) }}%">
                        </div>
                    </div>
                    <span class="text-[9px] font-semibold text-slate-500 mt-2 truncate w-full text-center">
                        {{ $day['date_label'] }}
                    </span>
                </div>
            @endforeach
        </div>
    </div>

    <!-- Amalan Items Breakdown Grid -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="mb-6">
            <h2 class="text-lg font-bold text-slate-900">Tingkat Ketuntasan Tiap Jenis Amalan</h2>
            <p class="text-xs text-slate-500">Persentase amalan yang berhasil dilaksanakan dari {{ $totalRecorded }} hari yang tercatat</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            @foreach($amalanStats as $stat)
                <div class="p-4 rounded-2xl bg-slate-50/70 border border-slate-200/80 flex flex-col justify-between">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex items-center gap-2.5">
                            <div class="w-7 h-7 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-xs">
                                <i data-lucide="check" class="w-3.5 h-3.5"></i>
                            </div>
                            <span class="text-xs font-bold text-slate-800">{{ $stat['label'] }}</span>
                        </div>
                        <span class="text-xs font-extrabold {{ $stat['percentage'] >= 75 ? 'text-amber-700' : 'text-slate-600' }}">
                            {{ $stat['percentage'] }}%
                        </span>
                    </div>

                    <!-- Progress bar -->
                    <div class="w-full bg-slate-200 rounded-full h-2 overflow-hidden mb-1">
                        <div class="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 h-2 rounded-full transition-all duration-500"
                             style="width: {{ $stat['percentage'] }}%"></div>
                    </div>
                    <div class="flex justify-between text-[10px] text-slate-400">
                        <span>Kategori: {{ ucfirst($stat['category']) }}</span>
                        <span>{{ $stat['count'] }} dari {{ $totalRecorded }} hari</span>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <!-- History Table -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-lg font-bold text-slate-900">Riwayat Catatan Harian</h2>
                <p class="text-xs text-slate-500">Daftar entri amalan yang pernah Anda simpan</p>
            </div>
        </div>

        @if($recentRecords->count() > 0)
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs sm:text-sm">
                    <thead>
                        <tr class="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px] tracking-wider">
                            <th class="py-3 px-4">Tanggal</th>
                            <th class="py-3 px-4">Capaian</th>
                            <th class="py-3 px-4">Amalan Selesai</th>
                            <th class="py-3 px-4">Catatan Evaluasi</th>
                            <th class="py-3 px-4 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @foreach($recentRecords as $rec)
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                                    {{ $rec->date->translatedFormat('d M Y') }}
                                </td>
                                <td class="py-3.5 px-4 whitespace-nowrap">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold {{ $rec->completion_rate >= 80 ? 'bg-amber-100 text-amber-900 border border-amber-200' : ($rec->completion_rate >= 50 ? 'bg-amber-50 text-amber-800 border border-amber-100' : 'bg-slate-100 text-slate-600') }}">
                                        {{ $rec->completion_rate }}%
                                    </span>
                                </td>
                                <td class="py-3.5 px-4 text-slate-600 whitespace-nowrap font-medium">
                                    {{ $rec->completedCount() }} / {{ count(\App\Models\DailyAmalan::AMALAN_KEYS) }} Amalan
                                </td>
                                <td class="py-3.5 px-4 text-slate-500 max-w-xs truncate">
                                    {{ $rec->notes ?: '—' }}
                                </td>
                                <td class="py-3.5 px-4 text-right whitespace-nowrap">
                                    <a href="{{ route('amalan.index', ['date' => $rec->date->toDateString()]) }}"
                                       class="px-3 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 text-xs font-bold transition-colors">
                                        Lihat / Ubah
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="mt-6">
                {{ $recentRecords->links() }}
            </div>
        @else
            <div class="p-8 text-center text-slate-400 text-xs">
                Belum ada data riwayat amalan tercatat.
            </div>
        @endif
    </div>

</div>
@endsection

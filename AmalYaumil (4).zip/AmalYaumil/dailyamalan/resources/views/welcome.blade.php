@extends('layouts.app')

@section('title', 'Amalan Yaumi — Sahabat Menjaga Istiqomah Ibadah')

@section('content')
<div class="space-y-16 py-4">

    <!-- Hero Section -->
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-950 via-stone-900 to-orange-950 text-white shadow-2xl p-8 sm:p-14 lg:p-16 border border-amber-600/40">
        <!-- Background subtle solar glow & radiant light -->
        <div class="absolute -top-24 -right-24 w-96 h-96 bg-amber-500/25 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -bottom-24 -left-24 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl pointer-events-none"></div>

        <div class="relative z-10 max-w-3xl">
            <!-- Institution Tagline Badge -->
            <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-900/60 border border-amber-500/40 text-amber-200 text-xs sm:text-sm font-medium mb-6 backdrop-blur-md">
                <i data-lucide="sun" class="w-4 h-4 text-amber-400"></i>
                <span class="font-bold text-amber-300">{{ $appSettings['app_tagline'] ?? 'powered by Rumah Qur\'an Al-Izzah Cab. Singkawang' }}</span>
            </div>

            <!-- Header and Sub Header -->
            <div class="mb-4">
                <span class="block text-xs sm:text-sm font-extrabold uppercase tracking-widest text-amber-400 mb-2">
                    {{ $appSettings['app_sub_header'] ?? 'Platform Digital Amalan Yaumi' }}
                </span>
                <h1 class="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-none text-white">
                    {{ $appSettings['app_name'] ?? 'Sunnah Bloom' }}
                </h1>
            </div>

            <p class="text-lg sm:text-xl text-amber-200 font-semibold mb-3">
                Menjaga <span class="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-300 to-orange-400">Istiqomah</span>, Menata Hati Menuju Ridho Ilahi.
            </p>

            <p class="text-sm sm:text-base text-amber-100/90 leading-relaxed mb-8 max-w-2xl font-normal">
                Platform mutaba'ah amalan yaumiyah harian untuk seluruh jamaah dan santri. Catat sholat fardhu, sunnah rawatib, tilawah 1 juz (ODOJ), dzikir pagi-petang, hingga jurnal refleksi jiwa terenkripsi yang aman dan terjaga kerahasiaannya.
            </p>

            <!-- Action Buttons -->
            <div class="flex flex-wrap items-center gap-4">
                @auth
                    <a href="{{ route('user.dashboard') }}"
                       class="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]">
                        <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
                        Buka Dashboard Saya
                    </a>
                    <a href="{{ route('amalan.index') }}"
                       class="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm border border-white/20 backdrop-blur-md transition-all">
                        <i data-lucide="check-circle" class="w-5 h-5 text-amber-300"></i>
                        Catat Amalan Hari Ini
                    </a>
                @else
                    <a href="{{ route('register') }}"
                       class="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]">
                        <i data-lucide="user-plus" class="w-5 h-5"></i>
                        Mulai Gratis Sekarang
                    </a>
                    <a href="{{ route('login') }}"
                       class="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm border border-white/20 backdrop-blur-md transition-all">
                        <i data-lucide="log-in" class="w-5 h-5 text-amber-300"></i>
                        Masuk ke Akun
                    </a>
                @endauth
            </div>
        </div>
    </div>

    <!-- Quick Demo Accounts Helper Card -->
    <div class="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/90 rounded-2xl p-6 shadow-xs">
        <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div class="flex items-center gap-3.5">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-400 text-slate-950 flex items-center justify-center font-bold shrink-0 shadow-xs">
                    <i data-lucide="key" class="w-5 h-5"></i>
                </div>
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Akun Pengujian Demo Tersedia</h2>
                    <p class="text-xs text-slate-600">Gunakan akun berikut untuk menguji fitur Pengguna dan Admin secara langsung:</p>
                </div>
            </div>
            <div class="flex flex-wrap items-center gap-3">
                <div class="px-3 py-2 rounded-xl bg-white border border-amber-200 text-xs shadow-2xs">
                    <span class="font-bold text-amber-800">Admin:</span>
                    <span class="font-mono text-slate-600">admin@amalan.id</span>
                    <span class="text-slate-400">/</span>
                    <span class="font-mono text-slate-600">password123</span>
                </div>
                <div class="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs shadow-2xs">
                    <span class="font-bold text-slate-800">User:</span>
                    <span class="font-mono text-slate-600">ahmad@example.com</span>
                    <span class="text-slate-400">/</span>
                    <span class="font-mono text-slate-600">password123</span>
                </div>
                <a href="{{ route('login') }}" class="px-3 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 rounded-xl text-xs font-bold shadow-xs transition-all">
                    Langsung Masuk &rarr;
                </a>
            </div>
        </div>
    </div>

    <!-- Hadith Quote Card -->
    <div class="max-w-4xl mx-auto text-center p-8 bg-white border border-amber-200/70 rounded-2xl shadow-xs">
        <p class="font-arabic text-2xl sm:text-3xl text-amber-950 font-bold mb-3 leading-loose">
            « أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ »
        </p>
        <p class="text-slate-700 text-sm sm:text-base italic mb-2">
            {{ $appSettings['daily_quote'] ?? '"Amalan yang paling dicintai oleh Allah adalah amalan yang berkelanjutan (istiqomah) walaupun sedikit."' }}
        </p>
        <p class="text-xs font-bold text-amber-700 uppercase tracking-wider">
            (HR. Bukhari no. 6464 & Muslim no. 782)
        </p>
    </div>

    <!-- 4 Key Core Features Grid -->
    <div>
        <div class="text-center max-w-2xl mx-auto mb-10">
            <span class="text-xs font-bold text-amber-600 uppercase tracking-wider">Fitur Unggulan</span>
            <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">Dirancang untuk Menjaga Kualitas Ibadah</h2>
            <p class="text-sm text-slate-500 mt-2">Setiap fitur dihadirkan untuk memudahkan muhasabah tanpa mengabaikan aspek kekhusyukan dan privasi.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <!-- Feature 1 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-lg transition-all group">
                <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all font-bold">
                    <i data-lucide="check-square" class="w-6 h-6"></i>
                </div>
                <h3 class="text-base font-bold text-slate-900 mb-2">Tracker Amalan Harian</h3>
                <p class="text-xs text-slate-600 leading-relaxed">
                    Checklist terstruktur mencakup sholat fardhu, sholat sunnah dhuha & tahajud, tilawah Qur'an, dzikir pagi petang, hingga sedekah harian.
                </p>
            </div>

            <!-- Feature 2 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-lg transition-all group">
                <div class="w-12 h-12 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:bg-orange-500 group-hover:text-white transition-all font-bold">
                    <i data-lucide="book-heart" class="w-6 h-6"></i>
                </div>
                <h3 class="text-base font-bold text-slate-900 mb-2">Jurnal Syukur Pribadi</h3>
                <p class="text-xs text-slate-600 leading-relaxed">
                    Tuliskan 3 hal yang disyukuri setiap hari dan muhasabah melepaskan kekecewaan serta memaafkan orang lain secara aman dan rahasia.
                </p>
            </div>

            <!-- Feature 3 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-lg transition-all group">
                <div class="w-12 h-12 rounded-xl bg-yellow-50 text-yellow-700 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:bg-yellow-400 group-hover:text-slate-950 transition-all font-bold">
                    <i data-lucide="trending-up" class="w-6 h-6"></i>
                </div>
                <h3 class="text-base font-bold text-slate-900 mb-2">Grafik & Tren Istiqomah</h3>
                <p class="text-xs text-slate-600 leading-relaxed">
                    Pantau grafik perkembangan 14 hari, hitungan hari istiqomah (streak), serta rata-rata capaian amalan untuk memotivasi perbaikan diri.
                </p>
            </div>

            <!-- Feature 4 -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-lg transition-all group">
                <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:bg-amber-600 group-hover:text-white transition-all font-bold">
                    <i data-lucide="shield-check" class="w-6 h-6"></i>
                </div>
                <h3 class="text-base font-bold text-slate-900 mb-2">Privasi & Panel Admin</h3>
                <p class="text-xs text-slate-600 leading-relaxed">
                    Admin dapat memantau keaktifan statistik & audit login, namun isi jurnal doa pengguna sepenuhnya dienkripsi & terlindungi secara privasi.
                </p>
            </div>
        </div>
    </div>

    <!-- Call to action card -->
    <div class="rounded-3xl bg-slate-900 text-white p-8 sm:p-12 text-center relative overflow-hidden">
        <div class="relative z-10 max-w-2xl mx-auto">
            <h2 class="text-2xl sm:text-3xl font-extrabold text-white mb-4">Mulai Perjalanan Ibadah yang Lebih Teratur</h2>
            <p class="text-sm text-slate-400 mb-8 leading-relaxed">
                Setiap fajar adalah lembaran baru untuk mendekat kepada-Nya. Sambut mentari dengan mutaba'ah yang konsisten dan penuh keberkahan.
            </p>
            @guest
                <a href="{{ route('register') }}"
                   class="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/25 transition-all hover:scale-105">
                    <i data-lucide="sun" class="w-5 h-5"></i>
                    Daftar Akun Gratis Sekarang
                </a>
            @else
                <a href="{{ route('user.dashboard') }}"
                   class="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/25 transition-all hover:scale-105">
                    <i data-lucide="arrow-right" class="w-5 h-5"></i>
                    Buka Dashboard Saya
                </a>
            @endguest
        </div>
    </div>
</div>
@endsection

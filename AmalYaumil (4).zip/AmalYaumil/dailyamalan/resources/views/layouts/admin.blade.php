<!DOCTYPE html>
<html lang="id" class="h-full bg-slate-100">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin Panel') — Amalan Yaumi Administration</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50: '#fffbeb',
                            100: '#fef3c7',
                            200: '#fde68a',
                            300: '#fcd34d',
                            400: '#fbbf24',
                            500: '#f59e0b',
                            600: '#d97706',
                            700: '#b45309',
                            800: '#92400e',
                            900: '#78350f',
                        }
                    }
                }
            }
        }
    </script>

    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
    @stack('styles')
</head>
<body class="flex h-full bg-slate-100 text-slate-800 antialiased selection:bg-amber-400 selection:text-slate-950">

    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 border-r border-slate-800 hidden md:flex">
        <!-- Brand Header -->
        <div class="h-16 flex items-center gap-3 px-6 border-b border-slate-800 bg-slate-950">
            <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 flex items-center justify-center text-slate-950 font-black shadow-md shadow-amber-500/25">
                <i data-lucide="sun" class="w-5 h-5 text-slate-950"></i>
            </div>
            <div>
                <span class="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
                    Admin<span class="text-amber-400">Panel</span>
                </span>
                <span class="block text-[10px] text-amber-500/80 font-semibold tracking-wider uppercase -mt-0.5">
                    Amalan Yaumi
                </span>
            </div>
        </div>

        <!-- Navigation Menu -->
        <div class="flex-1 py-6 px-4 space-y-1.5 overflow-y-auto">
            <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">
                Menu Utama
            </div>

            <a href="{{ route('admin.dashboard') }}"
               class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.dashboard') ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-300 hover:text-white hover:bg-slate-800/80' }}">
                <i data-lucide="layout-dashboard" class="w-4 h-4 {{ request()->routeIs('admin.dashboard') ? 'text-slate-950' : 'text-slate-400' }}"></i>
                <span>Ringkasan Dasbor</span>
            </a>

            <a href="{{ route('admin.users.index') }}"
               class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.users.*') ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-300 hover:text-white hover:bg-slate-800/80' }}">
                <i data-lucide="users" class="w-4 h-4 {{ request()->routeIs('admin.users.*') ? 'text-slate-950' : 'text-slate-400' }}"></i>
                <span>Manajemen Pengguna</span>
            </a>

            <a href="{{ route('admin.login-activities.index') }}"
               class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.login-activities.*') ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-300 hover:text-white hover:bg-slate-800/80' }}">
                <i data-lucide="shield-alert" class="w-4 h-4 {{ request()->routeIs('admin.login-activities.*') ? 'text-slate-950' : 'text-slate-400' }}"></i>
                <span>Aktivitas Login</span>
            </a>

            <a href="{{ route('admin.statistics.index') }}"
               class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.statistics.*') ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-300 hover:text-white hover:bg-slate-800/80' }}">
                <i data-lucide="bar-chart-3" class="w-4 h-4 {{ request()->routeIs('admin.statistics.*') ? 'text-slate-950' : 'text-slate-400' }}"></i>
                <span>Statistik & Laporan</span>
            </a>

            <div class="pt-4 pb-1">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">
                    Konfigurasi & Master
                </div>
            </div>

            <a href="{{ route('admin.amalan-items.index') }}"
               class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.amalan-items.*') ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-300 hover:text-white hover:bg-slate-800/80' }}">
                <i data-lucide="check-square" class="w-4 h-4 {{ request()->routeIs('admin.amalan-items.*') ? 'text-slate-950' : 'text-slate-400' }}"></i>
                <span>Master Amalan</span>
            </a>

            <a href="{{ route('admin.access-codes.index') }}"
               class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.access-codes.*') ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-300 hover:text-white hover:bg-slate-800/80' }}">
                <i data-lucide="key" class="w-4 h-4 {{ request()->routeIs('admin.access-codes.*') ? 'text-slate-950' : 'text-slate-400' }}"></i>
                <span>Kode Akses / Lisensi</span>
            </a>

            <a href="{{ route('admin.settings') }}"
               class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all {{ request()->routeIs('admin.settings*') ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20' : 'text-slate-300 hover:text-white hover:bg-slate-800/80' }}">
                <i data-lucide="settings" class="w-4 h-4 {{ request()->routeIs('admin.settings*') ? 'text-slate-950' : 'text-slate-400' }}"></i>
                <span>Pengaturan Aplikasi</span>
            </a>

            <div class="pt-6">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">
                    Akses Cepat
                </div>
                <a href="{{ route('user.dashboard') }}"
                   class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all">
                    <i data-lucide="arrow-left-circle" class="w-4 h-4 text-amber-400"></i>
                    <span>Tampilan Pengguna</span>
                </a>
            </div>
        </div>

        <!-- Privacy Assurance Card -->
        <div class="p-4 m-4 rounded-xl bg-slate-800/60 border border-slate-700/50 text-xs text-slate-400">
            <div class="flex items-center gap-2 text-amber-400 font-semibold mb-1">
                <i data-lucide="lock" class="w-3.5 h-3.5"></i>
                <span>Jaminan Privasi</span>
            </div>
            <p class="text-[11px] text-slate-400 leading-relaxed">
                Jurnal pribadi dan catatan spiritual pengguna terlindungi penuh & tidak ditampilkan di panel admin.
            </p>
        </div>

        <!-- Admin Profile Bottom Card -->
        <div class="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
            <div class="flex items-center gap-3 truncate">
                <div class="w-9 h-9 rounded-full bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center shrink-0">
                    AD
                </div>
                <div class="truncate">
                    <p class="text-xs font-semibold text-white truncate">{{ Auth::user()->name }}</p>
                    <p class="text-[10px] text-amber-400 font-medium">Super Administrator</p>
                </div>
            </div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" title="Logout" class="p-2 text-slate-400 hover:text-rose-400 transition-colors">
                    <i data-lucide="log-out" class="w-4 h-4"></i>
                </button>
            </form>
        </div>
    </aside>

    <!-- Main Content Wrapper -->
    <div class="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <!-- Topbar -->
        <header class="h-16 bg-white border-b border-slate-200/90 px-4 sm:px-8 flex items-center justify-between sticky top-0 z-30 shadow-xs">
            <div class="flex items-center gap-3">
                <div class="md:hidden flex items-center gap-2">
                    <a href="{{ route('admin.dashboard') }}" class="font-bold text-slate-900 flex items-center gap-1.5">
                        <span class="w-7 h-7 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-xs">
                            <i data-lucide="sun" class="w-4 h-4"></i>
                        </span>
                        <span>Admin</span>
                    </a>
                </div>
                <div class="hidden sm:flex items-center gap-2 text-xs font-medium text-slate-500">
                    <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                    <span>Server Aktif</span>
                    <span class="text-slate-300">|</span>
                    <span>{{ \Carbon\Carbon::now()->translatedFormat('l, d F Y') }}</span>
                </div>
            </div>

            <!-- Right Controls in Topbar -->
            <div class="flex items-center gap-4">
                <a href="{{ route('user.dashboard') }}" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-300 transition-colors">
                    <i data-lucide="external-link" class="w-3.5 h-3.5 text-amber-600"></i>
                    Buka Aplikasi
                </a>
                <div class="h-4 w-px bg-slate-200"></div>
                <div class="text-right hidden sm:block">
                    <p class="text-xs font-semibold text-slate-800">{{ Auth::user()->name }}</p>
                    <p class="text-[10px] text-slate-400">{{ Auth::user()->email }}</p>
                </div>
                <form action="{{ route('logout') }}" method="POST" class="inline">
                    @csrf
                    <button type="submit" class="p-2 text-slate-400 hover:text-rose-600 rounded-lg transition-colors" title="Keluar">
                        <i data-lucide="log-out" class="w-4 h-4"></i>
                    </button>
                </form>
            </div>
        </header>

        <!-- Admin Mobile Navigation -->
        <div class="md:hidden bg-slate-900 px-4 py-2 flex justify-between text-xs text-slate-300">
            <a href="{{ route('admin.dashboard') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('admin.dashboard') ? 'text-amber-400 font-bold' : '' }}">
                <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                <span class="text-[10px]">Dasbor</span>
            </a>
            <a href="{{ route('admin.users.index') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('admin.users.*') ? 'text-amber-400 font-bold' : '' }}">
                <i data-lucide="users" class="w-4 h-4"></i>
                <span class="text-[10px]">Pengguna</span>
            </a>
            <a href="{{ route('admin.login-activities.index') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('admin.login-activities.*') ? 'text-amber-400 font-bold' : '' }}">
                <i data-lucide="shield-alert" class="w-4 h-4"></i>
                <span class="text-[10px]">Login</span>
            </a>
            <a href="{{ route('admin.statistics.index') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('admin.statistics.*') ? 'text-amber-400 font-bold' : '' }}">
                <i data-lucide="bar-chart-3" class="w-4 h-4"></i>
                <span class="text-[10px]">Statistik</span>
            </a>
        </div>

        <!-- Global Flash Alerts -->
        <div class="px-4 sm:px-8 mt-6">
            @if(session('success'))
                <div class="flex items-center gap-3 p-4 mb-4 text-amber-950 bg-amber-50 border border-amber-300 rounded-xl shadow-xs" role="alert">
                    <i data-lucide="check-circle-2" class="w-5 h-5 text-amber-600 shrink-0"></i>
                    <div class="text-sm font-medium">{{ session('success') }}</div>
                </div>
            @endif

            @if(session('error'))
                <div class="flex items-center gap-3 p-4 mb-4 text-rose-800 bg-rose-50 border border-rose-200 rounded-xl shadow-xs" role="alert">
                    <i data-lucide="alert-circle" class="w-5 h-5 text-rose-600 shrink-0"></i>
                    <div class="text-sm font-medium">{{ session('error') }}</div>
                </div>
            @endif
        </div>

        <!-- Main Workspace -->
        <main class="flex-1 px-4 sm:px-8 py-6">
            @yield('content')
        </main>
    </div>

    <!-- Initialize Lucide Icons -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            lucide.createIcons();
        });
    </script>
    @stack('scripts')
</body>
</html>

<!DOCTYPE html>
<html lang="id" class="h-full bg-slate-50">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Amalan Yaumi') — Sahabat Menjaga Istiqomah</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Tailwind CSS CDN with configuration -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        arabic: ['"Amiri"', 'serif'],
                    },
                    colors: {
                        primary: {
                            50: '#fffbeb',
                            100: '#fef3c7',
                            200: '#fde68a',
                            300: '#fcd34d',
                            400: '#fbbf24',
                            500: '#f59e0b',
                            600: '#d97706',
                            700: '#b45309',
                            800: '#92400e',
                            900: '#78350f',
                            950: '#451a03',
                        },
                        sun: {
                            50: '#fffdf0',
                            100: '#fef9c3',
                            200: '#fef08a',
                            300: '#fde047',
                            400: '#facc15',
                            500: '#eab308',
                            600: '#ca8a04',
                            700: '#a16207',
                            800: '#854d0e',
                            900: '#713f12',
                        },
                        solar: {
                            50: '#fff7ed',
                            100: '#ffedd5',
                            200: '#fed7aa',
                            300: '#fdba74',
                            400: '#fb923c',
                            500: '#f97316',
                            600: '#ea580c',
                            700: '#c2410c',
                            800: '#9a3412',
                            900: '#7c2d12',
                        }
                    }
                }
            }
        }
    </script>

    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>

    <!-- Custom Micro-styling -->
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #fafaf9;
        }
        .bg-solar-pattern, .bg-islamic-pattern {
            background-color: #78350f;
            background-image: radial-gradient(#fbbf24 0.75px, transparent 0.75px), radial-gradient(#d97706 0.75px, #78350f 0.75px);
            background-size: 30px 30px;
            background-position: 0 0, 15px 15px;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(254, 243, 199, 0.8);
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #fde68a;
            border-radius: 9999px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #fffbeb;
        }
    </style>
    @stack('styles')
</head>
<body class="flex flex-col min-h-screen text-slate-800 antialiased selection:bg-amber-400 selection:text-slate-950">

    <!-- Top Navigation Bar -->
    <header class="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-amber-200/60 shadow-xs transition-all">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <!-- Brand Logo -->
                <div class="flex items-center gap-3">
                    <a href="{{ route('home') }}" class="flex items-center gap-2.5 group">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 flex items-center justify-center text-slate-950 font-bold shadow-md shadow-amber-500/25 group-hover:scale-105 transition-transform duration-200">
                            <i data-lucide="sun" class="w-5 h-5 text-slate-950"></i>
                        </div>
                        <div>
                            <span class="text-xl font-extrabold tracking-tight text-slate-900 flex items-center gap-1.5">
                                {{ $appSettings['app_name'] ?? 'Sunnah Bloom' }}
                            </span>
                            <span class="block text-[10px] font-semibold text-amber-700 tracking-wider uppercase -mt-1 truncate max-w-[240px]">
                                {{ $appSettings['app_sub_header'] ?? 'Platform Digital Amalan Yaumi' }}
                            </span>
                        </div>
                    </a>

                    <!-- Navigation Links for Authenticated Users -->
                    @auth
                        <nav class="hidden md:flex items-center gap-1 ml-8">
                            <a href="{{ route('user.dashboard') }}"
                               class="px-3.5 py-2 rounded-lg text-sm font-medium transition-all {{ request()->routeIs('user.dashboard') ? 'bg-amber-100/80 text-amber-900 font-bold shadow-2xs border-b-2 border-amber-500' : 'text-slate-600 hover:text-amber-800 hover:bg-amber-50/70' }}">
                                <span class="flex items-center gap-2">
                                    <i data-lucide="layout-dashboard" class="w-4 h-4 {{ request()->routeIs('user.dashboard') ? 'text-amber-600' : 'text-slate-400' }}"></i>
                                    Beranda
                                </span>
                            </a>
                            <a href="{{ route('amalan.index') }}"
                               class="px-3.5 py-2 rounded-lg text-sm font-medium transition-all {{ request()->routeIs('amalan.*') ? 'bg-amber-100/80 text-amber-900 font-bold shadow-2xs border-b-2 border-amber-500' : 'text-slate-600 hover:text-amber-800 hover:bg-amber-50/70' }}">
                                <span class="flex items-center gap-2">
                                    <i data-lucide="check-circle-2" class="w-4 h-4 {{ request()->routeIs('amalan.*') ? 'text-amber-600' : 'text-slate-400' }}"></i>
                                    Catat Amalan
                                </span>
                            </a>
                            <a href="{{ route('journal.index') }}"
                               class="px-3.5 py-2 rounded-lg text-sm font-medium transition-all {{ request()->routeIs('journal.*') ? 'bg-amber-100/80 text-amber-900 font-bold shadow-2xs border-b-2 border-amber-500' : 'text-slate-600 hover:text-amber-800 hover:bg-amber-50/70' }}">
                                <span class="flex items-center gap-2">
                                    <i data-lucide="book-heart" class="w-4 h-4 {{ request()->routeIs('journal.*') ? 'text-amber-600' : 'text-slate-400' }}"></i>
                                    Jurnal Syukur
                                    <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                                </span>
                            </a>
                            <a href="{{ route('progress.index') }}"
                               class="px-3.5 py-2 rounded-lg text-sm font-medium transition-all {{ request()->routeIs('progress.*') ? 'bg-amber-100/80 text-amber-900 font-bold shadow-2xs border-b-2 border-amber-500' : 'text-slate-600 hover:text-amber-800 hover:bg-amber-50/70' }}">
                                <span class="flex items-center gap-2">
                                    <i data-lucide="trending-up" class="w-4 h-4 {{ request()->routeIs('progress.*') ? 'text-amber-600' : 'text-slate-400' }}"></i>
                                    Grafik Progres
                                </span>
                            </a>
                        </nav>
                    @endauth
                </div>

                <!-- Right Actions / Profile -->
                <div class="flex items-center gap-3">
                    @auth
                        @if(Auth::user()->isAdmin())
                            <a href="{{ route('admin.dashboard') }}"
                                class="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 text-amber-800 hover:bg-amber-500/25 border border-amber-300 transition-colors">
                                <i data-lucide="shield-check" class="w-3.5 h-3.5 text-amber-600"></i>
                                Panel Admin
                            </a>
                        @endif

                        <!-- User Profile Menu -->
                        <div class="flex items-center gap-2">
                            <a href="{{ route('profile.index') }}" class="flex items-center gap-2.5 p-1.5 pr-3 rounded-full hover:bg-amber-50/60 transition-colors">
                                <div class="w-8 h-8 rounded-full bg-amber-100 text-amber-900 font-bold text-xs flex items-center justify-center border border-amber-300 shadow-xs">
                                    {{ strtoupper(substr(Auth::user()->name, 0, 2)) }}
                                </div>
                                <div class="hidden sm:block text-left">
                                    <p class="text-xs font-semibold text-slate-800 leading-tight">{{ Str::limit(Auth::user()->name, 16) }}</p>
                                    <p class="text-[10px] text-amber-700 font-medium">Akun {{ Auth::user()->role === 'admin' ? 'Admin' : 'Pribadi' }}</p>
                                </div>
                            </a>

                            <!-- Logout Form -->
                            <form action="{{ route('logout') }}" method="POST" class="inline">
                                @csrf
                                <button type="submit" title="Keluar dari akun" class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">
                                    <i data-lucide="log-out" class="w-4 h-4"></i>
                                </button>
                            </form>
                        </div>
                    @else
                        <div class="flex items-center gap-2">
                            <a href="{{ route('login') }}" class="px-4 py-2 text-sm font-semibold text-slate-700 hover:text-amber-800 hover:bg-amber-50 rounded-lg transition-colors">
                                Masuk
                            </a>
                            <a href="{{ route('register') }}" class="px-4 py-2 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-500 to-orange-400 hover:from-amber-300 hover:to-orange-300 rounded-lg shadow-sm shadow-amber-500/25 transition-all">
                                Daftar Gratis
                            </a>
                        </div>
                    @endauth
                </div>
            </div>
        </div>

        <!-- Mobile Navigation Strip for Authenticated Users -->
        @auth
            <div class="md:hidden border-t border-amber-200/60 bg-white/95 px-4 py-2 flex justify-around text-xs">
                <a href="{{ route('user.dashboard') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('user.dashboard') ? 'text-amber-600 font-bold' : 'text-slate-500' }}">
                    <i data-lucide="layout-dashboard" class="w-4 h-4 mb-0.5"></i>
                    <span>Beranda</span>
                </a>
                <a href="{{ route('amalan.index') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('amalan.*') ? 'text-amber-600 font-bold' : 'text-slate-500' }}">
                    <i data-lucide="check-circle-2" class="w-4 h-4 mb-0.5"></i>
                    <span>Amalan</span>
                </a>
                <a href="{{ route('journal.index') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('journal.*') ? 'text-amber-600 font-bold' : 'text-slate-500' }}">
                    <i data-lucide="book-heart" class="w-4 h-4 mb-0.5"></i>
                    <span>Jurnal</span>
                </a>
                <a href="{{ route('progress.index') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('progress.*') ? 'text-amber-600 font-bold' : 'text-slate-500' }}">
                    <i data-lucide="trending-up" class="w-4 h-4 mb-0.5"></i>
                    <span>Grafik</span>
                </a>
                <a href="{{ route('profile.index') }}" class="flex flex-col items-center py-1 {{ request()->routeIs('profile.*') ? 'text-amber-600 font-bold' : 'text-slate-500' }}">
                    <i data-lucide="user" class="w-4 h-4 mb-0.5"></i>
                    <span>Profil</span>
                </a>
            </div>
        @endauth
    </header>

    <!-- Global Toast / Flash Messages -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 w-full">
        @if(session('success'))
            <div class="flex items-center gap-3 p-4 mb-4 text-amber-950 bg-amber-50 border border-amber-300 rounded-xl shadow-xs transition-all animate-in fade-in slide-in-from-top-2" role="alert">
                <div class="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 font-bold">
                    <i data-lucide="check" class="w-4 h-4"></i>
                </div>
                <div class="text-sm font-medium">
                    {{ session('success') }}
                </div>
            </div>
        @endif

        @if(session('error'))
            <div class="flex items-center gap-3 p-4 mb-4 text-rose-800 bg-rose-50/90 border border-rose-200/90 rounded-xl shadow-xs transition-all animate-in fade-in slide-in-from-top-2" role="alert">
                <div class="w-8 h-8 rounded-lg bg-rose-600 text-white flex items-center justify-center shrink-0">
                    <i data-lucide="alert-circle" class="w-4 h-4"></i>
                </div>
                <div class="text-sm font-medium">
                    {{ session('error') }}
                </div>
            </div>
        @endif

        @if(session('info'))
            <div class="flex items-center gap-3 p-4 mb-4 text-amber-900 bg-amber-50 border border-amber-200 rounded-xl shadow-xs transition-all animate-in fade-in slide-in-from-top-2" role="alert">
                <div class="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center shrink-0">
                    <i data-lucide="info" class="w-4 h-4"></i>
                </div>
                <div class="text-sm font-medium">
                    {{ session('info') }}
                </div>
            </div>
        @endif
    </div>

    <!-- Main Content Area -->
    <main class="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        @yield('content')
    </main>

    <!-- App Footer -->
    <footer class="mt-auto bg-white border-t border-amber-200/60 py-8 text-center text-xs text-slate-400">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div class="flex items-center gap-2">
                <div class="w-6 h-6 rounded-md bg-amber-500 flex items-center justify-center text-slate-950 font-bold">
                    <i data-lucide="sun" class="w-3.5 h-3.5"></i>
                </div>
                <span class="font-bold text-slate-800">{{ $appSettings['app_name'] ?? 'Sunnah Bloom' }}</span>
                <span class="hidden sm:inline">— {{ $appSettings['app_sub_header'] ?? 'Platform Digital Amalan Yaumi' }}</span>
            </div>
            <div class="text-xs text-slate-500 font-medium">
                {{ $appSettings['app_tagline'] ?? 'powered by Rumah Qur\'an Al-Izzah Cab. Singkawang' }}
            </div>
        </div>
    </footer>

    <!-- Initialize Lucide Icons -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            lucide.createIcons();
        });
    </script>
    @stack('scripts')
</body>
</html>

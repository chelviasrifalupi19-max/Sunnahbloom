<?php

use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AdminLoginActivityController;
use App\Http\Controllers\Admin\AdminStatisticController;
use App\Http\Controllers\Admin\AdminUserController;
use App\Http\Controllers\AmalanController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\JournalController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProgressController;
use App\Http\Controllers\UserDashboardController;
use Illuminate\Support\Facades\Route;

// Public routes
Route::get('/', [LandingController::class, 'index'])->name('home');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');

    // Forgot Password Flow
    Route::get('/forgot-password', [AuthController::class, 'showForgotPassword'])->name('password.request');
    Route::post('/forgot-password', [AuthController::class, 'sendResetLink'])->name('password.email');
    Route::get('/reset-password/{token}', [AuthController::class, 'showResetPassword'])->name('password.reset');
    Route::post('/reset-password', [AuthController::class, 'resetPassword'])->name('password.update');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// User Routes (Authenticated & Active)
Route::middleware(['auth', 'active'])->group(function () {
    Route::get('/dashboard', [UserDashboardController::class, 'index'])->name('user.dashboard');

    // Amalan Yaumi & Custom User Amalan
    Route::get('/amalan', [AmalanController::class, 'index'])->name('amalan.index');
    Route::post('/amalan/save', [AmalanController::class, 'save'])->name('amalan.save');
    Route::post('/amalan/custom', [AmalanController::class, 'storeCustomItem'])->name('amalan.custom.store');
    Route::put('/amalan/custom/{id}', [AmalanController::class, 'updateCustomItem'])->name('amalan.custom.update');
    Route::delete('/amalan/custom/{id}', [AmalanController::class, 'destroyCustomItem'])->name('amalan.custom.destroy');

    // Private Journal & Gratitude / Forgiveness
    Route::get('/journal', [JournalController::class, 'index'])->name('journal.index');
    Route::post('/journal', [JournalController::class, 'store'])->name('journal.store');
    Route::get('/journal/{id}', [JournalController::class, 'show'])->name('journal.show');
    Route::delete('/journal/{id}', [JournalController::class, 'destroy'])->name('journal.destroy');

    // Progress & History
    Route::get('/progress', [ProgressController::class, 'index'])->name('progress.index');

    // User Profile & Reminders
    Route::get('/profil', [ProfileController::class, 'index'])->name('profile.index');
    Route::put('/profil', [ProfileController::class, 'update'])->name('profile.update');
    Route::match(['post', 'put'], '/profil/reminders', [ProfileController::class, 'updateReminders'])->name('reminders.update');
});

// Admin Routes (Authenticated, Active, and Admin Role in Database)
Route::middleware(['auth', 'active', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

    // App Dynamic Settings (Logo, Branding, Tagline, Quotes)
    Route::get('/settings', [AdminDashboardController::class, 'settings'])->name('settings');
    Route::post('/settings', [AdminDashboardController::class, 'updateSettings'])->name('settings.update');

    // Access Codes / Licenses Management
    Route::get('/access-codes', [AdminDashboardController::class, 'accessCodes'])->name('access-codes.index');
    Route::post('/access-codes', [AdminDashboardController::class, 'storeAccessCode'])->name('access-codes.store');
    Route::post('/access-codes/{id}/toggle', [AdminDashboardController::class, 'toggleAccessCode'])->name('access-codes.toggle');
    Route::delete('/access-codes/{id}', [AdminDashboardController::class, 'destroyAccessCode'])->name('access-codes.destroy');

    // Master Amalan Items Management
    Route::get('/amalan-items', [AdminDashboardController::class, 'amalanItems'])->name('amalan-items.index');
    Route::post('/amalan-items', [AdminDashboardController::class, 'storeAmalanItem'])->name('amalan-items.store');
    Route::put('/amalan-items/{id}', [AdminDashboardController::class, 'updateAmalanItem'])->name('amalan-items.update');
    Route::delete('/amalan-items/{id}', [AdminDashboardController::class, 'destroyAmalanItem'])->name('amalan-items.destroy');

    // User Management
    Route::get('/users', [AdminUserController::class, 'index'])->name('users.index');
    Route::get('/users/{user}', [AdminUserController::class, 'show'])->name('users.show');
    Route::post('/users/{user}/toggle-status', [AdminUserController::class, 'toggleStatus'])->name('users.toggle-status');

    // Login Activity Tracking
    Route::get('/login-activities', [AdminLoginActivityController::class, 'index'])->name('login-activities.index');

    // Statistics & Reports
    Route::get('/statistics', [AdminStatisticController::class, 'index'])->name('statistics.index');
});

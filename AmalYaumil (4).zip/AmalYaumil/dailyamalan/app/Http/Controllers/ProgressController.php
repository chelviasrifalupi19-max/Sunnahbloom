<?php

namespace App\Http\Controllers;

use App\Models\DailyAmalan;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class ProgressController extends Controller
{
    public function index(Request $request): View
    {
        $user = Auth::user();

        // 14 days completion trend
        $trendDays = collect();
        for ($i = 13; $i >= 0; $i--) {
            $d = Carbon::today()->subDays($i);
            $record = DailyAmalan::where('user_id', $user->id)
                ->whereDate('date', $d->toDateString())
                ->first();

            $trendDays->push([
                'date_label' => $d->format('d M'),
                'rate' => $record ? $record->completion_rate : 0,
            ]);
        }

        // Amalan item breakdown: percentage of times checked over all recorded days
        $allAmalans = DailyAmalan::where('user_id', $user->id)->get();
        $totalRecorded = $allAmalans->count();

        $amalanStats = [];
        foreach (DailyAmalan::AMALAN_KEYS as $key => $meta) {
            $checkedCount = $allAmalans->where($key, true)->count();
            $percentage = $totalRecorded > 0 ? round(($checkedCount / $totalRecorded) * 100) : 0;
            $amalanStats[] = [
                'key' => $key,
                'label' => $meta['label'],
                'category' => $meta['category'],
                'icon' => $meta['icon'],
                'count' => $checkedCount,
                'percentage' => $percentage,
            ];
        }

        $overallAverage = $totalRecorded > 0 ? round((float) $allAmalans->avg('completion_rate'), 1) : 0;
        $highestRate = $totalRecorded > 0 ? $allAmalans->max('completion_rate') : 0;
        $perfectDays = $allAmalans->where('completion_rate', 100)->count();

        // Recent records paginated/limited
        $recentRecords = DailyAmalan::where('user_id', $user->id)
            ->orderByDesc('date')
            ->paginate(10);

        return view('user.progress', compact(
            'trendDays',
            'amalanStats',
            'totalRecorded',
            'overallAverage',
            'highestRate',
            'perfectDays',
            'recentRecords'
        ));
    }
}

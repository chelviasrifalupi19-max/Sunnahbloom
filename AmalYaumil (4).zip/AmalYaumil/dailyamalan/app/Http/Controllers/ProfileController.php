<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserReminder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class ProfileController extends Controller
{
    public function index(): View
    {
        $user = Auth::user();
        $recentLogins = $user->loginActivities()->take(5)->get();
        $reminder = UserReminder::firstOrCreate(['user_id' => $user->id]);

        return view('user.profile', compact('user', 'recentLogins', 'reminder'));
    }

    public function update(Request $request): RedirectResponse
    {
        /** @var User $user */
        $user = Auth::user();

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email,' . $user->id],
            'phone' => ['nullable', 'string', 'max:20'],
            'bio' => ['nullable', 'string', 'max:500'],
            'current_password' => ['nullable', 'required_with:new_password', 'string'],
            'new_password' => ['nullable', 'string', 'min:8', 'confirmed'],
        ], [
            'name.required' => 'Nama lengkap wajib diisi.',
            'email.required' => 'Email wajib diisi.',
            'email.unique' => 'Email sudah digunakan oleh akun lain.',
            'current_password.required_with' => 'Masukkan password saat ini untuk mengganti password baru.',
            'new_password.min' => 'Password baru minimal 8 karakter.',
            'new_password.confirmed' => 'Konfirmasi password baru tidak cocok.',
        ]);

        if (!empty($validated['new_password'])) {
            if (!Hash::check($validated['current_password'], $user->password)) {
                return back()->withErrors(['current_password' => 'Password saat ini tidak sesuai.']);
            }
            $user->password = Hash::make($validated['new_password']);
        }

        $user->name = $validated['name'];
        $user->email = $validated['email'];
        $user->phone = $validated['phone'] ?? null;
        $user->bio = $validated['bio'] ?? null;
        $user->save();

        return redirect()->route('profile.index')
            ->with('success', 'Profil Anda berhasil diperbarui 🌻');
    }

    /**
     * Update user daily prayer & mutaba'ah reminders.
     */
    public function updateReminders(Request $request): RedirectResponse
    {
        $user = Auth::user();
        $reminder = UserReminder::firstOrCreate(['user_id' => $user->id]);

        $validated = $request->validate([
            'reminder_morning' => ['nullable', 'string', 'regex:/^[0-2][0-9]:[0-5][0-9]$/'],
            'reminder_dhuha' => ['nullable', 'string', 'regex:/^[0-2][0-9]:[0-5][0-9]$/'],
            'reminder_evening' => ['nullable', 'string', 'regex:/^[0-2][0-9]:[0-5][0-9]$/'],
            'reminder_night' => ['nullable', 'string', 'regex:/^[0-2][0-9]:[0-5][0-9]$/'],
        ]);

        $reminder->reminder_morning = !empty($validated['reminder_morning']) ? $validated['reminder_morning'] : '05:00';
        $reminder->is_morning_active = $request->boolean('is_morning_active');
        $reminder->reminder_dhuha = !empty($validated['reminder_dhuha']) ? $validated['reminder_dhuha'] : '09:30';
        $reminder->is_dhuha_active = $request->boolean('is_dhuha_active');
        $reminder->reminder_evening = !empty($validated['reminder_evening']) ? $validated['reminder_evening'] : '17:45';
        $reminder->is_evening_active = $request->boolean('is_evening_active');
        $reminder->reminder_night = !empty($validated['reminder_night']) ? $validated['reminder_night'] : '21:00';
        $reminder->is_night_active = $request->boolean('is_night_active');
        $reminder->browser_notifications_enabled = $request->boolean('browser_notifications_enabled');
        $reminder->save();

        return redirect()->route('profile.index')
            ->with('success', 'Pengaturan jadwal pengingat ibadah harian berhasil disimpan 🔔🌻');
    }
}

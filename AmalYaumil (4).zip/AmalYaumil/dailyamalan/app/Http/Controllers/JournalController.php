<?php

namespace App\Http\Controllers;

use App\Models\JournalEntry;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class JournalController extends Controller
{
    public function index(Request $request): View
    {
        $user = Auth::user();
        $entries = JournalEntry::where('user_id', $user->id)
            ->orderByDesc('date')
            ->orderByDesc('created_at')
            ->paginate(6);

        // Check if user already made an entry today
        $todayEntry = JournalEntry::where('user_id', $user->id)
            ->whereDate('date', Carbon::today()->toDateString())
            ->first();

        return view('user.journal', compact('entries', 'todayEntry'));
    }

    public function store(Request $request): RedirectResponse
    {
        $user = Auth::user();

        $validated = $request->validate([
            'date' => ['required', 'date'],
            'title' => ['required', 'string', 'max:255'],
            'journal_content' => ['required', 'string'],
            'gratitude_notes' => ['nullable', 'string'],
            'forgiveness_reflection' => ['nullable', 'string'],
            'mood' => ['nullable', 'string', 'max:50'],
        ], [
            'title.required' => 'Judul jurnal wajib diisi.',
            'journal_content.required' => 'Isi catatan harian pribadi wajib diisi.',
        ]);

        $entry = JournalEntry::where('user_id', $user->id)
            ->whereDate('date', $validated['date'])
            ->first();

        if (!$entry) {
            $entry = new JournalEntry();
            $entry->user_id = $user->id;
            $entry->date = $validated['date'];
        }

        $entry->title = $validated['title'];
        $entry->journal_content = $validated['journal_content'];
        $entry->gratitude_notes = $validated['gratitude_notes'] ?? null;
        $entry->forgiveness_reflection = $validated['forgiveness_reflection'] ?? null;
        $entry->mood = $validated['mood'] ?? 'bersyukur';
        $entry->save();

        return redirect()->route('journal.index')
            ->with('success', 'Jurnal pribadi dan refleksi syukur berhasil disimpan secara aman 🔒🌻');
    }

    public function show(int $id): View|RedirectResponse
    {
        $user = Auth::user();
        $entry = JournalEntry::where('user_id', $user->id)->findOrFail($id);

        return view('user.journal-detail', compact('entry'));
    }

    public function destroy(int $id): RedirectResponse
    {
        $user = Auth::user();
        $entry = JournalEntry::where('user_id', $user->id)->findOrFail($id);
        $entry->delete();

        return redirect()->route('journal.index')
            ->with('info', 'Catatan jurnal berhasil dihapus.');
    }
}

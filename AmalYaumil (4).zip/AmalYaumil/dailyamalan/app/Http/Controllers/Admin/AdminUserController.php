<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DailyAmalan;
use App\Models\LoginActivity;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AdminUserController extends Controller
{
    public function index(Request $request): View
    {
        $search = $request->query('search');
        $roleFilter = $request->query('role', 'all');
        $statusFilter = $request->query('status', 'all');

        $query = User::withCount('dailyAmalans')
            ->withAvg('dailyAmalans', 'completion_rate');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        if ($roleFilter !== 'all') {
            $query->where('role', $roleFilter);
        }

        if ($statusFilter !== 'all') {
            $isActive = $statusFilter === 'active';
            $query->where('is_active', $isActive);
        }

        $users = $query->orderByDesc('created_at')->paginate(10)->withQueryString();

        // Summary counts
        $totalCount = User::count();
        $activeCount = User::where('is_active', true)->count();
        $inactiveCount = User::where('is_active', false)->count();

        return view('admin.users.index', compact(
            'users',
            'search',
            'roleFilter',
            'statusFilter',
            'totalCount',
            'activeCount',
            'inactiveCount'
        ));
    }

    public function show(User $user): View
    {
        $user->loadCount('dailyAmalans');
        $user->loadAvg('dailyAmalans', 'completion_rate');

        // Recent login activities of this user
        $loginActivities = LoginActivity::where('user_id', $user->id)
            ->latest('login_at')
            ->paginate(8);

        // Amalan history (strictly statistical, no personal reflections)
        $amalanHistory = DailyAmalan::where('user_id', $user->id)
            ->orderByDesc('date')
            ->take(10)
            ->get();

        // Breakdown count of amalan performed
        $allUserAmalans = DailyAmalan::where('user_id', $user->id)->get();
        $breakdown = [];
        foreach (DailyAmalan::AMALAN_KEYS as $key => $meta) {
            $done = $allUserAmalans->where($key, true)->count();
            $breakdown[] = [
                'label' => $meta['label'],
                'category' => $meta['category'],
                'count' => $done,
                'total' => $allUserAmalans->count(),
                'pct' => $allUserAmalans->count() > 0 ? round(($done / $allUserAmalans->count()) * 100) : 0,
            ];
        }

        return view('admin.users.show', compact('user', 'loginActivities', 'amalanHistory', 'breakdown'));
    }

    public function toggleStatus(Request $request, User $user): RedirectResponse
    {
        // Prevent admin from deactivating their own currently logged-in account
        if ($user->id === Auth::id()) {
            return back()->with('error', 'Anda tidak dapat menonaktifkan akun Anda sendiri.');
        }

        $user->is_active = !$user->is_active;
        $user->save();

        $statusText = $user->is_active ? 'diaktifkan' : 'dinonaktifkan';

        return back()->with('success', "Akun {$user->name} ({$user->email}) berhasil {$statusText}.");
    }
}

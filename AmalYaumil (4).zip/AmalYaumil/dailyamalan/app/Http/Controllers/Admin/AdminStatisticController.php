<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DailyAmalan;
use App\Models\LoginActivity;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminStatisticController extends Controller
{
    public function index(Request $request): View
    {
        $totalUsers = User::count();
        $totalAmalanEntries = DailyAmalan::count();
        $allAmalans = DailyAmalan::all();

        // 1. Compliance rate for each amalan item
        $amalanStats = [];
        foreach (DailyAmalan::AMALAN_KEYS as $key => $meta) {
            $count = $allAmalans->where($key, true)->count();
            $percentage = $totalAmalanEntries > 0 ? round(($count / $totalAmalanEntries) * 100, 1) : 0;
            $amalanStats[] = [
                'key' => $key,
                'label' => $meta['label'],
                'category' => $meta['category'],
                'icon' => $meta['icon'],
                'count' => $count,
                'percentage' => $percentage,
            ];
        }

        // Sort by percentage descending
        usort($amalanStats, fn($a, $b) => $b['percentage'] <=> $a['percentage']);

        // 2. User Engagement Segmentation
        $users = User::withAvg('dailyAmalans', 'completion_rate')->get();
        $highEngagement = 0;   // >= 75%
        $mediumEngagement = 0; // 40% - 74%
        $lowEngagement = 0;    // 1% - 39%
        $zeroEngagement = 0;   // 0% or no entries

        foreach ($users as $u) {
            $rate = (float) ($u->daily_amalans_avg_completion_rate ?? 0);
            if ($rate >= 75) {
                $highEngagement++;
            } elseif ($rate >= 40) {
                $mediumEngagement++;
            } elseif ($rate > 0) {
                $lowEngagement++;
            } else {
                $zeroEngagement++;
            }
        }

        // 3. Device & Platform Distribution from Login Activities
        $recentActivities = LoginActivity::latest('login_at')->take(200)->get();
        $deviceBreakdown = [
            'Windows' => 0,
            'macOS' => 0,
            'iOS (iPhone)' => 0,
            'Android' => 0,
            'Linux / Other' => 0,
        ];

        foreach ($recentActivities as $act) {
            $agent = $act->user_agent ?? '';
            if (str_contains($agent, 'Windows')) {
                $deviceBreakdown['Windows']++;
            } elseif (str_contains($agent, 'Macintosh') || str_contains($agent, 'Mac OS')) {
                $deviceBreakdown['macOS']++;
            } elseif (str_contains($agent, 'iPhone')) {
                $deviceBreakdown['iOS (iPhone)']++;
            } elseif (str_contains($agent, 'Android')) {
                $deviceBreakdown['Android']++;
            } else {
                $deviceBreakdown['Linux / Other']++;
            }
        }

        return view('admin.statistics.index', compact(
            'totalUsers',
            'totalAmalanEntries',
            'amalanStats',
            'highEngagement',
            'mediumEngagement',
            'lowEngagement',
            'zeroEngagement',
            'deviceBreakdown'
        ));
    }
}

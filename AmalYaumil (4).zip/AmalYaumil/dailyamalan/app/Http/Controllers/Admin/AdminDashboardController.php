<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AccessCode;
use App\Models\AmalanItem;
use App\Models\AppSetting;
use App\Models\DailyAmalan;
use App\Models\LoginActivity;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class AdminDashboardController extends Controller
{
    public function index(Request $request): View
    {
        $today = Carbon::today();

        // 1. Total Pengguna Terdaftar
        $totalUsers = User::count();
        $totalRegularUsers = User::where('role', 'user')->count();
        $newUsersThisWeek = User::where('created_at', '>=', now()->subDays(7))->count();

        // 2. Pengguna yang sedang / terakhir aktif (dalam 15 menit terakhir)
        $activeThreshold = now()->subMinutes(15);
        $activeUsersCount = User::where('last_login_at', '>=', $activeThreshold)->count();

        // Pengguna aktif hari ini
        $activeTodayCount = User::whereDate('last_login_at', $today)->count();

        // 3. Jumlah pengguna yang login hari ini (dari riwayat login unik hari ini)
        $loggedInTodayCount = LoginActivity::whereDate('login_at', $today)
            ->distinct('user_id')
            ->count('user_id');

        // 4. Jumlah pengguna yang mengisi Amalan Yaumi hari ini & total entri
        $usersFilledAmalanTodayCount = DailyAmalan::whereDate('date', $today)
            ->where('completion_rate', '>', 0)
            ->distinct('user_id')
            ->count('user_id');

        $totalUsersEverFilledAmalan = DailyAmalan::distinct('user_id')->count('user_id');
        $totalAmalanEntries = DailyAmalan::count();
        $globalAvgAmalan = round((float) (DailyAmalan::avg('completion_rate') ?? 0), 1);

        // 5. Statistik jumlah pengguna dari waktu ke waktu (6 bulan terakhir)
        $userGrowth = collect();
        for ($i = 5; $i >= 0; $i--) {
            $month = Carbon::today()->subMonths($i);
            $monthStart = $month->copy()->startOfMonth();
            $monthEnd = $month->copy()->endOfMonth();

            $cumulativeUsers = User::where('created_at', '<=', $monthEnd)->count();
            $newInMonth = User::whereBetween('created_at', [$monthStart, $monthEnd])->count();

            $userGrowth->push([
                'month_label' => $month->translatedFormat('M Y'),
                'total_users' => $cumulativeUsers,
                'new_users' => $newInMonth,
            ]);
        }

        // 6. Tren pengisian amalan 7 hari terakhir
        $amalanWeeklyTrend = collect();
        for ($i = 6; $i >= 0; $i--) {
            $d = Carbon::today()->subDays($i);
            $entries = DailyAmalan::whereDate('date', $d->toDateString())->get();
            $amalanWeeklyTrend->push([
                'date_label' => $d->translatedFormat('D, d M'),
                'entries_count' => $entries->count(),
                'avg_rate' => $entries->count() > 0 ? round((float) $entries->avg('completion_rate'), 1) : 0,
            ]);
        }

        // Recent login activities (latest 6)
        $recentLogins = LoginActivity::with('user')
            ->latest('login_at')
            ->take(6)
            ->get();

        // Recent registered users with amalan stats
        $recentUsers = User::withCount('dailyAmalans')
            ->withAvg('dailyAmalans', 'completion_rate')
            ->latest('created_at')
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'totalUsers',
            'totalRegularUsers',
            'newUsersThisWeek',
            'activeUsersCount',
            'activeTodayCount',
            'loggedInTodayCount',
            'usersFilledAmalanTodayCount',
            'totalUsersEverFilledAmalan',
            'totalAmalanEntries',
            'globalAvgAmalan',
            'userGrowth',
            'amalanWeeklyTrend',
            'recentLogins',
            'recentUsers'
        ));
    }

    /**
     * View Dynamic App Settings.
     */
    public function settings(): View
    {
        $settings = AppSetting::allKeyed();

        return view('admin.settings.index', compact('settings'));
    }

    /**
     * Update Dynamic App Settings.
     */
    public function updateSettings(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'app_name' => ['required', 'string', 'max:100'],
            'app_sub_header' => ['required', 'string', 'max:200'],
            'app_tagline' => ['required', 'string', 'max:255'],
            'app_institution' => ['required', 'string', 'max:255'],
            'daily_quote' => ['required', 'string', 'max:1000'],
            'daily_quote_source' => ['required', 'string', 'max:100'],
            'registration_requires_access_code' => ['nullable'],
            'default_access_code' => ['required', 'string', 'max:50'],
        ]);

        AppSetting::set('app_name', $validated['app_name']);
        AppSetting::set('app_sub_header', $validated['app_sub_header']);
        AppSetting::set('app_tagline', $validated['app_tagline']);
        AppSetting::set('app_institution', $validated['app_institution']);
        AppSetting::set('daily_quote', $validated['daily_quote']);
        AppSetting::set('daily_quote_source', $validated['daily_quote_source']);
        AppSetting::set('registration_requires_access_code', $request->has('registration_requires_access_code') ? '1' : '0');
        AppSetting::set('default_access_code', strtoupper(trim($validated['default_access_code'])));

        AppSetting::clearCache();

        return redirect()->route('admin.settings')
            ->with('success', 'Pengaturan aplikasi, branding lembaga, dan kutipan mutiara harian berhasil disimpan 🌻');
    }

    /**
     * View Access Codes / Licenses Management.
     */
    public function accessCodes(): View
    {
        $codes = AccessCode::with('creator')->latest()->paginate(15);

        return view('admin.access-codes.index', compact('codes'));
    }

    /**
     * Store new Access Code.
     */
    public function storeAccessCode(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'code' => ['required', 'string', 'max:50', 'unique:access_codes,code'],
            'label' => ['required', 'string', 'max:100'],
            'max_uses' => ['nullable', 'integer', 'min:1'],
            'expires_at' => ['nullable', 'date', 'after:today'],
        ]);

        AccessCode::create([
            'code' => strtoupper(trim($validated['code'])),
            'label' => $validated['label'],
            'max_uses' => !empty($validated['max_uses']) ? $validated['max_uses'] : null,
            'expires_at' => !empty($validated['expires_at']) ? $validated['expires_at'] : null,
            'is_active' => true,
            'created_by' => auth()->id(),
        ]);

        return redirect()->route('admin.access-codes.index')
            ->with('success', 'Kode akses / lisensi ' . strtoupper($validated['code']) . ' berhasil diterbitkan!');
    }

    /**
     * Toggle active status of Access Code.
     */
    public function toggleAccessCode(int $id): RedirectResponse
    {
        $code = AccessCode::findOrFail($id);
        $code->is_active = !$code->is_active;
        $code->save();

        $status = $code->is_active ? 'diaktifkan' : 'dinonaktifkan';

        return redirect()->route('admin.access-codes.index')
            ->with('info', "Kode akses {$code->code} berhasil {$status}.");
    }

    /**
     * Delete Access Code.
     */
    public function destroyAccessCode(int $id): RedirectResponse
    {
        $code = AccessCode::findOrFail($id);
        $code->delete();

        return redirect()->route('admin.access-codes.index')
            ->with('info', "Kode akses {$code->code} berhasil dihapus.");
    }

    /**
     * View Master Amalan Items.
     */
    public function amalanItems(): View
    {
        $masterItems = AmalanItem::master()->orderBy('order')->get();

        return view('admin.amalan-items.index', compact('masterItems'));
    }

    /**
     * Store new Master Amalan Item.
     */
    public function storeAmalanItem(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'label' => ['required', 'string', 'max:100'],
            'category' => ['required', 'string', 'in:wajib,sunnah,quran,dzikir,kebaikan'],
            'icon' => ['nullable', 'string', 'max:50'],
        ]);

        $key = 'master_' . Str::slug($validated['label'], '_') . '_' . time();
        $highestOrder = (int) AmalanItem::master()->max('order');

        AmalanItem::create([
            'user_id' => null,
            'key' => $key,
            'label' => $validated['label'],
            'category' => $validated['category'],
            'icon' => !empty($validated['icon']) ? $validated['icon'] : 'check-circle',
            'order' => $highestOrder + 1,
            'is_active' => true,
        ]);

        return redirect()->route('admin.amalan-items.index')
            ->with('success', "Amalan master '{$validated['label']}' berhasil ditambahkan ke seluruh jamaah!");
    }

    /**
     * Update Master Amalan Item.
     */
    public function updateAmalanItem(Request $request, int $id): RedirectResponse
    {
        $item = AmalanItem::master()->findOrFail($id);

        $validated = $request->validate([
            'label' => ['required', 'string', 'max:100'],
            'category' => ['required', 'string', 'in:wajib,sunnah,quran,dzikir,kebaikan'],
            'icon' => ['nullable', 'string', 'max:50'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $item->label = $validated['label'];
        $item->category = $validated['category'];
        $item->icon = !empty($validated['icon']) ? $validated['icon'] : ($item->icon ?: 'check-circle');
        $item->is_active = $request->boolean('is_active');
        $item->save();

        return redirect()->route('admin.amalan-items.index')
            ->with('success', "Master amalan '{$item->label}' berhasil diperbarui!");
    }

    /**
     * Delete Master Amalan Item.
     */
    public function destroyAmalanItem(int $id): RedirectResponse
    {
        $item = AmalanItem::master()->findOrFail($id);
        $label = $item->label;
        $item->delete();

        return redirect()->route('admin.amalan-items.index')
            ->with('info', "Master amalan '{$label}' berhasil dihapus.");
    }
}

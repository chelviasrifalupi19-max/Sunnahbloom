<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LoginActivity;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminLoginActivityController extends Controller
{
    public function index(Request $request): View
    {
        $search = $request->query('search');
        $dateFilter = $request->query('date');

        $query = LoginActivity::with('user');

        if ($search) {
            $query->whereHas('user', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            })->orWhere('ip_address', 'like', "%{$search}%");
        }

        if ($dateFilter) {
            $query->whereDate('login_at', $dateFilter);
        }

        $activities = $query->latest('login_at')->paginate(15)->withQueryString();

        $totalLoginsToday = LoginActivity::whereDate('login_at', today())->count();
        $uniqueUsersToday = LoginActivity::whereDate('login_at', today())->distinct('user_id')->count('user_id');
        $totalAllTime = LoginActivity::count();

        return view('admin.login-activities.index', compact(
            'activities',
            'search',
            'dateFilter',
            'totalLoginsToday',
            'uniqueUsersToday',
            'totalAllTime'
        ));
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\AmalanItem;
use App\Models\DailyAmalan;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\View\View;

class AmalanController extends Controller
{
    public function index(Request $request): View
    {
        $user = Auth::user();
        $dateParam = $request->query('date', Carbon::today()->toDateString());

        try {
            $selectedDate = Carbon::parse($dateParam);
        } catch (\Exception $e) {
            $selectedDate = Carbon::today();
        }

        $amalan = DailyAmalan::where('user_id', $user->id)
            ->whereDate('date', $selectedDate->toDateString())
            ->first();

        if (!$amalan) {
            $amalan = DailyAmalan::create([
                'user_id' => $user->id,
                'date' => $selectedDate->toDateString(),
                'completion_rate' => 0,
                'checked_items' => [],
            ]);
        }

        // Fetch dynamic items for this user (Master + User Custom)
        $keys = DailyAmalan::getActiveItemsForUser($user->id);

        // Fetch user's custom items for management modal
        $myCustomItems = AmalanItem::where('user_id', $user->id)->orderBy('created_at')->get();

        // Group amalan items by category
        $categories = [
            'wajib' => ['title' => 'Sholat Wajib 5 Waktu', 'badge' => 'Fardhu Utama', 'color' => 'amber'],
            'sunnah' => ['title' => 'Sholat Sunnah', 'badge' => 'Penyempurna', 'color' => 'amber'],
            'quran' => ['title' => 'Al-Qur\'an & Tilawah', 'badge' => 'Cahaya Hati & ODOJ', 'color' => 'amber'],
            'dzikir' => ['title' => 'Dzikir & Doa', 'badge' => 'Penentram Jiwa', 'color' => 'amber'],
            'kebaikan' => ['title' => 'Muamalah & Kebaikan', 'badge' => 'Investasi Akhirat', 'color' => 'amber'],
            'pribadi' => ['title' => 'Target Amalan Pribadi', 'badge' => 'Kustom Mandiri', 'color' => 'amber'],
        ];

        return view('user.amalan', compact('amalan', 'selectedDate', 'keys', 'categories', 'myCustomItems'));
    }

    public function save(Request $request): RedirectResponse
    {
        $user = Auth::user();
        $date = $request->input('date', Carbon::today()->toDateString());

        $amalan = DailyAmalan::where('user_id', $user->id)
            ->whereDate('date', $date)
            ->first();

        if (!$amalan) {
            $amalan = new DailyAmalan();
            $amalan->user_id = $user->id;
            $amalan->date = $date;
        }

        $availableKeys = array_keys(DailyAmalan::getActiveItemsForUser($user->id));
        $checkedList = [];

        foreach ($availableKeys as $key) {
            $isChecked = $request->boolean($key);
            if ($isChecked) {
                $checkedList[] = $key;
            }

            // Sync with physical boolean column if it exists
            if (array_key_exists($key, DailyAmalan::AMALAN_KEYS)) {
                $amalan->{$key} = $isChecked;
            }
        }

        $amalan->checked_items = $checkedList;
        $amalan->notes = $request->input('notes');
        $amalan->completion_rate = $amalan->computeRate($availableKeys);
        $amalan->save();

        return redirect()->route('amalan.index', ['date' => $date])
            ->with('success', "Amalan Yaumi tanggal {$amalan->date->translatedFormat('d F Y')} berhasil disimpan! Capaian: {$amalan->completion_rate}% 🌻");
    }

    /**
     * Store personal custom amalan item for the authenticated user.
     */
    public function storeCustomItem(Request $request): RedirectResponse
    {
        $user = Auth::user();

        $validated = $request->validate([
            'label' => ['required', 'string', 'max:100'],
            'category' => ['required', 'string', 'in:wajib,sunnah,quran,dzikir,kebaikan,pribadi'],
            'icon' => ['nullable', 'string', 'max:50'],
        ], [
            'label.required' => 'Nama amalan wajib diisi.',
        ]);

        $key = 'custom_' . $user->id . '_' . Str::slug($validated['label'], '_') . '_' . time();
        $highestOrder = (int) AmalanItem::forUser($user->id)->max('order');

        AmalanItem::create([
            'user_id' => $user->id,
            'key' => $key,
            'label' => $validated['label'],
            'category' => !empty($validated['category']) ? $validated['category'] : 'pribadi',
            'icon' => !empty($validated['icon']) ? $validated['icon'] : 'sparkles',
            'order' => $highestOrder + 1,
            'is_active' => true,
        ]);

        return redirect()->back()
            ->with('success', "Amalan pribadi '{$validated['label']}' berhasil ditambahkan ke daftar checklist!");
    }

    /**
     * Update personal custom amalan item.
     */
    public function updateCustomItem(Request $request, int $id): RedirectResponse
    {
        $user = Auth::user();
        $item = AmalanItem::where('user_id', $user->id)->findOrFail($id);

        $validated = $request->validate([
            'label' => ['required', 'string', 'max:100'],
            'category' => ['required', 'string', 'in:wajib,sunnah,quran,dzikir,kebaikan,pribadi'],
            'icon' => ['nullable', 'string', 'max:50'],
        ]);

        $item->label = $validated['label'];
        $item->category = $validated['category'];
        $item->icon = !empty($validated['icon']) ? $validated['icon'] : ($item->icon ?: 'sparkles');
        $item->save();

        return redirect()->back()
            ->with('success', "Amalan pribadi '{$item->label}' berhasil diperbarui!");
    }

    /**
     * Delete personal custom amalan item.
     */
    public function destroyCustomItem(int $id): RedirectResponse
    {
        $user = Auth::user();
        $item = AmalanItem::where('user_id', $user->id)->findOrFail($id);
        $label = $item->label;
        $item->delete();

        return redirect()->back()
            ->with('info', "Amalan pribadi '{$label}' berhasil dihapus.");
    }
}

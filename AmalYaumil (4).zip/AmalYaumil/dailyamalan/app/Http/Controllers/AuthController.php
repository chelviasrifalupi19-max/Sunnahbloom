<?php

namespace App\Http\Controllers;

use App\Models\AccessCode;
use App\Models\AppSetting;
use App\Models\LoginActivity;
use App\Models\User;
use App\Models\UserReminder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\View\View;

class AuthController extends Controller
{
    /**
     * Show login view.
     */
    public function showLogin(): View|RedirectResponse
    {
        if (Auth::check()) {
            return Auth::user()->isAdmin()
                ? redirect()->route('admin.dashboard')
                : redirect()->route('user.dashboard');
        }

        return view('auth.login');
    }

    /**
     * Handle user login.
     */
    public function login(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ], [
            'email.required' => 'Email wajib diisi.',
            'email.email' => 'Format email tidak valid.',
            'password.required' => 'Password wajib diisi.',
        ]);

        $user = User::where('email', $credentials['email'])->first();

        // Check if account exists and is inactive
        if ($user && !$user->isActive()) {
            return back()->withInput($request->only('email'))->withErrors([
                'email' => 'Akun Anda dinonaktifkan oleh administrator. Silakan hubungi pengelola aplikasi.',
            ]);
        }

        $remember = $request->boolean('remember');

        if (Auth::attempt($credentials, $remember)) {
            $request->session()->regenerate();

            /** @var User $authenticatedUser */
            $authenticatedUser = Auth::user();
            $authenticatedUser->update(['last_login_at' => now()]);

            // Record login activity
            $activity = LoginActivity::create([
                'user_id' => $authenticatedUser->id,
                'login_at' => now(),
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ]);

            session(['current_login_activity_id' => $activity->id]);

            if ($authenticatedUser->isAdmin()) {
                return redirect()->intended(route('admin.dashboard'))
                    ->with('success', 'Selamat datang kembali, Administrator ' . $authenticatedUser->name . '!');
            }

            return redirect()->intended(route('user.dashboard'))
                ->with('success', 'Selamat datang kembali, ' . $authenticatedUser->name . ' 🌻');
        }

        return back()->withInput($request->only('email'))->withErrors([
            'email' => 'Email atau password yang Anda masukkan salah.',
        ]);
    }

    /**
     * Show register view.
     */
    public function showRegister(): View|RedirectResponse
    {
        if (Auth::check()) {
            return Auth::user()->isAdmin()
                ? redirect()->route('admin.dashboard')
                : redirect()->route('user.dashboard');
        }

        return view('auth.register');
    }

    /**
     * Handle user registration.
     */
    public function register(Request $request): RedirectResponse
    {
        $requiresAccessCode = AppSetting::get('registration_requires_access_code', '1') === '1';

        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'phone' => ['nullable', 'string', 'max:20'],
        ];

        if ($requiresAccessCode) {
            $rules['access_code'] = ['required', 'string'];
        }

        $validated = $request->validate($rules, [
            'name.required' => 'Nama lengkap wajib diisi.',
            'email.required' => 'Email wajib diisi.',
            'email.unique' => 'Email ini sudah terdaftar.',
            'password.required' => 'Password wajib diisi.',
            'password.min' => 'Password minimal 8 karakter.',
            'password.confirmed' => 'Konfirmasi password tidak cocok.',
            'access_code.required' => 'Kode akses lisensi lembaga wajib diisi untuk registrasi internal.',
        ]);

        $accessCodeModel = null;
        if ($requiresAccessCode) {
            $accessCodeInput = strtoupper(trim($validated['access_code']));
            $accessCodeModel = AccessCode::where('code', $accessCodeInput)->first();

            if (!$accessCodeModel || !$accessCodeModel->isValid()) {
                return back()->withInput()->withErrors([
                    'access_code' => 'Kode akses lisensi tidak valid, dinonaktifkan, atau kuota penggunaan telah habis. Hubungi pengurus RQ Al-Izzah.',
                ]);
            }
        }

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'role' => 'user',
            'is_active' => true,
            'last_login_at' => now(),
            'phone' => $validated['phone'] ?? null,
            'access_code_used' => $accessCodeModel ? $accessCodeModel->code : null,
        ]);

        if ($accessCodeModel) {
            $accessCodeModel->incrementUsage();
        }

        // Initialize default user reminder settings
        UserReminder::firstOrCreate(
            ['user_id' => $user->id],
            [
                'reminder_morning' => '05:00',
                'is_morning_active' => true,
                'reminder_dhuha' => '09:30',
                'is_dhuha_active' => true,
                'reminder_evening' => '17:45',
                'is_evening_active' => true,
                'reminder_night' => '21:00',
                'is_night_active' => true,
                'browser_notifications_enabled' => false,
            ]
        );

        Auth::login($user);
        $request->session()->regenerate();

        // Record initial login activity
        $activity = LoginActivity::create([
            'user_id' => $user->id,
            'login_at' => now(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        session(['current_login_activity_id' => $activity->id]);

        return redirect()->route('user.dashboard')
            ->with('success', 'Selamat datang di ' . AppSetting::get('app_name', 'Sunnah Bloom') . '! Mari awali hari dengan niat terbaik 🌻');
    }

    /**
     * Show forgot password view.
     */
    public function showForgotPassword(): View
    {
        return view('auth.forgot-password');
    }

    /**
     * Send password reset link / simulation code.
     */
    public function sendResetLink(Request $request): RedirectResponse
    {
        $request->validate([
            'email' => ['required', 'email', 'exists:users,email'],
        ], [
            'email.required' => 'Alamat email wajib diisi.',
            'email.exists' => 'Alamat email tersebut tidak terdaftar di sistem kami.',
        ]);

        $token = Str::random(64);

        DB::table('password_reset_tokens')->updateOrInsert(
            ['email' => $request->email],
            [
                'token' => Hash::make($token),
                'created_at' => now(),
            ]
        );

        $resetUrl = route('password.reset', ['token' => $token, 'email' => $request->email]);

        return back()->with([
            'status' => 'Tautan pemulihan kata sandi telah berhasil disiapkan!',
            'success' => 'Tautan pemulihan kata sandi telah berhasil disiapkan!',
            'simulation_url' => $resetUrl,
        ]);
    }

    /**
     * Show reset password view.
     */
    public function showResetPassword(Request $request, string $token): View
    {
        return view('auth.reset-password', [
            'token' => $token,
            'email' => $request->query('email', ''),
        ]);
    }

    /**
     * Handle password reset submission.
     */
    public function resetPassword(Request $request): RedirectResponse
    {
        $request->validate([
            'token' => ['required'],
            'email' => ['required', 'email'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ], [
            'password.required' => 'Kata sandi baru wajib diisi.',
            'password.min' => 'Kata sandi minimal 8 karakter.',
            'password.confirmed' => 'Konfirmasi kata sandi tidak cocok.',
        ]);

        $resetRecord = DB::table('password_reset_tokens')
            ->where('email', $request->email)
            ->first();

        if (!$resetRecord || !Hash::check($request->token, $resetRecord->token)) {
            return back()->withErrors(['email' => 'Token pemulihan kata sandi tidak valid atau telah kedaluwarsa.']);
        }

        $user = User::where('email', $request->email)->first();
        if (!$user) {
            return back()->withErrors(['email' => 'Pengguna tidak ditemukan.']);
        }

        $user->update(['password' => Hash::make($request->password)]);

        DB::table('password_reset_tokens')->where('email', $request->email)->delete();

        return redirect()->route('login')->with('success', 'Kata sandi Anda berhasil diperbarui! Silakan masuk dengan kata sandi baru Anda.');
    }

    /**
     * Handle logout.
     */
    public function logout(Request $request): RedirectResponse
    {
        $activityId = session('current_login_activity_id');
        if ($activityId) {
            $activity = LoginActivity::find($activityId);
            if ($activity && !$activity->logout_at) {
                $activity->update(['logout_at' => now()]);
            }
        }

        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('info', 'Anda telah berhasil keluar. Sampai jumpa kembali!');
    }
}

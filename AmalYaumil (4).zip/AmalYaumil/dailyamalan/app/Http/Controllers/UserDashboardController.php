<?php

namespace App\Http\Controllers;

use App\Models\DailyAmalan;
use App\Models\JournalEntry;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class UserDashboardController extends Controller
{
    public function index(Request $request): View
    {
        /** @var User $user */
        $user = Auth::user();
        $today = Carbon::today();

        // Today's amalan
        $todayAmalan = DailyAmalan::where('user_id', $user->id)
            ->whereDate('date', $today->toDateString())
            ->first();

        if (!$todayAmalan) {
            $todayAmalan = DailyAmalan::create([
                'user_id' => $user->id,
                'date' => $today->toDateString(),
                'completion_rate' => 0,
            ]);
        }

        // Calculate user streak (consecutive days of amalan)
        $streak = 0;
        $checkDate = $today->copy();
        while (true) {
            $exists = DailyAmalan::where('user_id', $user->id)
                ->whereDate('date', $checkDate->toDateString())
                ->where('completion_rate', '>', 0)
                ->exists();

            if ($exists) {
                $streak++;
                $checkDate->subDay();
            } else {
                // If today is not filled yet, check from yesterday before breaking streak
                if ($checkDate->isSameDay($today) && $todayAmalan->completion_rate === 0) {
                    $checkDate->subDay();
                    $yesterdayExists = DailyAmalan::where('user_id', $user->id)
                        ->whereDate('date', $checkDate->toDateString())
                        ->where('completion_rate', '>', 0)
                        ->exists();

                    if ($yesterdayExists) {
                        $streak++;
                        $checkDate->subDay();
                        continue;
                    }
                }
                break;
            }
        }

        // Last 7 days history for mini progress bar
        $last7Days = collect();
        for ($i = 6; $i >= 0; $i--) {
            $d = Carbon::today()->subDays($i);
            $record = DailyAmalan::where('user_id', $user->id)
                ->whereDate('date', $d->toDateString())
                ->first();

            $last7Days->push([
                'day' => $d->isoFormat('dd'),
                'date' => $d->format('d/m'),
                'is_today' => $d->isToday(),
                'rate' => $record ? $record->completion_rate : 0,
            ]);
        }

        // User stats
        $totalDays = $user->totalAmalanDays();
        $avgPercentage = $user->averageAmalanPercentage();
        $totalJournals = JournalEntry::where('user_id', $user->id)->count();
        $latestJournal = JournalEntry::where('user_id', $user->id)->latest('date')->first();

        return view('user.dashboard', compact(
            'user',
            'todayAmalan',
            'streak',
            'last7Days',
            'totalDays',
            'avgPercentage',
            'totalJournals',
            'latestJournal'
        ));
    }
}

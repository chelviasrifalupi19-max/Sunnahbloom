<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable([
    'user_id',
    'date',
    'sholat_subuh',
    'sholat_dzuhur',
    'sholat_ashar',
    'sholat_maghrib',
    'sholat_isya',
    'sholat_dhuha',
    'sholat_tahajud',
    'sholat_rawatib',
    'tilawah_quran',
    'odoj_one_juz',
    'dzikir_pagi',
    'dzikir_petang',
    'infaq_sedekah',
    'puasa_sunnah',
    'membaca_ilmu',
    'completion_rate',
    'notes',
    'checked_items',
])]
class DailyAmalan extends Model
{
    use HasFactory;

    public const AMALAN_KEYS = [
        'sholat_subuh' => ['label' => 'Sholat Subuh Tepat Waktu', 'category' => 'wajib', 'icon' => 'sunrise'],
        'sholat_dzuhur' => ['label' => 'Sholat Dzuhur', 'category' => 'wajib', 'icon' => 'sun'],
        'sholat_ashar' => ['label' => 'Sholat Ashar', 'category' => 'wajib', 'icon' => 'sun-medium'],
        'sholat_maghrib' => ['label' => 'Sholat Maghrib', 'category' => 'wajib', 'icon' => 'sunset'],
        'sholat_isya' => ['label' => 'Sholat Isya', 'category' => 'wajib', 'icon' => 'moon'],
        'sholat_dhuha' => ['label' => 'Sholat Dhuha', 'category' => 'sunnah', 'icon' => 'sparkles'],
        'sholat_tahajud' => ['label' => 'Tahajud / Qiyamul Lail', 'category' => 'sunnah', 'icon' => 'moon-star'],
        'sholat_rawatib' => ['label' => 'Sholat Sunnah Rawatib', 'category' => 'sunnah', 'icon' => 'heart-handshake'],
        'tilawah_quran' => ['label' => 'Tilawah Al-Qur\'an', 'category' => 'quran', 'icon' => 'book-open'],
        'odoj_one_juz' => ['label' => 'ODOJ 1 Juz (1 Hari 1 Juz)', 'category' => 'quran', 'icon' => 'book-marked'],
        'dzikir_pagi' => ['label' => 'Dzikir Pagi (Al-Ma\'tsurat)', 'category' => 'dzikir', 'icon' => 'compass'],
        'dzikir_petang' => ['label' => 'Dzikir Petang', 'category' => 'dzikir', 'icon' => 'shield-check'],
        'infaq_sedekah' => ['label' => 'Infaq / Sedekah Subuh', 'category' => 'kebaikan', 'icon' => 'gift'],
        'puasa_sunnah' => ['label' => 'Puasa Sunnah', 'category' => 'kebaikan', 'icon' => 'coffee'],
        'membaca_ilmu' => ['label' => 'Membaca Buku / Hadits', 'category' => 'kebaikan', 'icon' => 'bookmark'],
    ];

    protected function casts(): array
    {
        return [
            'date' => 'date',
            'sholat_subuh' => 'boolean',
            'sholat_dzuhur' => 'boolean',
            'sholat_ashar' => 'boolean',
            'sholat_maghrib' => 'boolean',
            'sholat_isya' => 'boolean',
            'sholat_dhuha' => 'boolean',
            'sholat_tahajud' => 'boolean',
            'sholat_rawatib' => 'boolean',
            'tilawah_quran' => 'boolean',
            'odoj_one_juz' => 'boolean',
            'dzikir_pagi' => 'boolean',
            'dzikir_petang' => 'boolean',
            'infaq_sedekah' => 'boolean',
            'puasa_sunnah' => 'boolean',
            'membaca_ilmu' => 'boolean',
            'completion_rate' => 'integer',
            'checked_items' => 'array',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get active items available for a user (Master + User's Custom Items).
     */
    public static function getActiveItemsForUser(?int $userId = null): array
    {
        try {
            $dbItems = AmalanItem::forUser($userId)
                ->active()
                ->orderBy('order')
                ->get();

            if ($dbItems->isNotEmpty()) {
                $mapped = [];
                foreach ($dbItems as $item) {
                    $mapped[$item->key] = [
                        'id' => $item->id,
                        'label' => $item->label,
                        'category' => $item->category,
                        'icon' => $item->icon ?: 'check-circle',
                        'is_custom' => $item->isCustom(),
                        'user_id' => $item->user_id,
                    ];
                }
                return $mapped;
            }
        } catch (\Throwable $e) {
            // fallback
        }

        return self::AMALAN_KEYS;
    }

    /**
     * Check if a specific amalan item is marked as completed.
     */
    public function isChecked(string $key): bool
    {
        if (is_array($this->checked_items)) {
            return in_array($key, $this->checked_items, true);
        }

        return (bool) ($this->{$key} ?? false);
    }

    /**
     * Compute completion rate automatically.
     */
    public function computeRate(?array $availableKeys = null): int
    {
        $keys = $availableKeys ?: array_keys(self::getActiveItemsForUser($this->user_id));
        $total = count($keys);
        if ($total === 0) {
            return 0;
        }

        $checked = 0;
        foreach ($keys as $key) {
            if ($this->isChecked($key)) {
                $checked++;
            }
        }

        return (int) round(($checked / $total) * 100);
    }

    /**
     * Count completed items.
     */
    public function completedCount(?array $availableKeys = null): int
    {
        $keys = $availableKeys ?: array_keys(self::getActiveItemsForUser($this->user_id));
        $count = 0;
        foreach ($keys as $key) {
            if ($this->isChecked($key)) {
                $count++;
            }
        }
        return $count;
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AmalanItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'key',
        'label',
        'category',
        'icon',
        'order',
        'is_active',
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'order' => 'integer',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function isMaster(): bool
    {
        return $this->user_id === null;
    }

    public function isCustom(): bool
    {
        return $this->user_id !== null;
    }

    /**
     * Scope for Master items (system-wide by Admin).
     */
    public function scopeMaster(Builder $query): Builder
    {
        return $query->whereNull('user_id');
    }

    /**
     * Scope for items available to a specific user (master + user's own custom items).
     */
    public function scopeForUser(Builder $query, ?int $userId): Builder
    {
        if (!$userId) {
            return $query->whereNull('user_id');
        }

        return $query->where(function ($q) use ($userId) {
            $q->whereNull('user_id')->orWhere('user_id', $userId);
        });
    }

    /**
     * Scope for active items only.
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }
}

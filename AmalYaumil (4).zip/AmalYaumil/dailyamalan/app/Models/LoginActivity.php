<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['user_id', 'login_at', 'logout_at', 'ip_address', 'user_agent'])]
class LoginActivity extends Model
{
    use HasFactory;

    protected function casts(): array
    {
        return [
            'login_at' => 'datetime',
            'logout_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Helper to get simplified browser and OS name from user agent string.
     */
    public function getDeviceInfoAttribute(): string
    {
        $agent = $this->user_agent ?? '';

        $platform = 'Unknown OS';
        if (str_contains($agent, 'Windows')) {
            $platform = 'Windows';
        } elseif (str_contains($agent, 'Macintosh') || str_contains($agent, 'Mac OS')) {
            $platform = 'macOS';
        } elseif (str_contains($agent, 'iPhone')) {
            $platform = 'iOS (iPhone)';
        } elseif (str_contains($agent, 'Android')) {
            $platform = 'Android';
        } elseif (str_contains($agent, 'Linux')) {
            $platform = 'Linux';
        }

        $browser = 'Browser';
        if (str_contains($agent, 'Edg')) {
            $browser = 'Edge';
        } elseif (str_contains($agent, 'Chrome')) {
            $browser = 'Chrome';
        } elseif (str_contains($agent, 'Safari')) {
            $browser = 'Safari';
        } elseif (str_contains($agent, 'Firefox')) {
            $browser = 'Firefox';
        }

        return "{$browser} on {$platform}";
    }

    /**
     * Get human-readable session duration if logged out.
     */
    public function getDurationAttribute(): string
    {
        if (!$this->logout_at) {
            return 'Aktif';
        }

        $diff = $this->login_at->diff($this->logout_at);
        if ($diff->h > 0) {
            return "{$diff->h}j {$diff->i}m";
        }
        return "{$diff->i}m {$diff->s}d";
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Crypt;

#[Fillable([
    'user_id',
    'date',
    'title',
    'journal_content',
    'gratitude_notes',
    'forgiveness_reflection',
    'mood',
])]
class JournalEntry extends Model
{
    use HasFactory;

    protected function casts(): array
    {
        return [
            'date' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Decrypt journal content safely, with plaintext fallback.
     */
    public function getJournalContentAttribute($value): ?string
    {
        if (empty($value)) {
            return $value;
        }
        try {
            return Crypt::decryptString($value);
        } catch (\Throwable $e) {
            return $value;
        }
    }

    /**
     * Encrypt journal content at rest with AES-256.
     */
    public function setJournalContentAttribute(?string $value): void
    {
        $this->attributes['journal_content'] = empty($value) ? null : Crypt::encryptString($value);
    }

    /**
     * Decrypt gratitude notes safely.
     */
    public function getGratitudeNotesAttribute($value): ?string
    {
        if (empty($value)) {
            return $value;
        }
        try {
            return Crypt::decryptString($value);
        } catch (\Throwable $e) {
            return $value;
        }
    }

    /**
     * Encrypt gratitude notes at rest with AES-256.
     */
    public function setGratitudeNotesAttribute(?string $value): void
    {
        $this->attributes['gratitude_notes'] = empty($value) ? null : Crypt::encryptString($value);
    }

    /**
     * Decrypt forgiveness reflection safely.
     */
    public function getForgivenessReflectionAttribute($value): ?string
    {
        if (empty($value)) {
            return $value;
        }
        try {
            return Crypt::decryptString($value);
        } catch (\Throwable $e) {
            return $value;
        }
    }

    /**
     * Encrypt forgiveness reflection at rest with AES-256.
     */
    public function setForgivenessReflectionAttribute(?string $value): void
    {
        $this->attributes['forgiveness_reflection'] = empty($value) ? null : Crypt::encryptString($value);
    }
}

<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Carbon;

#[Fillable(['name', 'email', 'password', 'role', 'is_active', 'last_login_at', 'phone', 'bio', 'access_code_used'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'last_login_at' => 'datetime',
            'is_active' => 'boolean',
            'password' => 'hashed',
        ];
    }

    /**
     * Check if user has admin role.
     */
    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    /**
     * Check if user account is active.
     */
    public function isActive(): bool
    {
        return (bool) $this->is_active;
    }

    /**
     * User's login activity records.
     */
    public function loginActivities(): HasMany
    {
        return $this->hasMany(LoginActivity::class)->orderByDesc('login_at');
    }

    /**
     * User's daily amalan records.
     */
    public function dailyAmalans(): HasMany
    {
        return $this->hasMany(DailyAmalan::class)->orderByDesc('date');
    }

    /**
     * User's private journal entries.
     */
    public function journalEntries(): HasMany
    {
        return $this->hasMany(JournalEntry::class)->orderByDesc('date');
    }

    /**
     * Count of days user has recorded amalan.
     */
    public function totalAmalanDays(): int
    {
        return $this->dailyAmalans()->count();
    }

    /**
     * Average completion rate percentage.
     */
    public function averageAmalanPercentage(): float
    {
        $avg = $this->dailyAmalans()->avg('completion_rate');
        return $avg ? round((float) $avg, 1) : 0.0;
    }

    /**
     * Check if user was active recently (e.g. within 15 minutes).
     */
    public function isRecentlyActive(): bool
    {
        if (!$this->last_login_at) {
            return false;
        }

        return $this->last_login_at->greaterThanOrEqualTo(now()->subMinutes(15));
    }
}

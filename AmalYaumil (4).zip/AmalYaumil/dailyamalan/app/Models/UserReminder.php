<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserReminder extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'reminder_morning',
        'is_morning_active',
        'reminder_dhuha',
        'is_dhuha_active',
        'reminder_evening',
        'is_evening_active',
        'reminder_night',
        'is_night_active',
        'browser_notifications_enabled',
    ];

    protected function casts(): array
    {
        return [
            'is_morning_active' => 'boolean',
            'is_dhuha_active' => 'boolean',
            'is_evening_active' => 'boolean',
            'is_night_active' => 'boolean',
            'browser_notifications_enabled' => 'boolean',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('daily_amalans', function (Blueprint $table) {
            $table->boolean('odoj_one_juz')->default(false)->after('tilawah_quran');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('daily_amalans', function (Blueprint $table) {
            $table->dropColumn('odoj_one_juz');
        });
    }
};

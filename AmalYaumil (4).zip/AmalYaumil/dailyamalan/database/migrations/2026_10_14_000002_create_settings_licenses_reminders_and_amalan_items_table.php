<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. App Settings Table
        Schema::create('app_settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->longText('value')->nullable();
            $table->string('group')->default('general');
            $table->string('type')->default('string'); // string, text, boolean, json
            $table->string('description')->nullable();
            $table->timestamps();
        });

        // 2. Access Codes & Licenses Table
        Schema::create('access_codes', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();
            $table->string('label')->default('Umum');
            $table->unsignedInteger('max_uses')->nullable(); // null = unlimited
            $table->unsignedInteger('used_count')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamp('expires_at')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        // Add access_code_used to users table
        Schema::table('users', function (Blueprint $table) {
            $table->string('access_code_used')->nullable()->after('remember_token');
        });

        // 3. User Reminders Table
        Schema::create('user_reminders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('reminder_morning', 5)->default('05:00');
            $table->boolean('is_morning_active')->default(true);
            $table->string('reminder_dhuha', 5)->default('09:30');
            $table->boolean('is_dhuha_active')->default(true);
            $table->string('reminder_evening', 5)->default('17:45');
            $table->boolean('is_evening_active')->default(true);
            $table->string('reminder_night', 5)->default('21:00');
            $table->boolean('is_night_active')->default(true);
            $table->boolean('browser_notifications_enabled')->default(false);
            $table->timestamps();
        });

        // 4. Dynamic Amalan Items Table
        Schema::create('amalan_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->cascadeOnDelete(); // null = master item, not null = user custom
            $table->string('key')->index();
            $table->string('label');
            $table->string('category')->default('kebaikan'); // wajib, sunnah, quran, dzikir, kebaikan, pribadi
            $table->string('icon')->default('check-circle');
            $table->unsignedInteger('order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // 5. Add dynamic checked_items JSON to daily_amalans
        Schema::table('daily_amalans', function (Blueprint $table) {
            $table->json('checked_items')->nullable()->after('notes');
        });
    }

    public function down(): void
    {
        Schema::table('daily_amalans', function (Blueprint $table) {
            $table->dropColumn('checked_items');
        });

        Schema::dropIfExists('amalan_items');
        Schema::dropIfExists('user_reminders');

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('access_code_used');
        });

        Schema::dropIfExists('access_codes');
        Schema::dropIfExists('app_settings');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('daily_amalans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->date('date')->index();

            // Sholat Wajib 5 Waktu
            $table->boolean('sholat_subuh')->default(false);
            $table->boolean('sholat_dzuhur')->default(false);
            $table->boolean('sholat_ashar')->default(false);
            $table->boolean('sholat_maghrib')->default(false);
            $table->boolean('sholat_isya')->default(false);

            // Sholat Sunnah & Ibadah Malam
            $table->boolean('sholat_dhuha')->default(false);
            $table->boolean('sholat_tahajud')->default(false);
            $table->boolean('sholat_rawatib')->default(false);

            // Al-Qur'an & Dzikir
            $table->boolean('tilawah_quran')->default(false);
            $table->boolean('dzikir_pagi')->default(false);
            $table->boolean('dzikir_petang')->default(false);

            // Muamalah & Kebaikan
            $table->boolean('infaq_sedekah')->default(false);
            $table->boolean('puasa_sunnah')->default(false);
            $table->boolean('membaca_ilmu')->default(false);

            $table->unsignedTinyInteger('completion_rate')->default(0);
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->unique(['user_id', 'date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('daily_amalans');
    }
};

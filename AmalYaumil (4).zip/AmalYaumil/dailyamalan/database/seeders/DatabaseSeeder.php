<?php

namespace Database\Seeders;

use App\Models\AccessCode;
use App\Models\AmalanItem;
use App\Models\AppSetting;
use App\Models\DailyAmalan;
use App\Models\JournalEntry;
use App\Models\LoginActivity;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // 0. Seed Application Settings
        AppSetting::set('app_name', 'Sunnah Bloom', 'general', 'string', 'Nama Utama Aplikasi');
        AppSetting::set('app_sub_header', 'Platform Digital Amalan Yaumi', 'general', 'string', 'Sub-header aplikasi');
        AppSetting::set('app_tagline', 'powered by Rumah Qur\'an Al-Izzah Cab. Singkawang', 'general', 'string', 'Tagline resmi lembaga');
        AppSetting::set('app_institution', 'Rumah Qur\'an (RQ) Al-Izzah Cab. Singkawang', 'general', 'string', 'Nama lembaga pengelola');
        AppSetting::set('daily_quote', 'Maka apabila engkau telah selesai (dari suatu urusan), tetaplah bekerja keras (untuk urusan yang lain), dan hanya kepada Tuhanmulah engkau berharap.', 'quote', 'text', 'Kutipan Mutiara Harian');
        AppSetting::set('daily_quote_source', 'QS. Al-Insyirah: 7-8', 'quote', 'string', 'Sumber kutipan');
        AppSetting::set('registration_requires_access_code', '1', 'access', 'boolean', 'Wajibkan Kode Akses/Lisensi saat Pendaftaran');
        AppSetting::set('default_access_code', 'RQ-ALIZZAH-2026', 'access', 'string', 'Kode Akses Registrasi Lembaga');

        // 1. Create Super Admin
        $admin = User::firstOrCreate(
            ['email' => 'admin@amalan.id'],
            [
                'name' => 'Admin Sunnah Bloom (RQ Al-Izzah)',
                'password' => Hash::make('password123'),
                'role' => 'admin',
                'is_active' => true,
                'last_login_at' => now(),
                'phone' => '081234567890',
                'bio' => 'Pengelola Utama Sunnah Bloom — RQ Al-Izzah Cab. Singkawang 🌻',
            ]
        );

        // Seed Default Access Code / License
        AccessCode::firstOrCreate(
            ['code' => 'RQ-ALIZZAH-2026'],
            [
                'label' => 'Lisensi Internal RQ Al-Izzah Singkawang',
                'max_uses' => null,
                'used_count' => 5,
                'is_active' => true,
                'created_by' => $admin->id,
            ]
        );

        // Seed Master Amalan Items
        $order = 1;
        foreach (DailyAmalan::AMALAN_KEYS as $key => $meta) {
            AmalanItem::firstOrCreate(
                ['key' => $key, 'user_id' => null],
                [
                    'label' => $meta['label'],
                    'category' => $meta['category'],
                    'icon' => $meta['icon'],
                    'order' => $order++,
                    'is_active' => true,
                ]
            );
        }

        // Admin login activities
        LoginActivity::create([
            'user_id' => $admin->id,
            'login_at' => now()->subMinutes(10),
            'ip_address' => '127.0.0.1',
            'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
        ]);

        // 2. Define Sample Regular Users
        $sampleUsers = [
            [
                'name' => 'Ahmad Rasyid',
                'email' => 'ahmad@example.com',
                'phone' => '081234567801',
                'bio' => 'Bismillah, berusaha istiqomah memperbaiki diri setiap hari.',
                'is_active' => true,
                'days_active' => 14,
                'avg_rate' => 92,
                'last_login' => now()->subMinutes(5),
                'ip' => '114.122.35.12',
                'agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36',
            ],
            [
                'name' => 'Fatimah Az-Zahra',
                'email' => 'fatimah@example.com',
                'phone' => '081234567802',
                'bio' => 'Mencari ridho Allah melalui amalan kecil yang konsisten.',
                'is_active' => true,
                'days_active' => 12,
                'avg_rate' => 88,
                'last_login' => now()->subMinutes(25),
                'ip' => '180.252.164.78',
                'agent' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1',
            ],
            [
                'name' => 'Zahra Nurul Izzah',
                'email' => 'zahra@example.com',
                'phone' => '081234567803',
                'bio' => 'Semoga Allah bimbing setiap langkah dalam kebaikan.',
                'is_active' => true,
                'days_active' => 10,
                'avg_rate' => 78,
                'last_login' => now()->subHours(2),
                'ip' => '36.72.215.110',
                'agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15',
            ],
            [
                'name' => 'Ali Syihabuddin',
                'email' => 'ali@example.com',
                'phone' => '081234567804',
                'bio' => 'Pejuang tahajud dan shubuh berjamaah.',
                'is_active' => true,
                'days_active' => 8,
                'avg_rate' => 70,
                'last_login' => now()->subHours(4),
                'ip' => '182.1.88.45',
                'agent' => 'Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 Chrome/125.0.0.0 Mobile Safari/537.36',
            ],
            [
                'name' => 'Aisyah Humaira',
                'email' => 'aisyah@example.com',
                'phone' => '081234567805',
                'bio' => 'Meniti hari dengan rasa syukur dan dzikir pagi petang.',
                'is_active' => true,
                'days_active' => 11,
                'avg_rate' => 85,
                'last_login' => now()->subHours(7),
                'ip' => '114.79.52.211',
                'agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0',
            ],
            [
                'name' => 'Hasan Al-Bashri',
                'email' => 'hasan@example.com',
                'phone' => '081234567806',
                'bio' => 'Muhasabah diri sebelum hisab di akhirat.',
                'is_active' => true,
                'days_active' => 6,
                'avg_rate' => 60,
                'last_login' => now()->subDays(1),
                'ip' => '103.144.170.15',
                'agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/127.0.0.0 Safari/537.36',
            ],
            [
                'name' => 'Maryam Salsabila',
                'email' => 'maryam@example.com',
                'phone' => '081234567807',
                'bio' => 'Cahaya kebaikan dari rutinitas Qur\'ani.',
                'is_active' => true,
                'days_active' => 5,
                'avg_rate' => 55,
                'last_login' => now()->subDays(2),
                'ip' => '125.166.12.89',
                'agent' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1',
            ],
            [
                'name' => 'Umar Farouq',
                'email' => 'umar@example.com',
                'phone' => '081234567808',
                'bio' => 'Akun sementara dinonaktifkan untuk demonstrasi kontrol admin.',
                'is_active' => false, // Inactive user for testing admin toggle!
                'days_active' => 3,
                'avg_rate' => 45,
                'last_login' => now()->subDays(4),
                'ip' => '110.138.90.33',
                'agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123.0.0.0 Safari/537.36',
            ],
            [
                'name' => 'Bilal Habasyi',
                'email' => 'bilal@example.com',
                'phone' => '081234567809',
                'bio' => 'Member baru yang baru mulai menata jadwal amalan yaumi.',
                'is_active' => true,
                'days_active' => 2,
                'avg_rate' => 40,
                'last_login' => now()->subDays(1),
                'ip' => '180.245.89.201',
                'agent' => 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36',
            ],
            [
                'name' => 'Khadijah Al-Kubra',
                'email' => 'khadijah@example.com',
                'phone' => '081234567810',
                'bio' => 'Sedekah subuh dan tilawah harian menjadi prioritasku.',
                'is_active' => true,
                'days_active' => 13,
                'avg_rate' => 95,
                'last_login' => now()->subHours(1),
                'ip' => '36.85.101.44',
                'agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36',
            ],
        ];

        foreach ($sampleUsers as $uData) {
            $user = User::updateOrCreate(
                ['email' => $uData['email']],
                [
                    'name' => $uData['name'],
                    'password' => Hash::make('password123'),
                    'role' => 'user',
                    'is_active' => $uData['is_active'],
                    'last_login_at' => $uData['last_login'],
                    'phone' => $uData['phone'],
                    'bio' => $uData['bio'],
                    'created_at' => now()->subDays(rand(15, 60)),
                ]
            );

            // Seed Login Activities for user
            // 1. Current or recent login
            LoginActivity::create([
                'user_id' => $user->id,
                'login_at' => $uData['last_login'],
                'logout_at' => $uData['last_login']->copy()->addMinutes(rand(15, 60)),
                'ip_address' => $uData['ip'],
                'user_agent' => $uData['agent'],
            ]);

            // 2. Previous logins
            for ($k = 1; $k <= rand(2, 4); $k++) {
                $pastTime = now()->subDays($k)->subHours(rand(1, 10));
                LoginActivity::create([
                    'user_id' => $user->id,
                    'login_at' => $pastTime,
                    'logout_at' => $pastTime->copy()->addMinutes(rand(10, 45)),
                    'ip_address' => $uData['ip'],
                    'user_agent' => $uData['agent'],
                ]);
            }

            // Seed Daily Amalans
            $daysCount = $uData['days_active'];
            for ($d = 0; $d < $daysCount; $d++) {
                $date = Carbon::today()->subDays($d);
                $isHigh = ($uData['avg_rate'] >= 80);

                $sholatSubuh = rand(0, 100) < ($isHigh ? 98 : 75);
                $sholatDzuhur = rand(0, 100) < ($isHigh ? 95 : 70);
                $sholatAshar = rand(0, 100) < ($isHigh ? 95 : 70);
                $sholatMaghrib = rand(0, 100) < ($isHigh ? 98 : 80);
                $sholatIsya = rand(0, 100) < ($isHigh ? 95 : 75);
                $sholatDhuha = rand(0, 100) < ($isHigh ? 80 : 40);
                $sholatTahajud = rand(0, 100) < ($isHigh ? 70 : 30);
                $sholatRawatib = rand(0, 100) < ($isHigh ? 75 : 35);
                $tilawahQuran = rand(0, 100) < ($isHigh ? 90 : 50);
                $odojOneJuz = rand(0, 100) < ($isHigh ? 80 : 35);
                $dzikirPagi = rand(0, 100) < ($isHigh ? 85 : 45);
                $dzikirPetang = rand(0, 100) < ($isHigh ? 80 : 40);
                $infaqSedekah = rand(0, 100) < ($isHigh ? 80 : 40);
                $puasaSunnah = ($date->isMonday() || $date->isThursday()) && (rand(0, 100) < ($isHigh ? 70 : 20));
                $membacaIlmu = rand(0, 100) < ($isHigh ? 75 : 35);

                $amalan = DailyAmalan::where('user_id', $user->id)->whereDate('date', $date->toDateString())->first() ?: new DailyAmalan();
                $amalan->user_id = $user->id;
                $amalan->date = $date->toDateString();
                $amalan->sholat_subuh = $sholatSubuh;
                $amalan->sholat_dzuhur = $sholatDzuhur;
                $amalan->sholat_ashar = $sholatAshar;
                $amalan->sholat_maghrib = $sholatMaghrib;
                $amalan->sholat_isya = $sholatIsya;
                $amalan->sholat_dhuha = $sholatDhuha;
                $amalan->sholat_tahajud = $sholatTahajud;
                $amalan->sholat_rawatib = $sholatRawatib;
                $amalan->tilawah_quran = $tilawahQuran;
                $amalan->odoj_one_juz = $odojOneJuz;
                $amalan->dzikir_pagi = $dzikirPagi;
                $amalan->dzikir_petang = $dzikirPetang;
                $amalan->infaq_sedekah = $infaqSedekah;
                $amalan->puasa_sunnah = $puasaSunnah;
                $amalan->membaca_ilmu = $membacaIlmu;
                $amalan->notes = $isHigh ? 'Alhamdulillah hari ini terasa damai dan produktif.' : 'InsyaAllah besok ditingkatkan lagi ibadah sunnahnya.';
                $amalan->completion_rate = $amalan->computeRate();
                $amalan->save();
            }

            // Seed Private Journals for each user (to test user views & confirm admin strictly cannot see them!)
            JournalEntry::updateOrCreate(
                ['user_id' => $user->id, 'date' => Carbon::today()->toDateString()],
                [
                    'title' => 'Catatan Perjalanan Ruhani & Refleksi Hari Ini',
                    'journal_content' => 'Hari ini Alhamdulillah merasa sangat tenang setelah sholat subuh berjamaah dan tilawah 1 juz. Ada ujian kecil di tempat kerja, tapi berusaha menahan emosi dan menyikapi dengan sabar.',
                    'gratitude_notes' => "1. Nikmat kesehatan dan bisa bangun tepat waktu.\n2. Keluarga yang selalu mendukung dan penuh kasih sayang.\n3. Rezeki kelapangan waktu untuk membaca Al-Qur'an hari ini.",
                    'forgiveness_reflection' => 'Memaafkan perkataan rekan kerja yang kurang mengenakkan tadi siang. Semoga Allah melembutkan hati kami berdua.',
                    'mood' => 'bersyukur',
                ]
            );

            JournalEntry::updateOrCreate(
                ['user_id' => $user->id, 'date' => Carbon::today()->subDays(2)->toDateString()],
                [
                    'title' => 'Muhasabah Waktu dan Niat',
                    'journal_content' => 'Mengevaluasi diri tentang bagaimana waktu luang digunakan. Terlalu banyak scrolling media sosial. Mulai besok pasang target membaca buku hadits 15 menit setiap malam.',
                    'gratitude_notes' => "1. Diberi hidayah untuk selalu ingat Allah.\n2. Makanan berkah di atas meja.\n3. Masih diberi kesempatan menghirup udara segar.",
                    'forgiveness_reflection' => 'Memaafkan diri sendiri atas kelalaian masa lalu dan berjanji membuka lembaran baru.',
                    'mood' => 'damai',
                ]
            );
        }
    }
}
